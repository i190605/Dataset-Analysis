state = {checked: false};
onChange = event => {
  this.setState({checked: event.target.checked});
};
render() {
  Scheduler.log(`render: ${this.state.checked}`);
  const controlledValue = this.props.reverse
    ? !this.state.checked
    : this.state.checked;
  return (
    <input
      ref={el => (input = el)}
      type="checkbox"
      checked={controlledValue}
      onChange={this.onChange}
    />
  );
}