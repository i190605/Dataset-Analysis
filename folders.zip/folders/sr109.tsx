export function Pagination({
    'aria-label': label,
    defaultPageIndex,
    id,
    onChange,
    pageSize = 25,
    showPages = {narrow: false},
    totalCount,
  }: PaginationProps) {
    const {
      pageIndex,
      pageStart,
      pageEnd,
      pageCount,
      hasPreviousPage,
      hasNextPage,
      selectPage,
      selectNextPage,
      selectPreviousPage,
    } = usePagination({
      defaultPageIndex,
      onChange,
      pageSize,
      totalCount,
    })
    const truncatedPageCount = pageCount > 2 ? Math.min(pageCount - 2, MAX_TRUNCATED_STEP_COUNT) : 0
    const [offsetStartIndex, setOffsetStartIndex] = useState(() => {
      // Set the offset start index to the page at index 1 since we will have the
      // first page already visible
      if (pageIndex === 0) {
        return 1
      }
      return pageIndex
    })
    const offsetEndIndex = offsetStartIndex + truncatedPageCount - 1
    const hasLeadingTruncation = offsetStartIndex >= 2
    const hasTrailingTruncation = pageCount - 1 - offsetEndIndex > 1
    const getViewportRangesToHidePages = useCallback(() => {
      if (typeof showPages !== 'boolean') {
        return Object.keys(showPages).filter(key => !showPages[key as keyof typeof viewportRanges]) as Array<
          keyof typeof viewportRanges
        >
      }
  
      if (showPages) {
        return []
      } else {
        return Object.keys(viewportRanges) as Array<keyof typeof viewportRanges>
      }
    }, [showPages])
  
    return (
      <LiveRegion>
        <LiveRegionOutlet />
        <StyledPagination aria-label={label} className="TablePagination" id={id}>
          <Range pageStart={pageStart} pageEnd={pageEnd} totalCount={totalCount} />
          <ol className="TablePaginationSteps" data-hidden-viewport-ranges={getViewportRangesToHidePages().join(' ')}>
            <Step>
              <Button
                className="TablePaginationAction"
                type="button"
                data-has-page={hasPreviousPage ? true : undefined}
                onClick={() => {
                  if (!hasPreviousPage) {
                    return
                  }
  
                  selectPreviousPage()
                  if (hasLeadingTruncation) {
                    if (pageIndex - 1 < offsetStartIndex + 1) {
                      setOffsetStartIndex(offsetStartIndex - 1)
                    }
                  }
                }}
              >
                {hasPreviousPage ? <ChevronLeftIcon /> : null}
                <span className="TablePaginationActionLabel">Previous</span>
                <VisuallyHidden>&nbsp;page</VisuallyHidden>
              </Button>
            </Step>
            {pageCount > 0 ? (
              <Step>
                <Page
                  active={pageIndex === 0}
                  onClick={() => {
                    selectPage(0)
                    if (pageCount > 1) {
                      setOffsetStartIndex(1)
                    }
                  }}
                >
                  {1}
                  {hasLeadingTruncation ? <VisuallyHidden>…</VisuallyHidden> : null}
                </Page>
              </Step>
            ) : null}
            {pageCount > 2
              ? Array.from({length: truncatedPageCount}).map((_, i) => {
                  if (i === 0 && hasLeadingTruncation) {
                    return <TruncationStep key={`truncation-${i}`} />
                  }
  
                  if (i === truncatedPageCount - 1 && hasTrailingTruncation) {
                    return <TruncationStep key={`truncation-${i}`} />
                  }
  
                  const page = offsetStartIndex + i
                  return (
                    <Step key={i}>
                      <Page
                        active={pageIndex === page}
                        onClick={() => {
                          selectPage(page)
                        }}
                      >
                        {page + 1}
                        {i === truncatedPageCount - 2 && hasTrailingTruncation ? (
                          <VisuallyHidden>…</VisuallyHidden>
                        ) : null}
                      </Page>
                    </Step>
                  )
                })
              : null}
            {pageCount > 1 ? (
              <Step>
                <Page
                  active={pageIndex === pageCount - 1}
                  onClick={() => {
                    selectPage(pageCount - 1)
                    setOffsetStartIndex(pageCount - 1 - truncatedPageCount)
                  }}
                >
                  {pageCount}
                </Page>
              </Step>
            ) : null}
            <Step>
              <Button
                className="TablePaginationAction"
                type="button"
                data-has-page={hasNextPage ? true : undefined}
                onClick={() => {
                  if (!hasNextPage) {
                    return
                  }
  
                  selectNextPage()
                  if (hasTrailingTruncation) {
                    if (pageIndex + 1 > offsetEndIndex - 1) {
                      setOffsetStartIndex(offsetStartIndex + 1)
                    }
                  }
                }}
              >
                <span className="TablePaginationActionLabel">Next</span>
                <VisuallyHidden>&nbsp;page</VisuallyHidden>
                {hasNextPage ? <ChevronRightIcon /> : null}
              </Button>
            </Step>
          </ol>
        </StyledPagination>
      </LiveRegion>
    )
  }