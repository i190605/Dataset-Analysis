ReactDOM.unstable_batchedUpdates(function () {
    // Simulate update on each component from top to bottom.
    instances.forEach(function (instance) {
      instance.forceUpdate();
    });
  });

