const Header: React.FC<React.PropsWithChildren<HeaderProps>> = ({variant, title, auxiliaryText, labelId, ...props}) => {
    const {variant: listVariant} = React.useContext(ListContext)
  
    const styles = {
      paddingY: '6px',
      paddingX: listVariant === 'full' ? 2 : 3,
      fontSize: 0,
      fontWeight: 'bold',
      color: 'fg.muted',
      ...(variant === 'filled' && {
        backgroundColor: 'canvas.subtle',
        marginX: 0,
        marginBottom: 2,
        borderTop: '1px solid',
        borderBottom: '1px solid',
        borderColor: 'neutral.muted',
      }),
    }
  
    return (
      <Box sx={styles} role="presentation" aria-hidden="true" {...props}>
        <span id={labelId}>{title}</span>
        {auxiliaryText && <span>{auxiliaryText}</span>}
      </Box>
    )
  }
  