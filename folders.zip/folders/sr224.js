import React, { Component } from 'react';

class UncontrolledDragAndDrop extends Component {
  handleDragStart = (e, item) => {
    e.dataTransfer.setData('item', item);
  }

  handleDrop = (e) => {
    const item = e.dataTransfer.getData('item');
    // Handle the dropped item.
    alert(`Dropped item: ${item}`);
  }

  render() {
    return (
      <div>
        <div
          draggable
          onDragStart={(e) => this.handleDragStart(e, 'Item 1')}
        >
          Item 1
        </div>
        <div
          draggable
          onDragStart={(e) => this.handleDragStart(e, 'Item 2')}
        >
          Item 2
        </div>
        <div
          onDrop={this.handleDrop}
          onDragOver={(e) => e.preventDefault()}
        >
          Drop Zone
        </div>
      </div>
    );
  }
}
