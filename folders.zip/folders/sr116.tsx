export const CustomFooter = ({
    disabled,
    fullHeight,
    monospace,
    minHeightLines,
    maxHeightLines,
    hideLabel,
    required,
    fileUploadsEnabled,
    onSubmit,
    onFooterClick,
    savedRepliesEnabled,
    pasteUrlsAsPlainText,
  }: ArgProps) => {
    const [value, setValue] = useState('')
  
    return (
      <>
        <MarkdownEditor
          value={value}
          onChange={setValue}
          onPrimaryAction={onSubmit}
          disabled={disabled}
          fullHeight={fullHeight}
          monospace={monospace}
          minHeightLines={minHeightLines}
          maxHeightLines={maxHeightLines}
          placeholder="Enter some Markdown..."
          onRenderPreview={renderPreview}
          onUploadFile={fileUploadsEnabled ? onUploadFile : undefined}
          emojiSuggestions={emojis}
          mentionSuggestions={mentionables}
          referenceSuggestions={references}
          required={required}
          savedReplies={savedRepliesEnabled ? savedReplies : undefined}
          pasteUrlsAsPlainText={pasteUrlsAsPlainText}
        >
          <MarkdownEditor.Label visuallyHidden={hideLabel}>Markdown Editor Example - Custom Footer</MarkdownEditor.Label>
  
          <MarkdownEditor.Footer>
            <MarkdownEditor.FooterButton
              variant="invisible"
              onClick={onFooterClick}
              leadingIcon={PlusIcon}
              sx={{borderRadius: '14px', color: 'fg.muted', borderColor: 'border.muted'}}
            >
              Add Button
            </MarkdownEditor.FooterButton>
  
            <MarkdownEditor.Actions>
              <MarkdownEditor.ActionButton variant="danger" onClick={() => setValue('')}>
                Reset
              </MarkdownEditor.ActionButton>
              <MarkdownEditor.ActionButton variant="primary" onClick={onSubmit}>
                Submit
              </MarkdownEditor.ActionButton>
            </MarkdownEditor.Actions>
          </MarkdownEditor.Footer>
        </MarkdownEditor>
        <p>Note: for demo purposes, files starting with &quot;A&quot; will be rejected.</p>
      </>
    )
  }