export function Track({
    filled,
    size,
    thumbSize,
    color,
    classNames,
    styles,
    radius,
    children,
    offset,
    disabled,
    marksOffset,
    unstyled,
    inverted,
    variant,
    containerProps,
    ...others
  }: TrackProps) {
    const { classes } = useStyles(
      { color, radius, disabled, inverted, thumbSize },
      { name: 'Slider', classNames, styles, unstyled, variant, size }
    );
  
    return (
      <>
        <div className={classes.trackContainer} {...containerProps}>
          <div className={classes.track}>
            <Box
              className={classes.bar}
              sx={{
                left: `calc(${offset}% - ${
                  thumbSize ? rem(thumbSize / 2) : getSize({ size, sizes })
                })`,
                width: `calc(${filled}% + 2 * ${
                  thumbSize ? rem(thumbSize / 2) : getSize({ size, sizes })
                })`,
              }}
            />
  
            {children}
          </div>
        </div>
  
        <Marks
          {...others}
          size={size}
          thumbSize={thumbSize}
          color={color}
          offset={marksOffset}
          classNames={classNames}
          styles={styles}
          disabled={disabled}
          unstyled={unstyled}
          inverted={inverted}
          variant={variant}
        />
      </>
    );
  }
  
  Track.displayName = '@mantine/core/SliderTrack';
  