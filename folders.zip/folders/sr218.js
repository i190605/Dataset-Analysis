import React, { Component } from 'react';

class UncontrolledShoppingCart extends Component {
  constructor(props) {
    super(props);
    this.cartItems = [];
  }

  handleAddToCart = (item) => {
    // Add the item to the shopping cart.
    this.cartItems.push(item);
  }

  handleCheckout = () => {
    // Perform checkout logic and display a receipt.
    alert(`Checkout complete. Total items: ${this.cartItems.length}`);
  }

  render() {
    return (
      <div>
        <button onClick={() => this.handleAddToCart({ name: 'Product 1', price: 10 })}>Add Product 1 to Cart</button>
        <button onClick={() => this.handleAddToCart({ name: 'Product 2', price: 20 })}>Add Product 2 to Cart</button>
        <button onClick={() => this.handleCheckout()}>Checkout</button>
        {/* Cart content and receipt */}
      </div>
    );
  }
}
