export function _Dropzone(props: DropzoneProps) {
    const {
      className,
      padding,
      radius,
      disabled,
      classNames,
      styles,
      loading,
      multiple,
      maxSize,
      accept,
      children,
      onDropAny,
      onDrop,
      onReject,
      openRef,
      name,
      unstyled,
      maxFiles,
      autoFocus,
      activateOnClick,
      activateOnDrag,
      dragEventsBubbling,
      activateOnKeyboard,
      onDragEnter,
      onDragLeave,
      onDragOver,
      onFileDialogCancel,
      onFileDialogOpen,
      preventDropOnDocument,
      useFsAccessApi,
      getFilesFromEvent,
      validator,
      variant,
      ...others
    } = useComponentDefaultProps('Dropzone', defaultProps, props);
  
    const { classes, cx } = useStyles(
      { radius, padding },
      { name: 'Dropzone', classNames, styles, unstyled, variant }
    );
  
    const { getRootProps, getInputProps, isDragAccept, isDragReject, open } = useDropzone({
      onDrop: onDropAny,
      onDropAccepted: onDrop,
      onDropRejected: onReject,
      disabled: disabled || loading,
      accept: Array.isArray(accept) ? accept.reduce((r, key) => ({ ...r, [key]: [] }), {}) : accept,
      multiple,
      maxSize,
      maxFiles,
      autoFocus,
      noClick: !activateOnClick,
      noDrag: !activateOnDrag,
      noDragEventsBubbling: !dragEventsBubbling,
      noKeyboard: !activateOnKeyboard,
      onDragEnter,
      onDragLeave,
      onDragOver,
      onFileDialogCancel,
      onFileDialogOpen,
      preventDropOnDocument,
      useFsAccessApi,
      validator,
      ...(getFilesFromEvent ? { getFilesFromEvent } : null),
    });
  
    assignRef(openRef, open);
  
    const isIdle = !isDragAccept && !isDragReject;
  
    return (
      <DropzoneProvider value={{ accept: isDragAccept, reject: isDragReject, idle: isIdle }}>
        <Box
          {...others}
          {...getRootProps()}
          data-accept={isDragAccept || undefined}
          data-reject={isDragReject || undefined}
          data-idle={isIdle || undefined}
          data-loading={loading || undefined}
          className={cx(classes.root, className)}
        >
          <LoadingOverlay visible={loading} radius={radius} unstyled={unstyled} />
          <input {...getInputProps()} name={name} />
          <div className={classes.inner}>{children}</div>
        </Box>
      </DropzoneProvider>
    );
  }
  
  _Dropzone.displayName = '@mantine/dropzone/Dropzone';
  _Dropzone.Accept = DropzoneAccept;
  _Dropzone.Reject = DropzoneReject;
  _Dropzone.Idle = DropzoneIdle;
  
  export const Dropzone: ForwardRefWithStaticComponents<
    DropzoneProps,
    {
      Accept: typeof DropzoneAccept;
      Reject: typeof DropzoneReject;
      Idle: typeof DropzoneIdle;
      FullScreen: DropzoneFullScreenType;
    }
  > = _Dropzone as any;
  