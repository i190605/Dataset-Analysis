import React, { Component } from 'react';

class UncontrolledTaskManager extends Component {
  constructor(props) {
    super(props);
    this.state = {
      tasks: [],
      newTask: '',
    };
  }

  handleInputChange = (e) => {
    this.setState({ newTask: e.target.value });
  }

  handleAddTask = () => {
    const { newTask, tasks } = this.state;
    if (newTask.trim() === '') return;
    const newTasks = [...tasks, { text: newTask, completed: false }];
    this.setState({ tasks: newTasks, newTask: '' });
  }

  handleToggleTask = (index) => {
    const updatedTasks = [...this.state.tasks];
    updatedTasks[index].completed = !updatedTasks[index].completed;
    this.setState({ tasks: updatedTasks });
  }

  renderTasks() {
    return this.state.tasks.map((task, index) => (
      <div key={index}>
        <input
          type="checkbox"
          checked={task.completed}
          onChange={() => this.handleToggleTask(index)}
        />
        <span>{task.text}</span>
      </div>
    ));
  }

  render() {
    return (
      <div>
        <h2>Task Manager</h2>
        <div>
          <input type="text" value={this.state.newTask} onChange={this.handleInputChange} />
          <button onClick={this.handleAddTask}>Add Task</button>
        </div>
        <div>
          {this.renderTasks()}
        </div>
      </div>
    );
  }
}
