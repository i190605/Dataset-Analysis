class UnthemedFluxQueryEditor extends PureComponent<Props> {
    onFluxQueryChange = (query: string) => {
      this.props.onChange({ ...this.props.query, query });
      this.props.onRunQuery();
    };
  
    onSampleChange = (val: SelectableValue<string>) => {
      this.props.onChange({
        ...this.props.query,
        query: val.value!,
      });
  
      // Angular HACK: Since the target does not actually change!
      this.forceUpdate();
      this.props.onRunQuery();
    };
  
    getSuggestions = (): CodeEditorSuggestionItem[] => {
      const sugs: CodeEditorSuggestionItem[] = [
        {
          label: 'v.timeRangeStart',
          kind: CodeEditorSuggestionItemKind.Property,
          detail: 'The start time',
        },
        {
          label: 'v.timeRangeStop',
          kind: CodeEditorSuggestionItemKind.Property,
          detail: 'The stop time',
        },
        {
          label: 'v.windowPeriod',
          kind: CodeEditorSuggestionItemKind.Property,
          detail: 'based on max data points',
        },
        {
          label: 'v.defaultBucket',
          kind: CodeEditorSuggestionItemKind.Property,
          detail: 'bucket configured in the datsource',
        },
        {
          label: 'v.organization',
          kind: CodeEditorSuggestionItemKind.Property,
          detail: 'org configured for the datsource',
        },
      ];
  
      const templateSrv = getTemplateSrv();
      templateSrv.getVariables().forEach((variable) => {
        const label = '${' + variable.name + '}';
        let val = templateSrv.replace(label);
        if (val === label) {
          val = '';
        }
        sugs.push({
          label,
          kind: CodeEditorSuggestionItemKind.Text,
          detail: `(Template Variable) ${val}`,
        });
      });
  
      return sugs;
    };
  
    // For some reason in angular, when this component gets re-mounted, the width
    // is not set properly.  This forces the layout shortly after mount so that it
    // displays OK.  Note: this is not an issue when used directly in react
    editorDidMountCallbackHack = (editor: MonacoEditor) => {
      setTimeout(() => editor.layout(), 100);
    };
  
    render() {
      const { query, theme } = this.props;
      const styles = getStyles(theme);
  
      const helpTooltip = (
        <div>
          Type: <i>ctrl+space</i> to show template variable suggestions <br />
          Many queries can be copied from Chronograf
        </div>
      );
  
      return (
        <>
          <CodeEditor
            height={'100%'}
            containerStyles={styles.editorContainerStyles}
            language="sql"
            value={query.query || ''}
            onBlur={this.onFluxQueryChange}
            onSave={this.onFluxQueryChange}
            showMiniMap={false}
            showLineNumbers={true}
            getSuggestions={this.getSuggestions}
            onEditorDidMount={this.editorDidMountCallbackHack}
          />
          <div className={cx('gf-form-inline', styles.editorActions)}>
            <LinkButton
              icon="external-link-alt"
              variant="secondary"
              target="blank"
              href="https://docs.influxdata.com/influxdb/latest/query-data/get-started/"
            >
              Flux language syntax
            </LinkButton>
            <Segment
              options={samples}
              value="Sample query"
              onChange={this.onSampleChange}
              className={css`
                margin-top: -${theme.spacing(0.5)};
                margin-left: ${theme.spacing(0.5)};
              `}
            />
            <div className="gf-form gf-form--grow">
              <div className="gf-form-label gf-form-label--grow"></div>
            </div>
            <InlineFormLabel width={5} tooltip={helpTooltip}>
              Help
            </InlineFormLabel>
          </div>
        </>
      );
    }
  }
  