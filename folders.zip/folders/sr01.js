
class GetEventTypeDuringUpdate extends React.Component {
    state = {};
  
    onClick = () => {
      this.expectUpdate = true;
      this.forceUpdate();
    };
  
    componentDidUpdate() {
      if (this.expectUpdate) {
        this.expectUpdate = false;
        this.setState({eventType: window.event.type});
        setTimeout(() => {
          this.setState({cleared: !window.event});
        });
      }
    }
  
    render() {
      return (
        <div className="test-fixture">
          <button onClick={this.onClick}>Trigger callback in event.</button>
          {this.state.eventType ? (
            <p>
              Got <b>{this.state.eventType}</b> event.
            </p>
          ) : (
            <p>Got no event</p>
          )}
          {this.state.cleared ? (
            <p>Event cleared correctly.</p>
          ) : (
            <p>Event failed to clear.</p>
          )}
        </div>
      );
    }
  }
  