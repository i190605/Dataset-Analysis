const SubReport = () => {
    const [color, setColor] = useState(true);
    const [colo, setColo] = useState(true);
    const history = useHistory();
    const handleClick = async () => {
      const data = await axios.get('http://3.239.246.88:5000/class/download', {
          headers: {
            'Content-Type': 'multipart/form-data'
          },
          responseType: 'arraybuffer'
        })
        const blob = new Blob([data.data], { type: 'application/pdf' })
        saveAs(blob, "ClassReports.pdf")
        if(data)
        setColor(true)
  
    };
    const handleButton = async () => {
      try{
        const data = await axios.post('http://3.239.246.88:5000/class/generate')
        console.log(data)
        if(data)
        setColor(false)
      }
      catch (e) {
          console.log(e)
      }
    };
    const handleClic = async () => {
      const data = await axios.get("http://3.239.246.88:5000/fee/download", {
        headers: {
          "Content-Type": "multipart/form-data",
        },
        responseType: "arraybuffer",
      });
      const blob = new Blob([data.data], { type: "application/pdf" });
      saveAs(blob, "FeeReport.pdf");
      if (data) setColo(true);
    };
    const handleButto = async () => {
      try {
        const data = await axios.post("http://3.239.246.88:5000/fee/generate");
        console.log(data);
        if (data) setColo(false);
      } catch (e) {
        console.log(e);
      }
    };
  
  
    return (
      <>
        <Paper
              style={styles.paperContainer}
            >
              <Typography className="text-center text-light py-5" variant="h4">
                Reports
              </Typography>
            </Paper>
          <Box
            sx={{
              bgcolor: 'background.paper',
              pt: 8,
              pb: 6,
            }}
          >
            <Container maxWidth="sm">
              <Typography
                component="h1"
                variant="h2"
                align="center"
                color="text.primary"
                gutterBottom
              >
                Classes Held and Not Held Report
              </Typography>
              <Typography variant="h5" align="center" color="text.secondary" paragraph>
                The report contains Student Name, Teacher Name, Date of Class Held or Not Held, Dua for the Student, Course Covered
                in respective class and Status of Class.
              </Typography>
              <Stack
                sx={{ pt: 4 }}
                direction="row"
                spacing={2}
                justifyContent="center"
              >
                {color===true ?<Button variant="contained" onClick={handleButton}>Generate Report</Button>:<Button variant="outline" onClick={() => alert("Report Is Already Generated")}>Generate Report</Button>}
                {color===true ?<Button variant="outlined" onClick={() => alert("Please Generate the Report")}>Download Report</Button>:<Button variant="contained" onClick={handleClick} >Download Report</Button>}
              </Stack>
            </Container>
          </Box>
          <Divider />
          <Box
          sx={{
            bgcolor: "background.paper",
            pt: 8,
            pb: 6,
          }}
        >
          <Container maxWidth="sm">
            <Typography
              component="h1"
              variant="h2"
              align="center"
              color="text.primary"
              gutterBottom
            >
              Fee Report For Classes
            </Typography>
            <Typography
              variant="h5"
              align="center"
              color="text.secondary"
              paragraph
            >
              The report contains Student Name, Teacher Name, Date of Class Held
              or Not Held, Dua for the Student, Course Covered in respective class
              and Status of Class.
            </Typography>
            <Stack
              sx={{ pt: 4 }}
              direction="row"
              spacing={2}
              justifyContent="center"
            >
              {colo === true ? (
                <Button variant="contained" onClick={handleButto}>
                  Generate Report
                </Button>
              ) : (
                <Button
                  variant="outline"
                  onClick={() => alert("Report Is Already Generated")}
                >
                  Generate Report
                </Button>
              )}
              {colo === true ? (
                <Button
                  variant="outlined"
                  onClick={() => alert("Please Generate the Report")}
                >
                  Download Report
                </Button>
              ) : (
                <Button variant="contained" onClick={handleClic}>
                  Download Report
                </Button>
              )}
            </Stack>
          </Container>
        </Box>
      </>
    );
  };
  