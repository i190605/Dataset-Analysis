import React, { Component } from 'react';

class UncontrolledDropdown extends Component {
  handleSelectChange = () => {
    const select = this.selectRef.current;
    alert(`Selected value: ${select.value}`);
  }

  render() {
    return (
      <div>
        <select onChange={this.handleSelectChange} ref={this.selectRef}>
          <option value="option1">Option 1</option>
          <option value="option2">Option 2</option>
          <option value="option3">Option 3</option>
        </select>
      </div>
    );
  }
}
