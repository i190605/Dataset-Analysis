const TeacherTable = (props) => {
    const history = useHistory();
    const classes = useStyles();
  
    const [page, setPage] = React.useState(0);
    const [toast, setToast] = React.useState(false);
    const [rowsPerPage, setRowsPerPage] = React.useState(5);
    const [openConfir, setOpenConfir] = React.useState(false);
    const [userId, setUserId] = React.useState("");
    const [newUserId, setNewUserId] = React.useState("");
  
    const handleClickOpenConfir = (id) => {
      setUserId(id);
      setOpenConfir(true);
    };
  
    const handleCloseConfir = () => {
      setOpenConfir(false);
    };
  
    const editUser = async (user) => {
      history.push({
        pathname: "/teacherRegister",
        state: { user: user, role: "Teacher", edit: true },
      });
    };
    const removeUser = async () => {
      const user = await Axios.post(`/users/delete-teacher`, 
      {
        teacherId: userId,
        newTeacherId: newUserId,
      },
      {
        headers: {
          Authorization: "Bearer " + localStorage.getItem("auth_token"),
        },
      });
      setToast(true);
      setTimeout(() => {
        window.location.reload();
      }, 1000);
      console.log(user);
    };
  
    return (
      <>
        <Toast_Comp
          setToast={setToast}
          renderToast={toast}
          msg={`Teacher deleted successfully}`}
        />
        <Table breakPoint={700}>
          <Thead>
            <Tr>
              <Th>Serial No.</Th>
              <Th>Teacher name</Th>
              <Th>Email</Th>
              <Th>Actions</Th>
            </Tr>
          </Thead>
          <Tbody>
            {(props.data && rowsPerPage > 0
              ? props.data.slice(
                  page * rowsPerPage,
                  page * rowsPerPage + rowsPerPage
                )
              : props.data
            ).map((user, index) => (
              <Tr>
                <Td>{index + 1}</Td>
                <Td>{user.userName}</Td>
                <Td>{user.email}</Td>
                <Td>
                  <IconButton onClick={() => editUser(user)}>
                    <EditIcon color="primary" />
                  </IconButton>
                  <IconButton
                    type="button"
                    className="btn btn-sm"
                    data-bs-toggle="modal"
                    data-bs-target="#exampleModal"
                    onClick={() => handleClickOpenConfir(user._id)}
                  >
                    <DeleteIcon style={{ color: "red" }} />
                  </IconButton>
                  <div
                    className="modal fade"
                    id="exampleModal"
                    tabindex="-1"
                    aria-labelledby="exampleModalLabel"
                    aria-hidden="true"
                  >
                    <div className="modal-dialog modal-dialog-centered">
                      <div className="modal-content">
                        <div className="modal-header">
                          <h5 className="modal-title" id="exampleModalLabel">
                            Confirm Delete
                          </h5>
                          <button
                            type="button"
                            className="btn-close"
                            data-bs-dismiss="modal"
                            aria-label="Close"
                          ></button>
                        </div>
                        <div className="modal-body text-left">
                          <div className="mt-2 mb-3">
                            <form>
                              <label>
                                Are you sure to delete the teacher please select
                                new teacher to assign Students?
                              </label>
                              <select className="form-control"
                                onChange={(e) => setNewUserId(e.target.value)}
                              >
                                <option value="">Select Teacher</option>
                                {props.data.map((user, index) => (
                                   user._id != userId ? <option value={user._id}>{user.userName}</option> : null
                                ))}
                              </select>
                            </form>
                          </div>
                        </div>
                        <div className="modal-footer">
                          <button
                            type="button"
                            className="btn btn-secondary"
                            onClick={handleCloseConfir}
                            data-bs-dismiss="modal"
                          >
                            Disagree
                          </button>
                          <button
                            type="button"
                            className="btn btn-primary"
                            onClick={() => {
                              removeUser(user._id);
                              handleCloseConfir();
                            }}
                            autoFocus
                          >
                            Agree
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </Td>
              </Tr>
            ))}
          </Tbody>
        </Table>
      </>
    );
  };
  
  