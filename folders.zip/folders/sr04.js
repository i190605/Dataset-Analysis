class Foo extends React.Component {
    constructor(props) {
      super(props);
      this.state = {bar: props.initialValue};
    }
    handleClick() {
      this.setState({bar: 'bar'});
    }
    render() {
      return (
        <Inner name={this.state.bar} onClick={this.handleClick.bind(this)} />
      );
    }
  }
  test(<Foo initialValue="foo" />, 'DIV', 'foo');

  ReactDOM.flushSync(() => attachedListener());
  expect(renderedName).toBe('bar');
  
it('should not implicitly bind event handlers', () => {
  class Foo extends React.Component {
    constructor(props) {
      super(props);
      this.state = {bar: props.initialValue};
    }
    handleClick() {
      this.setState({bar: 'bar'});
    }
    render() {
      return <Inner name={this.state.bar} onClick={this.handleClick} />;
    }
  }
  test(<Foo initialValue="foo" />, 'DIV', 'foo');
  expect(attachedListener).toThrow();
});

it('renders using forceUpdate even when there is no state', () => {
  class Foo extends React.Component {
    constructor(props) {
      super(props);
      this.mutativeValue = props.initialValue;
    }
    handleClick() {
      this.mutativeValue = 'bar';
      this.forceUpdate();
    }
    render() {
      return (
        <Inner
          name={this.mutativeValue}
          onClick={this.handleClick.bind(this)}
        />
      );
    }
  }
  test(<Foo initialValue="foo" />, 'DIV', 'foo');
  ReactDOM.flushSync(() => attachedListener());
  expect(renderedName).toBe('bar');
});

it('will call all the normal life cycle methods', () => {
  let lifeCycles = [];
  class Foo extends React.Component {
    constructor() {
      super();
      this.state = {};
    }
    UNSAFE_componentWillMount() {
      lifeCycles.push('will-mount');
    }
    componentDidMount() {
      lifeCycles.push('did-mount');
    }
    UNSAFE_componentWillReceiveProps(nextProps) {
      lifeCycles.push('receive-props', nextProps);
    }
    shouldComponentUpdate(nextProps, nextState) {
      lifeCycles.push('should-update', nextProps, nextState);
      return true;
    }
    UNSAFE_componentWillUpdate(nextProps, nextState) {
      lifeCycles.push('will-update', nextProps, nextState);
    }
    componentDidUpdate(prevProps, prevState) {
      lifeCycles.push('did-update', prevProps, prevState);
    }
    componentWillUnmount() {
      lifeCycles.push('will-unmount');
    }
    render() {
      return <span className={this.props.value} />;
    }
  }
  test(<Foo value="foo" />, 'SPAN', 'foo');
  expect(lifeCycles).toEqual(['will-mount', 'did-mount']);
  lifeCycles = []; // reset
  test(<Foo value="bar" />, 'SPAN', 'bar');
  // prettier-ignore
  expect(lifeCycles).toEqual([
    'receive-props', freeze({value: 'bar'}),
    'should-update', freeze({value: 'bar'}), {},
    'will-update', freeze({value: 'bar'}), {},
    'did-update', freeze({value: 'foo'}), {},
  ]);
  lifeCycles = []; // reset
  ReactDOM.flushSync(() => root.unmount());
  expect(lifeCycles).toEqual(['will-unmount']);
});

if (!require('shared/ReactFeatureFlags').disableLegacyContext) {
  it('warns when classic properties are defined on the instance, but does not invoke them.', () => {
    let getDefaultPropsWasCalled = false;
    let getInitialStateWasCalled = false;
    class Foo extends React.Component {
      constructor() {
        super();
        this.contextTypes = {};
        this.contextType = {};
        this.propTypes = {};
      }
      getInitialState() {
        getInitialStateWasCalled = true;
        return {};
      }
      getDefaultProps() {
        getDefaultPropsWasCalled = true;
        return {};
      }
      render() {
        return <span className="foo" />;
      }
    }

    expect(() => test(<Foo />, 'SPAN', 'foo')).toErrorDev([
      'getInitialState was defined on Foo, a plain JavaScript class.',
      'getDefaultProps was defined on Foo, a plain JavaScript class.',
      'propTypes was defined as an instance property on Foo.',
      'contextType was defined as an instance property on Foo.',
      'contextTypes was defined as an instance property on Foo.',
    ]);
    expect(getInitialStateWasCalled).toBe(false);
    expect(getDefaultPropsWasCalled).toBe(false);
  });
}

it('does not warn about getInitialState() on class components if state is also defined.', () => {
  class Foo extends React.Component {
    state = this.getInitialState();
    getInitialState() {
      return {};
    }
    render() {
      return <span className="foo" />;
    }
  }
  test(<Foo />, 'SPAN', 'foo');
});

it('should warn when misspelling shouldComponentUpdate', () => {
  class NamedComponent extends React.Component {
    componentShouldUpdate() {
      return false;
    }
    render() {
      return <span className="foo" />;
    }
  }

  expect(() => test(<NamedComponent />, 'SPAN', 'foo')).toErrorDev(
    'Warning: ' +
      'NamedComponent has a method called componentShouldUpdate(). Did you ' +
      'mean shouldComponentUpdate()? The name is phrased as a question ' +
      'because the function is expected to return a value.',
  );
});

it('should warn when misspelling componentWillReceiveProps', () => {
  class NamedComponent extends React.Component {
    componentWillRecieveProps() {
      return false;
    }
    render() {
      return <span className="foo" />;
    }
  }

  expect(() => test(<NamedComponent />, 'SPAN', 'foo')).toErrorDev(
    'Warning: ' +
      'NamedComponent has a method called componentWillRecieveProps(). Did ' +
      'you mean componentWillReceiveProps()?',
  );
});

it('should warn when misspelling UNSAFE_componentWillReceiveProps', () => {
  class NamedComponent extends React.Component {
    UNSAFE_componentWillRecieveProps() {
      return false;
    }
    render() {
      return <span className="foo" />;
    }
  }

  expect(() => test(<NamedComponent />, 'SPAN', 'foo')).toErrorDev(
    'Warning: ' +
      'NamedComponent has a method called UNSAFE_componentWillRecieveProps(). ' +
      'Did you mean UNSAFE_componentWillReceiveProps()?',
  );
});

it('should throw AND warn when trying to access classic APIs', () => {
  const ref = React.createRef();
  test(<Inner name="foo" ref={ref} />, 'DIV', 'foo');
  expect(() =>
    expect(() => ref.current.replaceState({})).toThrow(),
  ).toWarnDev(
    'replaceState(...) is deprecated in plain JavaScript React classes',
    {withoutStack: true},
  );
  expect(() => expect(() => ref.current.isMounted()).toThrow()).toWarnDev(
    'isMounted(...) is deprecated in plain JavaScript React classes',
    {withoutStack: true},
  );
});

if (!require('shared/ReactFeatureFlags').disableLegacyContext) {
  it('supports this.context passed via getChildContext', () => {
    class Bar extends React.Component {
      render() {
        return <div className={this.context.bar} />;
      }
    }
    Bar.contextTypes = {bar: PropTypes.string};
    class Foo extends React.Component {
      getChildContext() {
        return {bar: 'bar-through-context'};
      }
      render() {
        return <Bar />;
      }
    }
    Foo.childContextTypes = {bar: PropTypes.string};
    test(<Foo />, 'DIV', 'bar-through-context');
  });
}

it('supports string refs', () => {
  class Foo extends React.Component {
    render() {
      return <Inner name="foo" ref="inner" />;
    }
  }
  const ref = React.createRef();
  expect(() => {
    test(<Foo ref={ref} />, 'DIV', 'foo');
  }).toErrorDev([
    'Warning: Component "Foo" contains the string ref "inner". ' +
      'Support for string refs will be removed in a future major release. ' +
      'We recommend using useRef() or createRef() instead. ' +
      'Learn more about using refs safely here: https://reactjs.org/link/strict-mode-string-ref\n' +
      '    in Foo (at **)',
  ]);
  expect(ref.current.refs.inner.getName()).toBe('foo');
});

it('supports drilling through to the DOM using findDOMNode', () => {
  const ref = React.createRef();
  test(<Inner name="foo" ref={ref} />, 'DIV', 'foo');
  const node = ReactDOM.findDOMNode(ref.current);
  expect(node).toBe(container.firstChild);
});
