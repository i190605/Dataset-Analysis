function Test() {
    const inputRef = React.useRef(null);
    return (
      <div>
        <button
          ref={buttonRef}
          onClick={() => {
            // Sync click
            inputRef.current.click();
          }}
        />
        <input
          ref={inputRef}
          onClick={() => {
            clicks++;
          }}
        />
      </div>
    );
  }
