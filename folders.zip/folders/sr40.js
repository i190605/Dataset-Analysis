const ClientRegister = () => {
    const [userName, setUserName] = useState("");
    const [email, setEmail] = useState("");
    const [NumberOfStudent, setNumberofStudent] = useState();
    const [ContactNumber, setContactNumber] = useState("");
    const [setCountryObj] = useState({})
    const [Country, setCountry] = useState("")
    const [Fee,setFee] = useState();
    const [FeeDate,setFeeDate] = useState();
    const [NumberofClasses, setNumberofClasses] = useState()
  
    const [userNameError , setUserNameError] = useState ("");
    const [NumberOfStudentError , setNumberOfStudentError] = useState("");
    const [ContactNumberError , setContactNumberError] = useState("");
    const [CountryObjError  , setCountryObjError] = useState("");
    const [emailError ,setEmailError] = useState("");
    const [feeError , setFeeError] =useState("");
    const [feeDateError ,setFeeDateError] = useState("");
  
    const [NumberofClassesError , setNumberOfClassesError] = useState("");
  
    const [error, setError] = useState();
    const [loading, setLoading] = useState(false);
    const [toast, setToast] = useState(false);
    const history = useHistory();
    const edit = history.location.state.edit ? history.location.state.edit : false;
    const User = history.location.state.user ? history.location.state.user : null;
  
    const { user } = useSelector((state) => state.auth);
  
  
    const ValidateForm = () => {
  
      if(userName === ""){
        setUserNameError({userName:"Enter a Valid Name"})
        CheckNumberOfStudents()
        CheckContactNumber()
        checkCountry()
        CheckEmail()
        checkFee()
        checkFeeDate()
        checkNumberOfClasses()
        return 0;
      }
      const chckNOS = CheckNumberOfStudents()
      const chckCN = CheckContactNumber()
      const chkCon = checkCountry()
      const chkEmail = CheckEmail()
      const chkFee = checkFee()
      const chckFD = checkFeeDate()
      const chkNoC = checkNumberOfClasses()
      console.log(chckNOS && chckCN && chkCon && chkEmail && chkFee && chckFD && chkNoC)
  
      if(chckNOS && chckCN && chkCon && chkEmail && chkFee && chckFD && chkNoC)
      return 1;
      else 
      return 0;
    }
  
    const CheckNumberOfStudents = () => {
      console.log(NumberOfStudent)
      if(NumberOfStudent === undefined)
      {
          console.log("number of student")
          setNumberOfStudentError({NumberOfStudent:"Please enter number of Students"})
          return 0;
      }
      return 1;
    }
  
    const CheckContactNumber = () => {
      console.log(ContactNumber)
      if(ContactNumber === undefined){
        setContactNumberError({ContactNumber:"Please enter a valid number"})
        return 0;
      }
      return 1;
    }
  
    const checkCountry = () => {
      if(Country === "")
      {
        setCountryObjError({CountryObj:"Select a country"})
        return 0;
      }
      return 1;
    }
  
    const CheckEmail = () => {
      var emailPattern = /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/;
      if(email === ""){
        setEmailError({email:"Email is required"})
        return 0;
      }
      if(!emailPattern.test(email)){
        setEmailError({email:"Email is Invalid"})
        return 0;
      }
      return 1;
    }
  
    const checkFee = () => {
      if(Fee === undefined){
        setFeeError({Fee:'Enter Valid Fee'})
        return 0;
      }
      return 1;
    }
  
    const checkNumberOfClasses = () => {
      if (NumberofClasses === undefined){
        setNumberOfClassesError({NumberofClasses:"Number of Classes Are Required"})
        return 0;
      }
      return 1;
    }
  
    const checkFeeDate = () => {
      if(FeeDate === undefined){
        setFeeDateError({FeeDate:"Fee Date is Required"})
        return 0;
      }
      return 1;
    }
    
    const ClickBack = () => {
      history.push({
        pathname: "/admin/client-info",
      });
    }
  
    const formSubmitHandler = (e) => {
      e.preventDefault();
      const check = ValidateForm()
      console.log(check)
      if(check){
        if (!edit) {
          e.preventDefault();
          setLoading(true);
          fetch("http://3.239.246.88:5000/auth/client/register", {
            method: "post",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              userName,
              email,
              NumberOfStudent,
              ContactNumber,
              Country,
              Fee,
              FeeDate,
              NumberofClasses
            }),
          })
            .then((res) => res.json())
            .then((result) => {
              setLoading(false);
              console.log(result);
              if (result.errors) {
                setError(result.errors);
              } else {
                setToast(true);
                setError(null);
                setTimeout(() => {
                  history.push("/admin/client-info");
                }, 3000);
                clearTimeout();
              }
            })
            .catch((err) => {
              console.log(err);
            });
        }
        else {
          console.log(userName,
            email,
            NumberOfStudent,
            ContactNumber,
            Country,
            Fee,
            FeeDate,
            NumberofClasses,)
          e.preventDefault();
          setLoading(true);
          fetch("http://3.239.246.88:5000/users/client/edit-profile", {
            method: "put",
            headers: {
              "Content-Type": "application/json",
              "Authorization": "Bearer " + localStorage.getItem("auth_token"),
            },
            body: JSON.stringify({
              _id: User._id,
              userName,
              email,
              NumberOfStudent,
              ContactNumber,
              Country,
              Fee,
              FeeDate,
              NumberofClasses
            }),
          })
            .then((res) =>res.json())
            .then((result) => {
              setLoading(false);
              console.log(result);
              if (result.errors) {
                setError(result.errors);
              } else {
                setToast(true);
                setError(null);
                setTimeout(() => {
                  history.push("/admin/client-info");
                }, 3000);
                clearTimeout();
              }
            })
            .catch((err) => {
              console.log(err);
            });
        }
      }
    }
  
    useEffect(() => {
      console.log(User)
      User ? setUserName(User.userName) : setUserName("");
      User ? setNumberofStudent(User.NumberOfStudent) : setNumberofStudent();
      User ? setContactNumber(User.ContactNumber) : setContactNumber();
      User ? setCountryObj(User.Country): setCountryObj({});
      User ? setEmail(User.email) : setEmail("");
      User ? setFee(User.Fee) : setFee();
      User ? setFeeDate(User.FeeDate) : setFeeDate();
      User ? setNumberofClasses(User.NumberofClasses): setNumberofClasses();
    }, [user])
  
    console.log(Country)
  
    return (
      <>
  
        <div style={{ fontFamily: "Poppins" }}>
          <Container>
            <Toast_Comp
              setToast={setToast}
              renderToast={toast}
              msg={`Client Added successfully`}
            />
            <Row>
              <Col md={6} className="mx-auto mt-4 ">
                <Paper className="p-4 shadow rounded">
                  <Typography
                    className="text-center text-primary mb-3"
                    variant="h5"
                  >
                    Client Form
                  </Typography>
                  {loading && <Spinner_comp />}
                  {error && error.user && (
                    <Alert_Comp variant="danger" msg={error.user} />
                  )}
  
                  <Form onSubmit={formSubmitHandler}>
                    <Form.Group controlId="formBasicParentName">
                      <Form.Label>Full Name</Form.Label>
                      <Form.Control
                        type="text"
                        placeholder="Enter Parent/Guardian Name"
                        value={userName}
                        onChange={(e) => {
                          setUserNameError(null)
                          setUserName(e.target.value)}}
                      />
                      <span style={{ color: "red" }}>
                          {userNameError && userNameError.userName}
                      </span>
                    </Form.Group>
                    <Form.Group controlId="formBasicNoOfStudent">
                      <Form.Label>Number of Student</Form.Label>
                      <Form.Control
                        type="number"
                        placeholder="Enter No. of Students"
                        value={NumberOfStudent}
                        onChange={(e) => {
                          setNumberOfStudentError(null)
                          setNumberofStudent(e.target.value)}}
                      />
                      <span style={{ color: "red" }}>
                      {NumberOfStudentError && NumberOfStudentError.NumberOfStudent} 
                      </span>
                    </Form.Group>
                    <Form.Group controlId="formBasicContactNo">
                      <Form.Label>Contact Number</Form.Label>
                      <Form.Control
                        type="tel"
                        placeholder="Enter Contact Number"
                        value={ContactNumber}
                        onChange={(e) => {
                          setContactNumberError(null)
                          setContactNumber(e.target.value)
                        }}
                      />
                      <span style={{ color: "red" }}>
                        {ContactNumberError && ContactNumberError.ContactNumber}
                      </span>
                    </Form.Group>
                    <Form.Group controlId="formBasicCountry">
                      <Form.Label>Country</Form.Label>
                      <Form.Control as="select" onChange={(e)=> {console.log(e)
                                setCountry(e.target.value)}}>                      
                          {SelectCountry.length > 0 ? SelectCountry.map((t) => {
                            return(
                              <option value={t} >{t}</option>
                            )
                          }):null
                          }
                      <span style={{ color: "red" }}>
                        {CountryObjError && CountryObjError.CountryObj}
                      </span>
                      </Form.Control>
                    </Form.Group>
                    <Form.Group controlId="formBasicEmail">
                      <Form.Label>Email address</Form.Label>
                      <Form.Control
                        onChange={(e) => {
                          setEmailError(null)
                          setEmail(e.target.value)}}
                        type="email"
                        placeholder="Enter email"
                        value={email}
  
                      />
                      <span style={{ color: "red" }}>{emailError && emailError.email}</span>
                    </Form.Group>
                    <Row className="mb-3">
                    <Form.Group as={Col} controlId="formBasicFee">
                      <Form.Label>Fee</Form.Label>
                     
                      <Form.Control
                        value={Fee}
                        onChange={(e) => {
                          setFeeError(null)
                          setFee(e.target.value)}}
                        type="number"
                        placeholder="Enter Fee"
                      />
                     
                      <span style={{ color: "red" }}>
                        {feeError && feeError.Fee}
                      </span>
                      
                     
                    </Form.Group>
                    <Form.Group as={Col}>
                    <Form.Label>Currency</Form.Label>
                    <Form.Control
            as="select"
          >
            <option value="DICTUM">PKR</option>
            <option value="CONSTANCY">USD</option>
            <option value="COMPLEMENT">POUND</option>
          </Form.Control>
      </Form.Group>
                    </Row>
                    <Form.Group controlId="formBasicFeeDate">
                      <Form.Label>Fee Date</Form.Label>
                      <Form.Control
                        value={FeeDate}
                        onChange={(e) => {
                          setFeeDateError(null)
                          setFeeDate(e.target.value)}}
                        type="number"
                        placeholder="Enter Fee Date"
                        max="30"
                      />
                      <span style={{ color: "red" }}>
                        {feeDateError && feeDateError.FeeDate}
                      </span>
                    </Form.Group>
                    <Form.Group controlId="formBasicNoOfClasses">
                      <Form.Label>Number of Classes</Form.Label>
                      <Form.Control
                        type="number"
                        placeholder="Enter Number of Classes"
                        value={NumberofClasses}
                        onChange={(e) => {
                          setNumberOfClassesError(null)
                          setNumberofClasses(e.target.value)}}
                      />
                      <span style={{ color: "red" }}>
                        {NumberofClassesError && NumberofClassesError.NumberofClasses}
                      </span>
                    </Form.Group>
                    <div className="d-flex gap-2">
                      <Button
                        className=""
                        color="primary"
                        variant="contained"
                        type="submit"
                      >
                        Submit
                      </Button>
          
                      <Button
                        className=""
                        color="secondary"
                        variant="contained"
                        type="submit"
                        onClick={ClickBack}
                      >
                        Back
                      </Button>
                    </div>
  
                  </Form>
                </Paper>
              </Col>
            </Row>
          </Container>
        </div>
      </>
    );
  };