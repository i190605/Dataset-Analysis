export function SelectPopover({
    opened,
    transitionProps = { transition: 'fade', duration: 0 },
    shadow,
    withinPortal,
    portalProps,
    children,
    __staticSelector,
    onDirectionChange,
    switchDirectionOnFlip,
    zIndex,
    dropdownPosition,
    positionDependencies = [],
    classNames,
    styles,
    unstyled,
    readOnly,
    variant,
  }: SelectPopoverProps) {
    return (
      <Popover
        unstyled={unstyled}
        classNames={classNames}
        styles={styles}
        width="target"
        withRoles={false}
        opened={opened}
        middlewares={{ flip: dropdownPosition === 'flip', shift: false }}
        position={dropdownPosition === 'flip' ? 'bottom' : dropdownPosition}
        positionDependencies={positionDependencies}
        zIndex={zIndex}
        __staticSelector={__staticSelector}
        withinPortal={withinPortal}
        portalProps={portalProps}
        transitionProps={transitionProps}
        shadow={shadow}
        disabled={readOnly}
        onPositionChange={(nextPosition) =>
          switchDirectionOnFlip &&
          onDirectionChange?.(nextPosition === 'top' ? 'column-reverse' : 'column')
        }
        variant={variant}
      >
        {children}
      </Popover>
    );
  }