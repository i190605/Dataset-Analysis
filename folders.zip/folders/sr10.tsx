const Playground: React.FC<PlaygroundProps> = props => {
    const { isSicpEditor } = props;
    const workspaceLocation: WorkspaceLocation = isSicpEditor ? 'sicp' : 'playground';
    const { isMobileBreakpoint } = useResponsive();
  
    const [deviceSecret, setDeviceSecret] = useState<string | undefined>();
    const location = useLocation();
    const navigate = useNavigate();
    const store = useStore<OverallState>();
    const searchParams = new URLSearchParams(location.search);
    const shouldAddDevice = searchParams.get('add_device');
  
    // Selectors and handlers migrated over from deprecated withRouter implementation
    const {
      editorTabs,
      editorSessionId,
      execTime,
      stepLimit,
      isEditorAutorun,
      isRunning,
      isDebugging,
      output,
      replValue,
      sideContentHeight,
      sharedbConnected,
      usingSubst,
      usingEnv,
      isFolderModeEnabled,
      activeEditorTabIndex,
      context: { chapter: playgroundSourceChapter, variant: playgroundSourceVariant }
    } = useTypedSelector(state => state.workspaces[workspaceLocation]);
    const fileSystem = useTypedSelector(state => state.fileSystem.inBrowserFileSystem);
    const { queryString, shortURL, persistenceFile, githubSaveInfo } = useTypedSelector(
      state => state.playground
    );
    const {
      sourceChapter: courseSourceChapter,
      sourceVariant: courseSourceVariant,
      googleUser: persistenceUser,
      githubOctokitObject
    } = useTypedSelector(state => state.session);
  
    const dispatch = useDispatch();
    const {
      handleChangeExecTime,
      handleChapterSelect,
      handleEditorValueChange,
      handleSetEditorBreakpoints,
      handleReplEval,
      handleReplOutputClear,
      handleUsingEnv,
      handleUsingSubst
    } = useMemo(() => {
      return {
        handleChangeExecTime: (execTime: number) =>
          dispatch(changeExecTime(execTime, workspaceLocation)),
        handleChapterSelect: (chapter: Chapter, variant: Variant) =>
          dispatch(chapterSelect(chapter, variant, workspaceLocation)),
        handleEditorValueChange: (editorTabIndex: number, newEditorValue: string) =>
          dispatch(updateEditorValue(workspaceLocation, editorTabIndex, newEditorValue)),
        handleSetEditorBreakpoints: (editorTabIndex: number, newBreakpoints: string[]) =>
          dispatch(setEditorBreakpoint(workspaceLocation, editorTabIndex, newBreakpoints)),
        handleReplEval: () => dispatch(evalRepl(workspaceLocation)),
        handleReplOutputClear: () => dispatch(clearReplOutput(workspaceLocation)),
        handleUsingEnv: (usingEnv: boolean) => dispatch(toggleUsingEnv(usingEnv, workspaceLocation)),
        handleUsingSubst: (usingSubst: boolean) =>
          dispatch(toggleUsingSubst(usingSubst, workspaceLocation))
      };
    }, [dispatch, workspaceLocation]);
  
    // Hide search query from URL to maintain an illusion of security. The device secret
    // is still exposed via the 'Referer' header when requesting external content (e.g. Google API fonts)
    if (shouldAddDevice && !deviceSecret) {
      setDeviceSecret(shouldAddDevice);
      navigate(location.pathname, { replace: true });
    }
  
    const [lastEdit, setLastEdit] = useState(new Date());
    const [isGreen, setIsGreen] = useState(false);
    const [selectedTab, setSelectedTab] = useState(
      shouldAddDevice ? SideContentType.remoteExecution : SideContentType.introduction
    );
    const [hasBreakpoints, setHasBreakpoints] = useState(false);
    const [sessionId, setSessionId] = useState(() =>
      initSession('playground', {
        // TODO: Hardcoded to make use of the first editor tab. Rewrite after editor tabs are added.
        editorValue: editorTabs[0]?.value ?? '',
        chapter: playgroundSourceChapter
      })
    );
  
    const remoteExecutionTab: SideContentTab = useMemo(
      () => makeRemoteExecutionTabFrom(deviceSecret, setDeviceSecret),
      [deviceSecret]
    );
  
    const usingRemoteExecution =
      useTypedSelector(state => !!state.session.remoteExecutionSession) && !isSicpEditor;
    // this is still used by remote execution (EV3)
    // specifically, for the editor Ctrl+B to work
    const externalLibraryName = useTypedSelector(
      state => state.workspaces.playground.externalLibrary
    );
  
    useEffect(() => {
      // When the editor session Id changes, then treat it as a new session.
      setSessionId(
        initSession('playground', {
          // TODO: Hardcoded to make use of the first editor tab. Rewrite after editor tabs are added.
          editorValue: editorTabs[0]?.value ?? '',
          chapter: playgroundSourceChapter
        })
      );
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [editorSessionId]);
  
    const hash = isSicpEditor ? props.initialEditorValueHash : location.hash;
  
    useEffect(() => {
      if (!hash) {
        // If not a accessing via shared link, use the Source chapter and variant in the current course
        if (courseSourceChapter && courseSourceVariant) {
          handleChapterSelect(courseSourceChapter, courseSourceVariant);
          // TODO: To migrate the state logic away from playgroundSourceChapter
          //       and playgroundSourceVariant into the language config instead
          const languageConfig = getLanguageConfig(courseSourceChapter, courseSourceVariant);
          // Hardcoded for Playground only for now, while we await workspace refactoring
          // to decouple the SicpWorkspace from the Playground.
          dispatch(playgroundConfigLanguage(languageConfig));
          // Disable Folder mode when forcing the Source chapter and variant to follow the current course's.
          // This is because Folder mode only works in Source 2+.
          dispatch(setFolderMode(workspaceLocation, false));
        }
        return;
      }
      handleHash(
        hash,
        { handleChangeExecTime, handleChapterSelect },
        workspaceLocation,
        dispatch,
        fileSystem
      );
    }, [
      dispatch,
      fileSystem,
      hash,
      courseSourceChapter,
      courseSourceVariant,
      workspaceLocation,
      handleChapterSelect,
      handleChangeExecTime
    ]);
  
    /**
     * Handles toggling of relevant SideContentTabs when mobile breakpoint it hit
     */
    useEffect(() => {
      if (isMobileBreakpoint && desktopOnlyTabIds.includes(selectedTab)) {
        setSelectedTab(SideContentType.mobileEditor);
      } else if (!isMobileBreakpoint && mobileOnlyTabIds.includes(selectedTab)) {
        setSelectedTab(SideContentType.introduction);
      }
    }, [isMobileBreakpoint, selectedTab]);
  
    const handlers = useMemo(
      () => ({
        goGreen: () => setIsGreen(!isGreen)
      }),
      [isGreen]
    );
  
    const onEditorValueChange = React.useCallback(
      (editorTabIndex: number, newEditorValue: string) => {
        setLastEdit(new Date());
        handleEditorValueChange(editorTabIndex, newEditorValue);
      },
      [handleEditorValueChange]
    );
  
    const handleEnvVisualiserReset = useCallback(() => {
      handleUsingEnv(false);
      EnvVisualizer.clearEnv();
      dispatch(updateEnvSteps(-1, workspaceLocation));
      dispatch(updateEnvStepsTotal(0, workspaceLocation));
      dispatch(toggleUpdateEnv(true, workspaceLocation));
      dispatch(setEditorHighlightedLines(workspaceLocation, 0, []));
    }, [dispatch, workspaceLocation, handleUsingEnv]);
  
    const onChangeTabs = useCallback(
      (
        newTabId: SideContentType,
        prevTabId: SideContentType,
        event: React.MouseEvent<HTMLElement>
      ) => {
        if (newTabId === prevTabId) {
          return;
        }
  
        // Do nothing when clicking the mobile 'Run' tab while on the stepper tab.
        if (
          prevTabId === SideContentType.substVisualizer &&
          newTabId === SideContentType.mobileEditorRun
        ) {
          return;
        }
  
        if (newTabId !== SideContentType.envVisualizer) {
          handleEnvVisualiserReset();
        }
  
        if (
          isSourceLanguage(playgroundSourceChapter) &&
          (newTabId === SideContentType.substVisualizer || newTabId === SideContentType.envVisualizer)
        ) {
          if (playgroundSourceChapter <= Chapter.SOURCE_2) {
            handleUsingSubst(true);
          } else {
            handleUsingEnv(true);
          }
        }
  
        if (prevTabId === SideContentType.substVisualizer && !hasBreakpoints) {
          handleReplOutputClear();
          handleUsingSubst(false);
        }
  
        setSelectedTab(newTabId);
      },
      [
        hasBreakpoints,
        handleEnvVisualiserReset,
        playgroundSourceChapter,
        handleUsingSubst,
        handleUsingEnv,
        handleReplOutputClear
      ]
    );
  
    const pushLog = useCallback(
      (newInput: Input) => {
        log(sessionId, newInput);
      },
      [sessionId]
    );
  
    const autorunButtonHandlers = useMemo(() => {
      return {
        handleEditorEval: () => dispatch(evalEditor(workspaceLocation)),
        handleInterruptEval: () => dispatch(beginInterruptExecution(workspaceLocation)),
        handleToggleEditorAutorun: () => dispatch(toggleEditorAutorun(workspaceLocation)),
        handleDebuggerPause: () => dispatch(beginDebuggerPause(workspaceLocation)),
        handleDebuggerReset: () => dispatch(debuggerReset(workspaceLocation)),
        handleDebuggerResume: () => dispatch(debuggerResume(workspaceLocation))
      };
    }, [dispatch, workspaceLocation]);
  
    const languageConfig: SALanguage = useTypedSelector(state => state.playground.languageConfig);
  
    const autorunButtons = useMemo(() => {
      return (
        <ControlBarAutorunButtons
          isEntrypointFileDefined={activeEditorTabIndex !== null}
          isDebugging={isDebugging}
          isEditorAutorun={isEditorAutorun}
          isRunning={isRunning}
          key="autorun"
          autorunDisabled={usingRemoteExecution}
          sourceChapter={languageConfig.chapter}
          // Disable pause for non-Source languages since they cannot be paused
          pauseDisabled={usingRemoteExecution || !isSourceLanguage(languageConfig.chapter)}
          {...autorunButtonHandlers}
        />
      );
    }, [
      activeEditorTabIndex,
      isDebugging,
      isEditorAutorun,
      isRunning,
      languageConfig.chapter,
      autorunButtonHandlers,
      usingRemoteExecution
    ]);
  
    const chapterSelectHandler = useCallback(
      (sublanguage: SALanguage, e: any) => {
        const { chapter, variant } = sublanguage;
        if ((chapter <= 2 && hasBreakpoints) || selectedTab === SideContentType.substVisualizer) {
          handleUsingSubst(true);
        }
        if (chapter > 2) {
          handleReplOutputClear();
          handleUsingSubst(false);
        }
  
        const input: Input = {
          time: Date.now(),
          type: 'chapterSelect',
          data: chapter
        };
  
        pushLog(input);
  
        handleChapterSelect(chapter, variant);
        // Hardcoded for Playground only for now, while we await workspace refactoring
        // to decouple the SicpWorkspace from the Playground.
        dispatch(playgroundConfigLanguage(sublanguage));
      },
      [
        dispatch,
        hasBreakpoints,
        selectedTab,
        pushLog,
        handleReplOutputClear,
        handleUsingSubst,
        handleChapterSelect
      ]
    );
  
    const chapterSelectButton = useMemo(
      () => (
        <ControlBarChapterSelect
          handleChapterSelect={chapterSelectHandler}
          isFolderModeEnabled={isFolderModeEnabled}
          sourceChapter={languageConfig.chapter}
          sourceVariant={languageConfig.variant}
          key="chapter"
          disabled={usingRemoteExecution}
        />
      ),
      [
        chapterSelectHandler,
        isFolderModeEnabled,
        languageConfig.chapter,
        languageConfig.variant,
        usingRemoteExecution
      ]
    );
  
    const clearButton = useMemo(
      () =>
        selectedTab === SideContentType.substVisualizer ? null : (
          <ControlBarClearButton handleReplOutputClear={handleReplOutputClear} key="clear_repl" />
        ),
      [handleReplOutputClear, selectedTab]
    );
  
    const evalButton = useMemo(
      () =>
        selectedTab === SideContentType.substVisualizer ? null : (
          <ControlBarEvalButton
            handleReplEval={handleReplEval}
            isRunning={isRunning}
            key="eval_repl"
          />
        ),
      [handleReplEval, isRunning, selectedTab]
    );
  
    // Compute this here to avoid re-rendering the button every keystroke
    const persistenceIsDirty =
      persistenceFile && (!persistenceFile.lastSaved || persistenceFile.lastSaved < lastEdit);
    const persistenceButtons = useMemo(() => {
      return (
        <ControlBarGoogleDriveButtons
          isFolderModeEnabled={isFolderModeEnabled}
          currentFile={persistenceFile}
          loggedInAs={persistenceUser}
          isDirty={persistenceIsDirty}
          key="googledrive"
          onClickSaveAs={() => dispatch(persistenceSaveFileAs())}
          onClickOpen={() => dispatch(persistenceOpenPicker())}
          onClickSave={
            persistenceFile ? () => dispatch(persistenceSaveFile(persistenceFile)) : undefined
          }
          onClickLogOut={() => dispatch(logoutGoogle())}
          onPopoverOpening={() => dispatch(persistenceInitialise())}
        />
      );
    }, [isFolderModeEnabled, persistenceFile, persistenceUser, persistenceIsDirty, dispatch]);
  
    const githubPersistenceIsDirty =
      githubSaveInfo && (!githubSaveInfo.lastSaved || githubSaveInfo.lastSaved < lastEdit);
    const githubButtons = useMemo(() => {
      return (
        <ControlBarGitHubButtons
          key="github"
          isFolderModeEnabled={isFolderModeEnabled}
          loggedInAs={githubOctokitObject.octokit}
          githubSaveInfo={githubSaveInfo}
          isDirty={githubPersistenceIsDirty}
          onClickOpen={() => dispatch(githubOpenFile())}
          onClickSaveAs={() => dispatch(githubSaveFileAs())}
          onClickSave={() => dispatch(githubSaveFile())}
          onClickLogIn={() => dispatch(loginGitHub())}
          onClickLogOut={() => dispatch(logoutGitHub())}
        />
      );
    }, [
      dispatch,
      githubOctokitObject.octokit,
      githubPersistenceIsDirty,
      githubSaveInfo,
      isFolderModeEnabled
    ]);
  
    const executionTime = useMemo(
      () => (
        <ControlBarExecutionTime
          execTime={execTime}
          handleChangeExecTime={handleChangeExecTime}
          key="execution_time"
        />
      ),
      [execTime, handleChangeExecTime]
    );
  
    const stepperStepLimit = useMemo(
      () => (
        <ControlBarStepLimit
          stepLimit={stepLimit}
          stepSize={usingSubst ? 2 : 1}
          handleChangeStepLimit={limit => {
            dispatch(changeStepLimit(limit, workspaceLocation));
            usingEnv && dispatch(toggleUpdateEnv(true, workspaceLocation));
          }}
          handleOnBlurAutoScale={limit => {
            limit % 2 === 0 || !usingSubst
              ? dispatch(changeStepLimit(limit, workspaceLocation))
              : dispatch(changeStepLimit(limit + 1, workspaceLocation));
            usingEnv && dispatch(toggleUpdateEnv(true, workspaceLocation));
          }}
          key="step_limit"
        />
      ),
      [dispatch, stepLimit, usingSubst, usingEnv, workspaceLocation]
    );
  
    const getEditorValue = useCallback(
      // TODO: Hardcoded to make use of the first editor tab. Rewrite after editor tabs are added.
      () => store.getState().workspaces[workspaceLocation].editorTabs[0].value,
      [store, workspaceLocation]
    );
  
    const sessionButtons = useMemo(
      () => (
        <ControlBarSessionButtons
          isFolderModeEnabled={isFolderModeEnabled}
          editorSessionId={editorSessionId}
          getEditorValue={getEditorValue}
          handleSetEditorSessionId={id => dispatch(setEditorSessionId(workspaceLocation, id))}
          sharedbConnected={sharedbConnected}
          key="session"
        />
      ),
      [
        dispatch,
        getEditorValue,
        isFolderModeEnabled,
        editorSessionId,
        sharedbConnected,
        workspaceLocation
      ]
    );
  
    const shareButton = useMemo(() => {
      const qs = isSicpEditor ? Links.playground + '#' + props.initialEditorValueHash : queryString;
      return (
        <ControlBarShareButton
          handleGenerateLz={() => dispatch(generateLzString())}
          handleShortenURL={s => dispatch(shortenURL(s))}
          handleUpdateShortURL={s => dispatch(updateShortURL(s))}
          queryString={qs}
          shortURL={shortURL}
          isSicp={isSicpEditor}
          key="share"
        />
      );
    }, [dispatch, isSicpEditor, props.initialEditorValueHash, queryString, shortURL]);
  
    const toggleFolderModeButton = useMemo(() => {
      return (
        <ControlBarToggleFolderModeButton
          isFolderModeEnabled={isFolderModeEnabled}
          isSessionActive={editorSessionId !== ''}
          isPersistenceActive={persistenceFile !== undefined || githubSaveInfo.repoName !== ''}
          toggleFolderMode={() => dispatch(toggleFolderMode(workspaceLocation))}
          key="folder"
        />
      );
    }, [
      dispatch,
      githubSaveInfo.repoName,
      isFolderModeEnabled,
      persistenceFile,
      editorSessionId,
      workspaceLocation
    ]);
  
    useEffect(() => {
      // TODO: To migrate the state logic away from playgroundSourceChapter
      //       and playgroundSourceVariant into the language config instead
      const languageConfigToSet = getLanguageConfig(playgroundSourceChapter, playgroundSourceVariant);
      // Hardcoded for Playground only for now, while we await workspace refactoring
      // to decouple the SicpWorkspace from the Playground.
      dispatch(playgroundConfigLanguage(languageConfigToSet));
    }, [dispatch, playgroundSourceChapter, playgroundSourceVariant]);
  
    const shouldShowDataVisualizer = languageConfig.supports.dataVisualizer;
    const shouldShowEnvVisualizer = languageConfig.supports.envVisualizer;
    const shouldShowSubstVisualizer = languageConfig.supports.substVisualizer;
  
    const playgroundIntroductionTab: SideContentTab = useMemo(
      () => makeIntroductionTabFrom(generateLanguageIntroduction(languageConfig)),
      [languageConfig]
    );
    const tabs = useMemo(() => {
      const tabs: SideContentTab[] = [playgroundIntroductionTab];
  
      const currentLang = languageConfig.chapter;
      if (currentLang === Chapter.HTML) {
        // For HTML Chapter, HTML Display tab is added only after code is run
        if (output.length > 0 && output[0].type === 'result') {
          tabs.push(
            makeHtmlDisplayTabFrom(output[0] as ResultOutput, errorMsg =>
              dispatch(addHtmlConsoleError(errorMsg, workspaceLocation))
            )
          );
        }
        return tabs;
      }
  
      if (!usingRemoteExecution) {
        // Don't show the following when using remote execution
        if (shouldShowDataVisualizer) {
          tabs.push(dataVisualizerTab);
        }
        if (shouldShowEnvVisualizer) {
          tabs.push(makeEnvVisualizerTabFrom(workspaceLocation));
        }
        if (shouldShowSubstVisualizer) {
          tabs.push(makeSubstVisualizerTabFrom(output));
        }
      }
  
      if (!isSicpEditor) {
        tabs.push(remoteExecutionTab);
      }
  
      return tabs;
    }, [
      playgroundIntroductionTab,
      languageConfig.chapter,
      output,
      usingRemoteExecution,
      isSicpEditor,
      dispatch,
      workspaceLocation,
      shouldShowDataVisualizer,
      shouldShowEnvVisualizer,
      shouldShowSubstVisualizer,
      remoteExecutionTab
    ]);
  
    // Remove Intro and Remote Execution tabs for mobile
    const mobileTabs = [...tabs].filter(({ id }) => !(id && desktopOnlyTabIds.includes(id)));
  
    const onLoadMethod = useCallback(
      (editor: Ace.Editor) => {
        const addFold = () => {
          editor.getSession().addFold('    ', new Range(1, 0, props.prependLength!, 0));
          editor.renderer.off('afterRender', addFold);
        };
  
        editor.renderer.on('afterRender', addFold);
      },
      [props.prependLength]
    );
  
    const onChangeMethod = useCallback(
      (newCode: string, delta: CodeDelta) => {
        const input: Input = {
          time: Date.now(),
          type: 'codeDelta',
          data: delta
        };
  
        pushLog(input);
        dispatch(toggleUpdateEnv(true, workspaceLocation));
        dispatch(setEditorHighlightedLines(workspaceLocation, 0, []));
      },
      [pushLog, dispatch, workspaceLocation]
    );
  
    const onCursorChangeMethod = useCallback(
      (selection: any) => {
        const input: Input = {
          time: Date.now(),
          type: 'cursorPositionChange',
          data: selection.getCursor()
        };
  
        pushLog(input);
      },
      [pushLog]
    );
  
    const onSelectionChangeMethod = useCallback(
      (selection: any) => {
        const range: SelectionRange = selection.getRange();
        const isBackwards: boolean = selection.isBackwards();
        if (!isEqual(range.start, range.end)) {
          const input: Input = {
            time: Date.now(),
            type: 'selectionRangeData',
            data: { range, isBackwards }
          };
  
          pushLog(input);
        }
      },
      [pushLog]
    );
  
    const handleEditorUpdateBreakpoints = useCallback(
      (editorTabIndex: number, breakpoints: string[]) => {
        // get rid of holes in array
        const numberOfBreakpoints = breakpoints.filter(arrayItem => !!arrayItem).length;
        if (numberOfBreakpoints > 0) {
          setHasBreakpoints(true);
          if (playgroundSourceChapter <= 2) {
            /**
             * There are breakpoints set on Source Chapter 2, so we set the
             * Redux state for the editor to evaluate to the substituter
             */
  
            handleUsingSubst(true);
          }
        }
        if (numberOfBreakpoints === 0) {
          setHasBreakpoints(false);
  
          if (selectedTab !== SideContentType.substVisualizer) {
            handleReplOutputClear();
            handleUsingSubst(false);
          }
        }
        handleSetEditorBreakpoints(editorTabIndex, breakpoints);
        dispatch(toggleUpdateEnv(true, workspaceLocation));
      },
      [
        selectedTab,
        dispatch,
        workspaceLocation,
        handleSetEditorBreakpoints,
        handleReplOutputClear,
        handleUsingSubst,
        playgroundSourceChapter
      ]
    );
  
    const replDisabled = !languageConfig.supports.repl || usingRemoteExecution;
  
    const editorContainerHandlers = useMemo(() => {
      return {
        handleDeclarationNavigate: (cursorPosition: Position) =>
          dispatch(navigateToDeclaration(workspaceLocation, cursorPosition)),
        handlePromptAutocomplete: (row: number, col: number, callback: any) =>
          dispatch(promptAutocomplete(workspaceLocation, row, col, callback)),
        handleSendReplInputToOutput: (code: string) =>
          dispatch(sendReplInputToOutput(code, workspaceLocation)),
        handleSetSharedbConnected: (connected: boolean) =>
          dispatch(setSharedbConnected(workspaceLocation, connected)),
        setActiveEditorTabIndex: (activeEditorTabIndex: number | null) =>
          dispatch(updateActiveEditorTabIndex(workspaceLocation, activeEditorTabIndex)),
        removeEditorTabByIndex: (editorTabIndex: number) =>
          dispatch(removeEditorTab(workspaceLocation, editorTabIndex))
      };
    }, [dispatch, workspaceLocation]);
    const editorContainerProps: NormalEditorContainerProps = {
      editorSessionId,
      isEditorAutorun,
      editorVariant: 'normal',
      baseFilePath: WORKSPACE_BASE_PATHS[workspaceLocation],
      isFolderModeEnabled,
      activeEditorTabIndex,
      setActiveEditorTabIndex: editorContainerHandlers.setActiveEditorTabIndex,
      removeEditorTabByIndex: editorContainerHandlers.removeEditorTabByIndex,
      editorTabs: editorTabs.map(convertEditorTabStateToProps),
      handleDeclarationNavigate: editorContainerHandlers.handleDeclarationNavigate,
      handleEditorEval: autorunButtonHandlers.handleEditorEval,
      handlePromptAutocomplete: editorContainerHandlers.handlePromptAutocomplete,
      handleSendReplInputToOutput: editorContainerHandlers.handleSendReplInputToOutput,
      handleSetSharedbConnected: editorContainerHandlers.handleSetSharedbConnected,
      onChange: onChangeMethod,
      onCursorChange: onCursorChangeMethod,
      onSelectionChange: onSelectionChangeMethod,
      onLoad: isSicpEditor && props.prependLength ? onLoadMethod : undefined,
      sourceChapter: languageConfig.chapter,
      externalLibraryName,
      sourceVariant: languageConfig.variant,
      handleEditorValueChange: onEditorValueChange,
      handleEditorUpdateBreakpoints: handleEditorUpdateBreakpoints
    };
  
    const replHandlers = useMemo(() => {
      return {
        handleBrowseHistoryDown: () => dispatch(browseReplHistoryDown(workspaceLocation)),
        handleBrowseHistoryUp: () => dispatch(browseReplHistoryUp(workspaceLocation)),
        handleReplValueChange: (newValue: string) =>
          dispatch(updateReplValue(newValue, workspaceLocation))
      };
    }, [dispatch, workspaceLocation]);
    const replProps = {
      output,
      replValue,
      handleReplEval,
      usingSubst,
      handleBrowseHistoryDown: replHandlers.handleBrowseHistoryDown,
      handleBrowseHistoryUp: replHandlers.handleBrowseHistoryUp,
      handleReplValueChange: replHandlers.handleReplValueChange,
      sourceChapter: languageConfig.chapter,
      sourceVariant: languageConfig.variant,
      externalLibrary: ExternalLibraryName.NONE, // temporary placeholder as we phase out libraries
      hidden:
        selectedTab === SideContentType.substVisualizer ||
        selectedTab === SideContentType.envVisualizer,
      inputHidden: replDisabled,
      replButtons: [replDisabled ? null : evalButton, clearButton],
      disableScrolling: isSicpEditor
    };
  
    const sideBarProps: { tabs: SideBarTab[] } = useMemo(() => {
      // The sidebar is rendered if and only if there is at least one tab present.
      // Because whether the sidebar is rendered or not affects the sidebar resizing
      // logic, we cannot defer the decision on which sidebar tabs should be rendered
      // to the sidebar as it would be too late - the sidebar resizing logic in the
      // workspace would not be able to act on that information. Instead, we need to
      // determine which sidebar tabs should be rendered here.
      return {
        tabs: [
          ...(isFolderModeEnabled
            ? [
                {
                  label: 'Folder',
                  body: (
                    <FileSystemView
                      workspaceLocation="playground"
                      basePath={WORKSPACE_BASE_PATHS[workspaceLocation]}
                    />
                  ),
                  iconName: IconNames.FOLDER_CLOSE,
                  id: SideContentType.folder
                }
              ]
            : [])
        ]
      };
    }, [isFolderModeEnabled, workspaceLocation]);
  
    const workspaceProps: WorkspaceProps = {
      controlBarProps: {
        editorButtons: [
          autorunButtons,
          languageConfig.chapter === Chapter.FULL_JS ? null : shareButton,
          chapterSelectButton,
          isSicpEditor ? null : sessionButtons,
          languageConfig.supports.multiFile ? toggleFolderModeButton : null,
          persistenceButtons,
          githubButtons,
          usingRemoteExecution || !isSourceLanguage(languageConfig.chapter)
            ? null
            : usingSubst || usingEnv
            ? stepperStepLimit
            : executionTime
        ]
      },
      editorContainerProps: editorContainerProps,
      handleSideContentHeightChange: useCallback(
        change => dispatch(changeSideContentHeight(change, workspaceLocation)),
        [dispatch, workspaceLocation]
      ),
      replProps: replProps,
      sideBarProps: sideBarProps,
      sideContentHeight: sideContentHeight,
      sideContentProps: {
        selectedTabId: selectedTab,
        onChange: onChangeTabs,
        tabs: {
          beforeDynamicTabs: tabs,
          afterDynamicTabs: []
        },
        workspaceLocation: workspaceLocation,
        sideContentHeight: sideContentHeight
      },
      sideContentIsResizeable:
        selectedTab !== SideContentType.substVisualizer &&
        selectedTab !== SideContentType.envVisualizer
    };
  
    const mobileWorkspaceProps: MobileWorkspaceProps = {
      editorContainerProps: editorContainerProps,
      replProps: replProps,
      sideBarProps: sideBarProps,
      mobileSideContentProps: {
        mobileControlBarProps: {
          editorButtons: [
            autorunButtons,
            chapterSelectButton,
            languageConfig.chapter === Chapter.FULL_JS ? null : shareButton,
            isSicpEditor ? null : sessionButtons,
            languageConfig.supports.multiFile ? toggleFolderModeButton : null,
            persistenceButtons,
            githubButtons
          ]
        },
        selectedTabId: selectedTab,
        onChange: onChangeTabs,
        tabs: {
          beforeDynamicTabs: mobileTabs,
          afterDynamicTabs: []
        },
        workspaceLocation: workspaceLocation
      }
    };
  
    return isMobileBreakpoint ? (
      <div className={classNames('Playground', Classes.DARK, isGreen ? 'GreenScreen' : undefined)}>
        <MobileWorkspace {...mobileWorkspaceProps} />
      </div>
    ) : (
      <HotKeys
        className={classNames('Playground', Classes.DARK, isGreen ? 'GreenScreen' : undefined)}
        keyMap={keyMap}
        handlers={handlers}
      >
        <Workspace {...workspaceProps} />
      </HotKeys>
    );
  };
  
  // react-router lazy loading
  // https://reactrouter.com/en/main/route/lazy
  export const Component = Playground;
  Component.displayName = 'Playground';
  