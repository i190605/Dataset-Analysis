const SourceBlock: React.FC<SourceBlockProps> = props => {
    const dispatch = useDispatch();
    const [code, setCode] = useState<string>(props.content);
    const [outputIndex, setOutputIndex] = useState(Infinity);
    const [selectedTab, setSelectedTab] = useState(SideContentType.storiesRun);
  
    const envList = useTypedSelector(store => Object.keys(store.stories.envs));
  
    // setting env
    const commandsEnv = parseMetadata('env', props.commands);
    const env =
      commandsEnv === undefined
        ? DEFAULT_ENV
        : envList.includes(commandsEnv)
        ? commandsEnv
        : DEFAULT_ENV;
  
    const chapter = useTypedSelector(
      store => store.stories.envs[env]?.context.chapter || Constants.defaultSourceChapter
    );
    const variant = useTypedSelector(
      store => store.stories.envs[env]?.context.variant || Constants.defaultSourceVariant
    );
  
    useEffect(() => {
      setCode(props.content);
    }, [props.content]);
  
    const output = useTypedSelector(store => store.stories.envs[env]?.output || []);
  
    const onChangeTabs = React.useCallback(
      (
        newTabId: SideContentType,
        prevTabId: SideContentType,
        event: React.MouseEvent<HTMLElement>
      ) => {
        // TODO: Migrate relevant updated logic from Playground component
        // TODO: Use language config for source chapter.
        dispatch(toggleStoriesUsingSubst(newTabId === SideContentType.substVisualizer, env));
  
        setSelectedTab(newTabId);
      },
      // eslint-disable-next-line react-hooks/exhaustive-deps
      []
    );
  
    const envDisplayLabel =
      env === DEFAULT_ENV
        ? styliseSublanguage(chapter, variant)
        : env + ' | ' + styliseSublanguage(chapter, variant);
  
    // TODO: Add env visualiser tabs and shift to language config
  
    // const envVisualizerTab: SideContentTab = {
    //   label: 'Env Visualizer',
    //   iconName: IconNames.GLOBE,
    //   body: <SideContentEnvVisualizer />,
    //   id: SideContentType.envVisualizer
    // };
  
    const usingSubst = selectedTab === SideContentType.substVisualizer;
    const outputTab: SideContentTab = {
      label: 'Normal Output',
      iconName: IconNames.PLAY,
      body:
        output.length > outputIndex ? (
          <div className="Repl" style={{ margin: 0 }}>
            <div className="repl-output-parent">
              <p className={Classes.RUNNING_TEXT}>Output:</p>
              <Output output={output[outputIndex]} usingSubst={usingSubst} />
            </div>
          </div>
        ) : (
          <p className={Classes.RUNNING_TEXT}>Click "Run" in the top left to run some code!</p>
        ),
      id: SideContentType.storiesRun
    };
  
    const tabs = React.useMemo(() => {
      const tabs: SideContentTab[] = [outputTab];
  
      // TODO: Restore logic post refactor
  
      // For HTML Chapter, HTML Display tab is added only after code is run
      if (chapter === Chapter.HTML) {
        if (output.length > outputIndex && output[outputIndex].type === 'result') {
          tabs.push(
            makeHtmlDisplayTabFrom(output[outputIndex] as ResultOutput, errorMsg =>
              dispatch(addHtmlConsoleError(errorMsg, 'stories', env))
            )
          );
        }
        return tabs;
      }
  
      // // (TEMP) Remove tabs for fullJS until support is integrated
      // if (chapter === Chapter.FULL_JS) {
      //   return [...tabs, dataVisualizerTab];
      // }
  
      if (chapter >= Chapter.SOURCE_2) {
        // Enable Data Visualizer for Source Chapter 2 and above
        tabs.push(dataVisualizerTab);
      }
      // if (chapter >= 3 && variant !== Variant.CONCURRENT && variant !== Variant.NON_DET) {
      //   // Enable Env Visualizer for Source Chapter 3 and above
      //   tabs.push(envVisualizerTab);
      // }
  
      if (
        chapter <= Chapter.SOURCE_2 &&
        (variant === Variant.DEFAULT || variant === Variant.NATIVE)
      ) {
        // Enable Subst Visualizer only for default Source 1 & 2
        tabs.push(makeSubstVisualizerTabFrom(output.slice(outputIndex)));
      }
  
      return tabs;
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [chapter, variant, output, dispatch, env]);
  
    const sideContentProps: StoriesSideContentProps = {
      selectedTabId: selectedTab,
      onChange: onChangeTabs,
      tabs: {
        beforeDynamicTabs: tabs,
        afterDynamicTabs: []
      },
      workspaceLocation: 'stories',
      getDebuggerContext: state => state.stories.envs[env].debuggerContext
    };
  
    const execEvaluate = () => {
      // We call onChangeTabs with the current tab when the run
      // button is clicked. This is a hotfix for incorrect execution
      // method because of the fact that execution logic is handled
      // by the environment setting, but the currently showing tab
      // is handled by the component setting.
      onChangeTabs(selectedTab, selectedTab, {} as any);
  
      dispatch(evalStory(env, code));
      setOutputIndex(output.length);
    };
  
    // needed so execeval will update on shift-enter
    const execRef = useRef(execEvaluate);
    execRef.current = execEvaluate;
  
    const execResetEnv = () => {
      dispatch(clearStoryEnv(env));
    };
  
    selectMode(chapter, variant, ExternalLibraryName.NONE);
  
    return (
      <div className={Classes.DARK}>
        <div className="workspace">
          <Card>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <ControlBarRunButton
                key="runButton"
                handleEditorEval={execEvaluate}
                isEntrypointFileDefined
              />
              <span style={{ display: 'inline-block', fontSize: '0.9rem', textAlign: 'center' }}>
                {envDisplayLabel}
              </span>
              <ControlButton label="Reset Env" onClick={execResetEnv} icon={IconNames.RESET} />
            </div>
            <div>
              <div className="right-parent">
                <Card>
                  <AceEditor
                    className="repl-react-ace react-ace"
                    mode={getModeString(chapter, variant, ExternalLibraryName.NONE)}
                    theme="source"
                    height="1px"
                    width="100%"
                    value={code}
                    onChange={code => setCode(code)}
                    commands={[
                      {
                        name: 'evaluate',
                        bindKey: {
                          win: 'Shift-Enter',
                          mac: 'Shift-Enter'
                        },
                        exec: () => execRef.current()
                      }
                    ]}
                    minLines={5}
                    maxLines={20}
                    fontSize={17}
                    highlightActiveLine={false}
                    showGutter={false}
                    showPrintMargin={false}
                    setOptions={{
                      fontFamily: "'Inconsolata', 'Consolas', monospace"
                    }}
                  />
                </Card>
                <div>
                  <StoriesSideContent {...sideContentProps} />
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    );
  };
  