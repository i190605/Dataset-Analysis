class Bar extends React.Component {
    constructor() {
      super();
      instance = this;
    }
    shouldComponentUpdate() {
      return false;
    }
    render() {
      Scheduler.log('Bar');
      return <Baz />;
    }
  }

  function Foo() {
    Scheduler.log('Foo');
    return (
      <div>
        <Bar />
      </div>
    );
  }

  ReactNoop.render(<Foo />);
  await waitForAll(['Foo', 'Bar', 'Baz']);
  instance.forceUpdate();
  await waitForAll(['Bar', 'Baz']);

it('should clear forceUpdate after update is flushed', async () => {
  let a = 0;

  class Foo extends React.PureComponent {
    render() {
      const msg = `A: ${a}, B: ${this.props.b}`;
      Scheduler.log(msg);
      return msg;
    }
  }

  const foo = React.createRef(null);
  ReactNoop.render(<Foo ref={foo} b={0} />);
  await waitForAll(['A: 0, B: 0']);

  a = 1;
  foo.current.forceUpdate();
  await waitForAll(['A: 1, B: 0']);

  ReactNoop.render(<Foo ref={foo} b={0} />);
  await waitForAll([]);
});

xit('can call sCU while resuming a partly mounted component', () => {
  const instances = new Set();

  class Bar extends React.Component {
    state = {y: 'A'};
    constructor() {
      super();
      instances.add(this);
    }
    shouldComponentUpdate(newProps, newState) {
      return this.props.x !== newProps.x || this.state.y !== newState.y;
    }
    render() {
      Scheduler.log('Bar:' + this.props.x);
      return <span prop={String(this.props.x === this.state.y)} />;
    }
  }

  function Foo(props) {
    Scheduler.log('Foo');
    return [
      <Bar key="a" x="A" />,
      <Bar key="b" x={props.step === 0 ? 'B' : 'B2'} />,
      <Bar key="c" x="C" />,
      <Bar key="d" x="D" />,
    ];
  }

  ReactNoop.render(<Foo step={0} />);
  ReactNoop.flushDeferredPri(40);
  assertLog(['Foo', 'Bar:A', 'Bar:B', 'Bar:C']);

  expect(instances.size).toBe(3);

  ReactNoop.render(<Foo step={1} />);
  ReactNoop.flushDeferredPri(50);
  // A was memoized and reused. B was memoized but couldn't be reused because
  // props differences. C was memoized and reused. D never even started so it
  // needed a new instance.
  assertLog(['Foo', 'Bar:B2', 'Bar:D']);

  // We expect each rerender to correspond to a new instance.
  expect(instances.size).toBe(4);
});
