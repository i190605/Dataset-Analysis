export function DropzoneFullScreen(props: DropzoneFullScreenProps) {
    const {
      classNames,
      styles,
      sx,
      className,
      style,
      unstyled,
      active,
      onDrop,
      onReject,
      zIndex,
      withinPortal,
      portalProps,
      ...others
    } = useComponentDefaultProps('DropzoneFullScreen', fullScreenDefaultProps, props);
  
    const [counter, setCounter] = React.useState(0);
    const [visible, { open, close }] = useDisclosure(false);
    const { classes, cx } = useFullScreenStyles(null, {
      name: 'DropzoneFullScreen',
      classNames,
      styles,
      unstyled,
    });
  
    const handleDragEnter = (event: DragEvent) => {
      if (event.dataTransfer.types.includes('Files')) {
        setCounter((prev) => prev + 1);
        open();
      }
    };
  
    const handleDragLeave = () => {
      setCounter((prev) => prev - 1);
    };
  
    useEffect(() => {
      counter === 0 && close();
    }, [counter]);
  
    useEffect(() => {
      if (!active) return undefined;
  
      document.addEventListener('dragenter', handleDragEnter, false);
      document.addEventListener('dragleave', handleDragLeave, false);
  
      return () => {
        document.removeEventListener('dragenter', handleDragEnter, false);
        document.removeEventListener('dragleave', handleDragLeave, false);
      };
    }, [active]);
  
    return (
      <OptionalPortal {...portalProps} withinPortal={withinPortal}>
        <Box
          className={cx(classes.wrapper, className)}
          sx={sx}
          style={{
            ...style,
            opacity: visible ? 1 : 0,
            pointerEvents: visible ? 'all' : 'none',
            zIndex,
          }}
        >
          <_Dropzone
            {...others}
            classNames={classNames}
            styles={styles}
            unstyled={unstyled}
            className={classes.dropzone}
            onDrop={(files: any) => {
              onDrop?.(files);
              close();
            }}
            onReject={(files: any) => {
              onReject?.(files);
              close();
            }}
          />
        </Box>
      </OptionalPortal>
    );
  }
  