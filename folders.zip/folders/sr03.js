
    handleRef = ref => {
      if (ref !== this.iframeRef) {
        this.iframeRef = ref;
        if (ref) {
          if (ref.contentDocument && this.props.head) {
            ref.contentDocument.head.innerHTML = this.props.head;
          }
          // Re-render must take place in the next tick (Firefox)
          setTimeout(() => {
            this.forceUpdate();
          });
        }
      }
    };

