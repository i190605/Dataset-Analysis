
class UncontrolledBlogPostEditor extends Component {
  constructor(props) {
    super(props);
    this.titleInputRef = React.createRef();
    this.contentInputRef = React.createRef();
  }

  handleSavePost = () => {
    const title = this.titleInputRef.current.value;
    const content = this.contentInputRef.current.value;
    // Simulate saving the blog post to a server.
    alert(`Saved Blog Post: Title - ${title}, Content - ${content}`);
  }

  render() {
    return (
      <div>
        <h2>Blog Post Editor</h2>
        <div>
          <label>Title:</label>
          <input type="text" ref={this.titleInputRef} />
        </div>
        <div>
          <label>Content:</label>
          <textarea ref={this.contentInputRef} />
        </div>
        <div>
          <button onClick={this.handleSavePost}>Save</button>
        </div>
      </div>
    );
  }
}
