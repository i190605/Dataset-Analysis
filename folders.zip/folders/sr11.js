function Child() {
    if (suspend) {
      throw promise;
    } else {
      return <input ref={innerRef} />;
    }
  }
