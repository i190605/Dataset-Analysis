import React, { Component } from 'react';

class UncontrolledTable extends Component {
  constructor(props) {
    super(props);
    this.tableRef = React.createRef();
  }

  handleSortColumn = (columnIndex) => {
    // Sort the table by the selected column.
    const table = this.tableRef.current;
    const rows = Array.from(table.querySelectorAll('tbody tr'));
    rows.sort((rowA, rowB) => {
      const cellA = rowA.querySelectorAll('td')[columnIndex].textContent;
      const cellB = rowB.querySelectorAll('td')[columnIndex].textContent;
      return cellA.localeCompare(cellB);
    });
    rows.forEach((row) => table.querySelector('tbody').appendChild(row));
  }

  render() {
    return (
      <div>
        <table ref={this.tableRef}>
          <thead>
            <tr>
              <th onClick={() => this.handleSortColumn(0)}>Name</th>
              <th onClick={() => this.handleSortColumn(1)}>Age</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Alice</td>
              <td>28</td>
            </tr>
            <tr>
              <td>Bob</td>
              <td>22</td>
            </tr>
            {/* More rows */}
          </tbody>
        </table>
      </div>
    );
  }
}
