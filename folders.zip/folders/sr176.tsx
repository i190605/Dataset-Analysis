export function ActionsList({
    actions,
    styles,
    classNames,
    actionComponent: Action,
    hovered,
    onActionTrigger,
    query,
    nothingFoundMessage,
    highlightQuery,
    highlightColor,
    radius,
    variant,
    ...others
  }: ActionsListProps) {
    const { classes } = useStyles(null, { name: 'Spotlight', classNames, styles, variant });
  
    const items = actions.map((item) => {
      if (item.type === 'item') {
        return (
          <Action
            query={query}
            key={item.item.id}
            action={item.item}
            hovered={item.index === hovered}
            classNames={classNames}
            styles={styles}
            radius={radius}
            onTrigger={() => onActionTrigger(item.item)}
            highlightQuery={highlightQuery}
            highlightColor={highlightColor}
          />
        );
      }
  
      return (
        <Text className={classes.actionsGroup} color="dimmed" key={item.label}>
          {item.label}
        </Text>
      );
    });
  
    const shouldRenderActions =
      items.length > 0 || (!!nothingFoundMessage && query.trim().length > 0);
  
    return (
      <>
        {shouldRenderActions && (
          <div className={classes.actions} {...others}>
            {items.length > 0 ? (
              items
            ) : (
              <Text c="dimmed" className={classes.nothingFound} ta="center" fz="lg" py="md">
                {nothingFoundMessage}
              </Text>
            )}
          </div>
        )}
      </>
    );
  }