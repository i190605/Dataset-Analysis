export const MemexIssueOverlay = () => {
    const [overlayOpen, setOverlayOpen] = React.useState(false)
    const linkRef = useRef<HTMLAnchorElement>(null)
    const inputRef = useRef<HTMLInputElement>(null)
    const buttonRef = useRef<HTMLButtonElement>(null)
  
    const [title, setTitle] = React.useState('Implement draft issue editor')
    const [editing, setEditing] = React.useState(false)
  
    React.useEffect(() => {
      // If we just started editing, focus the newly rendered input
      if (editing) inputRef.current?.focus()
    }, [editing])
  
    return (
      <>
        <Link
          href="#"
          muted
          ref={linkRef}
          onClick={event => {
            event.preventDefault()
            setOverlayOpen(true)
          }}
          sx={{
            display: 'block',
            border: '1px solid',
            borderColor: 'border.default',
            p: 2,
            ':hover': {
              backgroundColor: 'canvas.subtle',
            },
          }}
        >
          <IssueDraftIcon /> {title}
        </Link>
        {overlayOpen && (
          <Overlay
            height="auto"
            width="large"
            onEscape={() => setOverlayOpen(false)}
            onClickOutside={() => setOverlayOpen(false)}
            returnFocusRef={linkRef}
            top={0}
            left="calc(100vw - 480px)"
          >
            <Box sx={{p: 4, height: '100vh'}}>
              <Box sx={{display: 'flex', alignItems: 'center', gap: 1, mb: 2}}>
                <Label size="large">
                  <IssueDraftIcon /> Draft
                </Label>
                <Text sx={{fontSize: 1}}>opened 2 days ago,</Text>
                <Text sx={{fontSize: 1}}>showing {editing ? 'input' : 'button'}</Text>
              </Box>
              {editing ? (
                <TextInput
                  defaultValue={title}
                  onBlur={(event: React.FocusEvent<HTMLInputElement>) => {
                    setEditing(false)
                    setTitle(event.target.value)
                  }}
                  onKeyDown={(event: React.KeyboardEvent<HTMLInputElement>) => {
                    if (event.key === 'Enter') {
                      setEditing(false)
                      setTitle((event.target as HTMLInputElement).value)
                    } else if (event.key === 'Escape') {
                      setEditing(false)
                      setTitle(title)
                      event.preventDefault() // prevent Overlay from closing, this is what we recommend
                      // event.stopPropagation() // this also works and feels nicer to use
                    }
                  }}
                  ref={inputRef}
                  sx={{
                    width: '100%',
                    py: '2px',
                    px: '7px',
                    textAlign: 'left',
                    color: 'fg.default',
                    input: {fontWeight: 'bold', fontSize: 4, px: 0},
                  }}
                />
              ) : (
                <Button
                  variant="invisible"
                  ref={buttonRef}
                  onClick={() => setEditing(true)}
                  aria-label="Change issue title"
                  sx={{
                    width: '100%',
                    fontSize: 4,
                    color: 'fg.default',
                    p: 2,
                    textAlign: 'left',
                    borderRadius: '2',
                  }}
                >
                  {title}
                </Button>
              )}
            </Box>
          </Overlay>
        )}
      </>
    )
  }
  