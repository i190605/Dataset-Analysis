export function TabsProvider({
    defaultValue,
    value,
    onTabChange,
    orientation,
    children,
    loop,
    id,
    activateTabWithKeyboard,
    allowTabDeactivation,
    variant,
    color,
    radius,
    inverted,
    placement,
    keepMounted = true,
    classNames,
    styles,
    unstyled,
  }: _TabsProviderProps) {
    const uid = useId(id);
  
    const [mountedPanelIds, setMountedPanelIds] = useState([]);
  
    const [_value, onChange] = useUncontrolled<TabsValue>({
      value,
      defaultValue,
      finalValue: null,
      onChange: onTabChange,
    });
  
    return (
      <TabsContextProvider
        value={{
          placement,
          value: _value,
          orientation,
          id: uid,
          loop,
          activateTabWithKeyboard,
          getTabId: getSafeId(`${uid}-tab`, TABS_ERRORS.value),
          getPanelId: getSafeId(`${uid}-panel`, TABS_ERRORS.value),
          onTabChange: onChange,
          setMountedPanelIds,
          mountedPanelIds,
          allowTabDeactivation,
          variant,
          color,
          radius,
          inverted,
          keepMounted,
          classNames,
          styles,
          unstyled,
        }}
      >
        {children}
      </TabsContextProvider>
    );
  }
  