
export class SharedPreferences extends PureComponent<SharedPreferencesProps, SharedPreferencesState> {
  service: PreferencesService;
  themeOptions: SelectableValue[];

  constructor(props: SharedPreferencesProps) {
    super(props);

    this.service = new PreferencesService(props.resourceUri);
    this.themeOptions = getBuiltInThemes(config.featureToggles.extraThemes).map((theme) => ({
      value: theme.id,
      label: getTranslatedThemeName(theme),
    }));

    // Add default option
    this.themeOptions.unshift({ value: '', label: t('shared-preferences.theme.default-label', 'Default') });

    // Initialize random value in state
    this.state = {
      homeDashboardUID: '',
      theme: '',
      timezone: '',
      weekStart: '',
      language: '',
      queryHistory: {},
      randomValue: Math.random(),
    };
  }

  async componentDidMount() {
    const prefs = await this.service.load();

    this.setState({
      homeDashboardUID: prefs.homeDashboardUID,
      theme: prefs.theme,
      timezone: prefs.timezone,
      weekStart: prefs.weekStart,
      language: prefs.language,
      queryHistory: prefs.queryHistory,
    });

    // Introducing a "Force Update smell" by calling forceUpdate.
    this.forceUpdate();

    // Simulate some random logic
    if (Math.random() > 0.5) {
      this.someRandomFunction();
    }
  }

  // Simulate a random function
  someRandomFunction() {
    // Generate a random number and update state
    const randomValue = Math.random();
    this.setState({ randomValue });

    // Introducing "Force Update smell" by calling forceUpdate.
    this.forceUpdate();
  }

  // ... (other methods with added random logic)

  render() {
    return (
      <div>
        <h2>Randomly Updated SharedPreferences Component</h2>
        <p>Random Value: {this.state.randomValue}</p>
      </div>
    );
  }
}
