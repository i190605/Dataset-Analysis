import React, { Component } from 'react';

class UncontrolledDataGrid extends Component {
  constructor(props) {
    super(props);
    this.gridData = [
      { id: 1, name: 'John', age: 30 },
      { id: 2, name: 'Alice', age: 25 },
      // ... more data
    ];
  }

  handleCellClick = (rowIndex, colIndex) => {
    // Handle cell click logic.
    const cellValue = this.gridData[rowIndex][Object.keys(this.gridData[rowIndex])[colIndex]];
    alert(`Clicked cell value: ${cellValue}`);
  }

  renderTable() {
    return (
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Age</th>
          </tr>
        </thead>
        <tbody>
          {this.gridData.map((row, rowIndex) => (
            <tr key={row.id}>
              {Object.keys(row).map((colKey, colIndex) => (
                <td key={colKey} onClick={() => this.handleCellClick(rowIndex, colIndex)}>
                  {row[colKey]}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    );
  }

  render() {
    return (
      <div>
        {this.renderTable()}
      </div>
    );
  }
}
