const CourseView = () => {
    const history = useHistory();
    const [data, setData] = useState(null);
    const [toast, setToast] = React.useState(false);
    const [openConfir, setOpenConfir] = React.useState(false);
    const [selectedValue, setSelectedValue] = React.useState("");
    const [newValue, setNewValue] = React.useState("");
  
    const handleClickOpenConfir = (id) => {
      setSelectedValue(id);
      setOpenConfir(true);
    };
  
    const handleCloseConfir = () => {
      setOpenConfir(false);
    };
    const edit = history.location.state ? history.location.state.edit : false;
    const handleClick = () => {
      history.push({
        pathname: "/admin/add-course",
      });
    };
    const editCourse = async (user) => {
      history.push({
        pathname: "/admin/add-course",
        state: { user: user, role: "Student", edit: true },
      });
    };
    const removeCourse = async (userId) => {
      console.log("deleting");
      console.log(selectedValue);
      console.log(newValue);
      const user = await Axios.post(`http://3.239.246.88:5000/delete-course`, 
      {
        courseId: selectedValue,
        newCourseId: newValue,
      },
      {
        headers: {
          Authorization: "Bearer " + localStorage.getItem("auth_token"),
        },
      });
      setToast(true);
      setTimeout(() => {
        window.location.reload();
      }, 1000);
      console.log(user);
    };
    const courseList = async () => {
      const course = await Axios.get("http://3.239.246.88:5000/get-courses", {
        headers: {
          Authorization: "Bearer " + localStorage.getItem("auth_token"),
        },
      });
      console.log(course.data.courses);
      setData(course.data.courses);
    };
    useEffect(() => {
      courseList();
    }, []);
  
    return (
      <>
        {data != null ? (
          <>
            <Toast_Comp
              setToast={setToast}
              renderToast={toast}
              msg={`Course deleted successfully`}
            />
            <div class="d-flex align-content-end justify-content-end mt-2">
              <Button variant="contained" onClick={handleClick}>
                Add Course
              </Button>
            </div>
  
            <Row container sx={{ marginTop: "5px" }}>
              {data &&
                data.map((course) => {
                  return (
                    <Col sm={12} md={6} lg={3}>
                      <Card
                        sx={{ maxWidth: 345, marginTop: "10px", padding: "10px" }}
                      >
                        <CardMedia
                          component="img"
                          height="140"
                          image={course.courseThumbnail}
                          alt="course name"
                        />
                        <CardContent>
                          <Typography gutterBottom variant="h5" component="div">
                            {course.courseName}
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            {course.courseDescription}
                          </Typography>
                        </CardContent>
                        <CardActions>
                          <Button
                            onClick={() => editCourse(course)}
                            variant="contained"
                            color="success"
                          >
                            Edit
                          </Button>
                          <Button
                            onClick={() => handleClickOpenConfir(course._id)}
                            variant="contained"
                            color="error"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                          >
                            Delete
                          </Button>
                        </CardActions>
                      </Card>
                      <div
                        className="modal fade"
                        id="exampleModal"
                        tabindex="-1"
                        aria-labelledby="exampleModalLabel"
                        aria-hidden="true"
                        open={openConfir}
                        onClose={handleCloseConfir}
                        aria-describedby="alert-dialog-description"
                      >
                        <div className="modal-dialog modal-dialog-centered">
                          <div className="modal-content">
                            <div className="modal-header">
                              <h5 className="modal-title" id="exampleModalLabel">
                                Confirm Delete
                              </h5>
                              <button
                                type="button"
                                className="btn-close"
                                data-bs-dismiss="modal"
                                aria-label="Close"
                              ></button>
                            </div>
                            <div className="modal-body text-left">
                              <div className="mt-3 mb-3">
                                <form>
                                  <label>
                                    Are you sure to delete this Course please
                                    select a new course to enroll students?
                                  </label>
                                  <select className="form-control"
                                    onChange={(e) => setNewValue(e.target.value)}
                                  >
                                    <option value="">Select Course</option>
                                    {data &&
                                      data.map((course) => {
                                        return (
                                          course._id != selectedValue ? <option value={course._id}>
                                            {course.courseName}
                                          </option> : null
                                        );
                                      })}
                                  </select>
                                </form>
                              </div>
                            </div>
                            <div className="modal-footer">
                              <button
                                type="button"
                                className="btn btn-secondary"
                                onClick={handleCloseConfir}
                                data-bs-dismiss="modal"
                              >
                                Disagree
                              </button>
                              <button
                                type="button"
                                className="btn btn-primary"
                                onClick={() => {
                                  removeCourse(course._id);
                                  handleCloseConfir();
                                }}
                                autoFocus
                              >
                                Agree
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Col>
                  );
                })}
            </Row>
          </>
        ) : (
          <Loader />
        )}
      </>
    );
  };