import React, { Component } from 'react';

class UncontrolledCheckbox extends Component {
  handleCheckboxChange = () => {
    const checkbox = this.checkboxRef.current;
    alert(`Checkbox checked: ${checkbox.checked}`);
  }

  render() {
    return (
      <div>
        <input type="checkbox" onChange={this.handleCheckboxChange} ref={this.checkboxRef} />
      </div>
    );
  }
}
