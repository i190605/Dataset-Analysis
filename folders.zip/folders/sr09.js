const setAfterBlurHandle =
ReactDOM.unstable_createEventHandle('afterblur');
const setBeforeBlurHandle =
ReactDOM.unstable_createEventHandle('beforeblur');

function Child() {
if (suspend) {
  throw promise;
} else {
  return <input ref={innerRef} />;
}
}
