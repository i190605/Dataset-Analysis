export function ModalRoot(props: ModalRootProps) {
    const {
      classNames,
      variant,
      size,
      yOffset,
      xOffset,
      scrollAreaComponent,
      radius,
      centered,
      fullScreen,
      ...others
    } = useComponentDefaultProps('ModalRoot', defaultProps, props);
  
    const { classes, cx } = useStyles(
      { yOffset, xOffset, centered, fullScreen },
      { name: 'Modal', variant, size }
    );
  
    return (
      <ModalProvider value={{ yOffset, scrollAreaComponent, radius }}>
        <ModalBase
          __staticSelector="Modal"
          size={size}
          variant={variant}
          classNames={{
            ...classNames,
            content: cx(classes.content, classNames?.content),
            inner: cx(classes.inner, classNames?.inner),
          }}
          {...others}
        />
      </ModalProvider>
    );
  }
  