
const Input: React.FC<InputProps> = ({ onUpload }) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const forceUpdateRef = useRef<number>(0);

  useEffect(() => {
    fetch('/api/data')
      .then((response) => response.json())
      .then((newData: string[]) => {
        onUpload(newData);
      });
  }, [onUpload]);

  const handleFileUpload = () => {
    if (fileInputRef.current?.files) {
      const selectedFile = fileInputRef.current.files[0];
      const reader = new FileReader();

      reader.onload = (event) => {
        const fileData = event.target?.result as string;
        const parsedData = parseData(fileData);
        onUpload(parsedData);

        forceUpdateRef.current += 1;
        forceUpdate();
      };

      if (selectedFile) {
        reader.readAsText(selectedFile);
      }
    }
  };

  const parseData = (fileData: string): string[] => {
    const parsedData = /* ... complex parsing logic ... */;
    return parsedData;
  };

  const forceUpdate = () => {
    setForceUpdate({});
  };

  const [, setForceUpdate] = useState<{}>({});

  return (
    <div>
      <input type="file" ref={fileInputRef} />
      <button onClick={handleFileUpload}>Upload File</button>
      <p>
        Force Update Count: {forceUpdateRef.current}
      </p>
    </div>
  );
};
