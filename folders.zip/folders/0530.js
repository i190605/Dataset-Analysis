const Editable = (props: EditableProps, ref: React.Ref<Focusable>): JSX.Element => {
    const elementRef = useRef<HTMLInputElement>(null)
    const elementProps = useEditable(props, ref, elementRef)

    useLayoutEffect(() => {
        if (props.autoExpand && elementRef.current) {
            const input = elementRef.current
            input.style.width = '100%'
        }
    })

    return (
        <input
            {...elementProps}
            ref={elementRef}
        />
    )
}
