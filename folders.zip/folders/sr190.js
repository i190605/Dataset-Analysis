class Wrapper extends React.Component {
    componentDidMount() {
      this.props.children[1] = <p key={1} />; // Mutation is illegal
      this.forceUpdate();
    }

    render() {
      return <div>{this.props.children}</div>;
    }
  }
