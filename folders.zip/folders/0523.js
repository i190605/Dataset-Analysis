class VisualizationWidget extends React.Component {
    static propTypes = {
      widget: PropTypes.object.isRequired, // eslint-disable-line react/forbid-prop-types
      dashboard: PropTypes.object.isRequired, // eslint-disable-line react/forbid-prop-types
      filters: FiltersType,
      isPublic: PropTypes.bool,
      isLoading: PropTypes.bool,
      canEdit: PropTypes.bool,
      isEditing: PropTypes.bool,
      onLoad: PropTypes.func,
      onRefresh: PropTypes.func,
      onDelete: PropTypes.func,
      onParameterMappingsChange: PropTypes.func,
    };
  
    static defaultProps = {
      filters: [],
      isPublic: false,
      isLoading: false,
      canEdit: false,
      isEditing: false,
      onLoad: () => {},
      onRefresh: () => {},
      onDelete: () => {},
      onParameterMappingsChange: () => {},
    };
  
    constructor(props) {
      super(props);
      this.state = {
        localParameters: props.widget.getLocalParameters(),
        localFilters: props.filters,
      };
    }
  
    componentDidMount() {
      const { widget, onLoad } = this.props;
      recordEvent("view", "query", widget.visualization.query.id, { dashboard: true });
      recordEvent("view", "visualization", widget.visualization.id, { dashboard: true });
      onLoad();
    }
  
    onLocalFiltersChange = localFilters => {
      this.setState({ localFilters });
    };
  
    expandWidget = () => {
      ExpandedWidgetDialog.showModal({ widget: this.props.widget, filters: this.state.localFilters });
    };
  
    editParameterMappings = () => {
      const { widget, dashboard, onRefresh, onParameterMappingsChange } = this.props;
      EditParameterMappingsDialog.showModal({
        dashboard,
        widget,
      }).onClose(valuesChanged => {
        // refresh widget if any parameter value has been updated
        if (valuesChanged) {
          onRefresh();
        }
        onParameterMappingsChange();
        this.setState({ localParameters: widget.getLocalParameters() });
      });
    };
  
    renderVisualization() {
      const { widget, filters } = this.props;
      const widgetQueryResult = widget.getQueryResult();
      const widgetStatus = widgetQueryResult && widgetQueryResult.getStatus();
      switch (widgetStatus) {
        case "failed":
          return (
            <div className="body-row-auto scrollbox">
              {widgetQueryResult.getError() && (
                <div className="alert alert-danger m-5">
                  Error running query: <strong>{widgetQueryResult.getError()}</strong>
                </div>
              )}
            </div>
          );
        case "done":
          return (
            <div className="body-row-auto scrollbox">
              <VisualizationRenderer
                visualization={widget.visualization}
                queryResult={widgetQueryResult}
                filters={filters}
                onFiltersChange={this.onLocalFiltersChange}
                context="widget"
              />
            </div>
          );
        default:
          return (
            <div
              className="body-row-auto spinner-container"
              role="status"
              aria-live="polite"
              aria-relevant="additions removals">
              <div className="spinner">
                <i className="zmdi zmdi-refresh zmdi-hc-spin zmdi-hc-5x" aria-hidden="true" />
                <span className="sr-only">Loading...</span>
              </div>
            </div>
          );
      }
    }
  
    render() {
      const { widget, isLoading, isPublic, canEdit, isEditing, onRefresh } = this.props;
      const { localParameters } = this.state;
      const widgetQueryResult = widget.getQueryResult();
      const isRefreshing = isLoading && !!(widgetQueryResult && widgetQueryResult.getStatus());
      const onParametersEdit = parameters => {
        const paramOrder = map(parameters, "name");
        widget.options.paramOrder = paramOrder;
        widget.save("options", { paramOrder });
      };
  
      return (
        <Widget
          {...this.props}
          className="widget-visualization"
          menuOptions={visualizationWidgetMenuOptions({
            widget,
            canEditDashboard: canEdit,
            onParametersEdit: this.editParameterMappings,
          })}
          header={
            <VisualizationWidgetHeader
              widget={widget}
              refreshStartedAt={isRefreshing ? widget.refreshStartedAt : null}
              parameters={localParameters}
              isEditing={isEditing}
              onParametersUpdate={onRefresh}
              onParametersEdit={onParametersEdit}
            />
          }
          footer={
            <VisualizationWidgetFooter
              widget={widget}
              isPublic={isPublic}
              onRefresh={onRefresh}
              onExpand={this.expandWidget}
            />
          }
          tileProps={{ "data-refreshing": isRefreshing }}>
          {this.renderVisualization()}
        </Widget>
      );
    }
  }
  