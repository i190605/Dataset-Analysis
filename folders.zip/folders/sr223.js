import React, { Component } from 'react';

class UncontrolledChatRoom extends Component {
  constructor(props) {
    super(props);
    this.state = {
      messages: [],
      newMessage: '',
    };
  }

  handleInputChange = (e) => {
    this.setState({ newMessage: e.target.value });
  }

  handleSendMessage = () => {
    const { newMessage, messages } = this.state;
    if (newMessage.trim() === '') return;
    messages.push({ text: newMessage, timestamp: new Date() });
    this.setState({ messages, newMessage: '' });
  }

  renderMessages() {
    return this.state.messages.map((message, index) => (
      <div key={index}>
        <span>{message.timestamp.toLocaleTimeString()}: </span>
        <span>{message.text}</span>
      </div>
    ));
  }

  render() {
    return (
      <div>
        <div>
          <div>
            <input type="text" value={this.state.newMessage} onChange={this.handleInputChange} />
            <button onClick={this.handleSendMessage}>Send</button>
          </div>
          <div>
            {this.renderMessages()}
          </div>
        </div>
      </div>
    );
  }
}
