class Foo extends React.Component {
    constructor(props) {
      super(props);
      this.mutativeValue = props.initialValue;
    }
    handleClick() {
      this.mutativeValue = 'bar';
      this.forceUpdate();
    }
    render() {
      return (
        <Inner
          name={this.mutativeValue}
          onClick={this.handleClick.bind(this)}
        />
      );
    }
  }
  