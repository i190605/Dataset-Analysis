export class ValidatedNumberInput extends Component<Props, State> {
    constructor(props: Props) {
      super(props);
  
      const { isValid, errorMessage } = isNumberValid(
        props.initialValue,
        this.props.min,
        this.props.max
      );
  
      this.state = {
        value: props.initialValue,
        errorMessage,
        isValid,
      };
    }
  
    _submit = _.debounce((value) => {
      this.props.onChange(value);
    }, 250);
  
    _onChange = (e: ChangeEvent<HTMLInputElement>) => {
      const value = e.target.value;
      const { isValid, errorMessage, parsedValue } = isNumberValid(
        value,
        this.props.min,
        this.props.max
      );
  
      this.setState({
        value,
        errorMessage,
        isValid,
      });
  
      if (isValid) {
        this._submit(parsedValue);
      }
    };
  
    render() {
      return (
        <EuiFormRow
          label={this.props.label}
          isInvalid={!this.state.isValid}
          error={this.state.errorMessage ? [this.state.errorMessage] : []}
          display={this.props.display}
          helpText={this.props.helpText}
        >
          <EuiFieldNumber
            isInvalid={!this.state.isValid}
            min={this.props.min}
            max={this.props.max}
            value={this.state.value}
            onChange={this._onChange}
            aria-label={`${this.props.label} number input`}
          />
        </EuiFormRow>
      );
    }
  }
  