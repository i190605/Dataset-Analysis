export function Thumb({
    position,
    className,
    styles,
    classNames,
    style,
    size,
    __staticSelector,
    unstyled,
    variant,
  }: ThumbProps) {
    const { classes, cx } = useStyles(null, {
      classNames,
      styles,
      name: __staticSelector,
      unstyled,
      size,
      variant,
    });
  
    return (
      <div
        className={cx(classes.thumb, className)}
        style={{
          left: `calc(${position.x * 100}% - ${THUMB_SIZES[size]} / 2)`,
          top: `calc(${position.y * 100}% - ${THUMB_SIZES[size]} / 2)`,
          ...style,
        }}
      />
    );
  }
  