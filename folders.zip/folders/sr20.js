function App() {
    return (
      <form>
        <input type="hidden" name="foo" value="bar" ref={hiddenRef} />
        <input
          type="submit"
          formAction={action}
          method={null}
          ref={inputRef}
        />
        <button formAction={action} ref={buttonRef} target={null} />
      </form>
    );
  }
