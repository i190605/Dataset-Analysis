import React, { Component } from 'react';

class UncontrolledDynamicList extends Component {
  constructor(props) {
    super(props);
    this.textInputRefs = [];
  }

  handleAddInput = () => {
    this.textInputRefs.push(React.createRef());
    this.forceUpdate(); // Not recommended; used here for simplicity.
  }

  handleShowValues = () => {
    const values = this.textInputRefs.map(ref => ref.current.value);
    alert(`Input values: ${values.join(', ')}`);
  }

  render() {
    return (
      <div>
        <button onClick={this.handleAddInput}>Add Input</button>
        <button onClick={this.handleShowValues}>Show Values</button>
        <div>
          {this.textInputRefs.map((ref, index) => (
            <input type="text" key={index} ref={ref} />
          ))}
        </div>
      </div>
    );
  }
}
