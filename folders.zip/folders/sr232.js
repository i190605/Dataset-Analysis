import React, { useRef, useEffect } from 'react';

// Custom hook for data management.
function useDataManagement(initialData) {
  const dataRef = useRef(initialData);

  // Simulate initial data loading.
  useEffect(() => {
    fetch('/api/data')
      .then(response => response.json())
      .then(newData => {
        dataRef.current = newData;
      });
  }, []);

  return {
    getData: () => dataRef.current,
    updateData: (newData) => {
      dataRef.current = newData;
    },
  };
}

// Component that demonstrates the uncontrolled component smell.
function UncontrolledComponent() {
  const fileInputRef = useRef(null);
  const { getData, updateData } = useDataManagement([]);

  function handleFileUpload() {
    const selectedFile = fileInputRef.current.files[0];
    const reader = new FileReader();

    reader.onload = (event) => {
      const fileData = event.target.result;
      const parsedData = parseData(fileData);
      updateData(parsedData); // Update data outside of React state.
    };

    if (selectedFile) {
      reader.readAsText(selectedFile);
    }
  }

  function parseData(fileData) {
    // Complex data parsing logic, not utilizing React state.
    const parsedData = /* ... complex parsing logic ... */;
    return parsedData;
  }

  return (
    <div>
      <h2>Uncontrolled Component</h2>
      <input type="file" ref={fileInputRef} />
      <button onClick={handleFileUpload}>Upload File</button>
      <div>
        <h3>Data</h3>
        <ul>
          {/* Render data items */}
          {getData().map((item, index) => (
            <li key={index}>{item}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}

function App() {
  return (
    <div>
      <UncontrolledComponent />
    </div>
  );
}

export default App;
