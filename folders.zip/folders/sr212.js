import React, { Component } from 'react';

class UncontrolledForm extends Component {
  constructor(props) {
    super(props);
    this.nameInputRef = React.createRef();
    this.emailInputRef = React.createRef();
  }

  handleSubmit = (e) => {
    e.preventDefault();
    const name = this.nameInputRef.current.value;
    const email = this.emailInputRef.current.value;
    alert(`Submitted: Name - ${name}, Email - ${email}`);
  }

  render() {
    return (
      <div>
        <form onSubmit={this.handleSubmit}>
          <label>
            Name:
            <input type="text" ref={this.nameInputRef} />
          </label>
          <label>
            Email:
            <input type="email" ref={this.emailInputRef} />
          </label>
          <button type="submit">Submit</button>
        </form>
      </div>
    );
  }
}
