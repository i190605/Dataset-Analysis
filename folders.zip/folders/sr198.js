import React, { Component } from 'react';

class MyAppContainer extends Component {
  componentDidMount() {
    ipcRenderer.on("toggle-side-menu", this.handleSideMenuToggle)
  }

  handleSideMenuToggle() {
    mySession.ui.toggleSidebar()
  }

  render() {
    const { ui } = mySession
    const displayHome = ui.tab === "home"
    const displayTimeline = ui.tab === "timeline"
    const displayHelp = ui.tab === "help"
    const displaySettings = ui.tab === "settings"
    const displayNative = ui.tab === "native"
    const displayState = ui.tab === "state"
    const displayCustomCommands = ui.tab === "customCommands"

    return (
      <Provider session={mySession}>
        <div style={Styles.container}>
          <div style={Styles.content}>
            {!ui.inTerminal && (
              <div style={Styles.body}>
                <MyAppSidebar />
                <div style={Styles.app}>
                  <div style={displayHome ? Styles.page : Styles.pageHidden}>
                    <MyHomeComponent />
                  </div>
                  <div style={displayTimeline ? Styles.page : Styles.pageHidden}>
                    <MyTimelineComponent />
                  </div>
                  <div style={displayState ? Styles.page : Styles.pageHidden}>
                    <MyStateComponent />
                  </div>
                  <div style={displayHelp ? Styles.page : Styles.pageHidden}>
                    <MyHelpComponent />
                  </div>
                  <div style={displayNative ? Styles.page : Styles.pageHidden}>
                    <MyNativeComponent />
                  </div>
                  <div style={displayCustomCommands ? Styles.page : Styles.pageHidden}>
                    <MyCustomCommandsList />
                  </div>
                  <div style={displaySettings ? Styles.page : Styles.pageHidden}>
                    <h1>My App Settings</h1>
                  </div>
                </div>
              </div>
            )}
            {ui.inTerminal && (
              <div style={Styles.body}>
                <div style={Styles.app}>
                  <div style={Styles.page}>
                    <MyReactotronTerminal />
                  </div>
                </div>
              </div>
            )}
            <MyAppStatusBar />
          </div>
          <MyStateKeysAndValuesDialog />
          <MyStateDispatchDialog />
          <MyStateWatchDialog />
          <MyRenameStateDialog />
          <MyFilterTimelineDialog />
          <MyExportTimelineDialog />
          <MySendCustomDialog />
        </div>
      </Provider>
    )
  }
}

export default MyAppContainer;
