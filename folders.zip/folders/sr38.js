const Login = () => {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState();
    const [loading, setLoading] = useState(false);
    const [toast, setToast] = useState(false);
    const history = useHistory();
    const {user} = useSelector((state) => state.auth);
    const dispatch = useDispatch();
  
    const formSubmitHandler = (e) => {
      e.preventDefault();
      setLoading(true);
      fetch("http://3.239.246.88:5000/auth/login", {
        method: "post",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email,
          password,
        }),
      })
        .then((res) => res.json())
        .then((result) => {
          setLoading(false);
          if (result.errors) {
            setError(result.errors);
          } else {
            
            setToast(true);
            setError(null);
            console.log(result)
               setTimeout(() => {
                dispatch({ type: "SET__USER", payload: result.userInfo });
                localStorage.setItem("auth_token", result.token);
                localStorage.setItem("user", JSON.stringify(result.userInfo));
                localStorage.setItem("token", Date.now())
               }, 1000);
               clearTimeout();
          }
        })
        .catch((err) => {
          console.log(err);
        });
    };
  
    useEffect(() => {
      if(user && user.role==="Student")
      {
        history.push('/student-dashboard')
      }
      else if(user && user.role==="Admin")
      {
        history.push('/admin-dashboard')
      }
      else if(user && user.role==="Teacher")
      {
        history.push('/teacher-dashboard')
      }
      else if(user && user.role==="Scheduler")
      {
        history.push('/scheduler-dashboard')
      }
    }, [user])
    return (
      <div style={styles}>
        <Container>
          <Toast_Comp
            setToast={setToast}
            renderToast={toast}
            msg="Login Success"
          />
          <Row>
            <Col md={6} className="mx-auto mt-4 ">
              <Paper className="p-4 shadow rounded">
                <Typography
                  className="text-center mb-3"
                  variant="h5"
                >
                  Login Here
                </Typography>
                {loading && <Spinner_comp />}
                {error && error.userExist && (
                  <Alert_Comp variant="danger" msg={error.userExist} />
                )}
  
                <Form onSubmit={formSubmitHandler}>
                  <Form.Group controlId="formBasicEmail">
                    <Form.Label>Email address</Form.Label>
                    <Form.Control
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      type="email"
                      placeholder="Enter email"
                    />
                    <span style={{ color: "red" }}>{error && error.email}</span>
                  </Form.Group>
                  <Form.Group controlId="formBasicPassword">
                    <Form.Label>Password</Form.Label>
                    <Form.Control
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      type="password"
                      placeholder="Password"
                    />
                    <span style={{ color: "red" }}>
                      {error && error.password}
                    </span>
                  </Form.Group>
  
                  {loading ?
                    <Button
                    className="mt-2"
                    color="#D9D9D9"
                    variant="contained"
                  >
                    Sign In
                  </Button>
                    :
                    <Button
                    className="mt-2"
                    color="#D9D9D9"
                    variant="contained"
                    type="submit"
                  >
                    Sign In
                  </Button>
  
                  }
                </Form>
              </Paper>
            </Col>
          </Row>
        </Container>
      </div>
    );
  };