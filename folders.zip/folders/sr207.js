import React, { Component } from 'react';

class UncontrolledNumberInput extends Component {
  handleNumberChange = () => {
    const numberInput = this.numberInputRef.current;
    alert(`Entered number: ${numberInput.value}`);
  }

  render() {
    return (
      <div>
        <input type="number" onChange={this.handleNumberChange} ref={this.numberInputRef} />
      </div>
    );
  }
}
