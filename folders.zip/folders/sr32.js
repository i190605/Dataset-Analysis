const WidgetsDropdown = () => {
    const [data, setData] = useState([]);
    const [teachers, setTeachers] = useState([]);
    const [fee, setFee] = useState([]);
  
    const getFee = async () => {
      const temp = await Axios.get(`http://3.239.246.88:5000/fee/getFee`, {
        headers: {
          Authorization: "Bearer " + localStorage.getItem("auth_token"),
        },
      });
      console.log(temp)
  
      // filter by current month
      const currentMonth = new Date().getMonth() + 1;
      const filteredFee = temp.data.fee.filter((f) => {
        const feeMonth = new Date(f.submissionDate).getMonth() + 1;
        return feeMonth === currentMonth;
      }
      );
      setFee(filteredFee);
    };
  
    const userList = async () => {
      const user = await Axios.get("http://3.239.246.88:5000/users/student", {
        headers: {
          Authorization: "Bearer " + localStorage.getItem("auth_token"),
        },
      });
      console.log(user);
      setData(user.data.studentInfo);
    };
  
    const userTeacher = async () => {
      const user = await Axios.get("http://3.239.246.88:5000/users/teacher", {
        headers: {
          Authorization: "Bearer " + localStorage.getItem("auth_token"),
        },
      });
      console.log(user);
      setTeachers(user.data.teacherInfo);
    };
  
    useEffect(() => {
      userList();
      userTeacher();
      getFee();
    }, []);
    return (
      <Container fluid>
        <CRow>
          <CCol lg={3} md={6} sm={3}>
            <CWidgetStatsA
              className="mb-4 mt-4"
              color="primary"
              value={<>{data && data.length} </>}
              title="No Of Students"
            />
          </CCol>
          <CCol lg={3} md={6} sm={3}>
            <CWidgetStatsA
              className="mb-4 mt-4"
              color="warning"
              height="auto"
              value={<>{teachers && teachers.length}</>}
              title="No Of Teachers"
            />
          </CCol>
          <CCol lg={3} md={6} sm={3}>
            <CWidgetStatsA
              className="mb-4 mt-4"
              color="danger"
              value={
                <>
                  {fee && data && data.length - fee.length}{" "}
                </>
              }
              title="Fee Not Paid"
              action={
                <CDropdown alignment="end" className="mb-4">
                  <CDropdownToggle
                    color="transparent"
                    caret={false}
                    className="p-0"
                  >
                    <CIcon
                      icon={cilOptions}
                      className="text-high-emphasis-inverse"
                    />
                  </CDropdownToggle>
                  <CDropdownMenu>
                    <CDropdownItem>Action</CDropdownItem>
                    <CDropdownItem>Another action</CDropdownItem>
                    <CDropdownItem>Something else here...</CDropdownItem>
                    <CDropdownItem disabled>Disabled action</CDropdownItem>
                  </CDropdownMenu>
                </CDropdown>
              }
            />
          </CCol>
          <CCol lg={3} md={6} sm={3}>
            <CWidgetStatsA
              className="mb-4 mt-4"
              color="success "
              value={
                <>
                  {fee && fee.length}{" "}
                </>
              }
              title="Fee Paid"
              action={
                <CDropdown alignment="end" className="mb-4">
                  <CDropdownToggle
                    color="transparent"
                    caret={false}
                    className="p-0"
                  >
                    <CIcon
                      icon={cilOptions}
                      className="text-high-emphasis-inverse"
                    />
                  </CDropdownToggle>
                  <CDropdownMenu>
                    <CDropdownItem>Action</CDropdownItem>
                    <CDropdownItem>Another action</CDropdownItem>
                    <CDropdownItem>Something else here...</CDropdownItem>
                    <CDropdownItem disabled>Disabled action</CDropdownItem>
                  </CDropdownMenu>
                </CDropdown>
              }
            />
          </CCol>
        </CRow>
      </Container>
    );
  };
  
  