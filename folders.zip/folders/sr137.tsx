export function Accordion<Multiple extends boolean = false>(props: AccordionProps<Multiple>) {
    const {
      id,
      loop,
      children,
      multiple,
      value,
      defaultValue,
      onChange,
      transitionDuration,
      disableChevronRotation,
      chevronPosition,
      chevronSize,
      order,
      chevron,
      classNames,
      styles,
      unstyled,
      variant,
      radius,
      ...others
    } = useComponentDefaultProps<AccordionProps<Multiple>>(
      'Accordion',
      defaultProps as AccordionProps<Multiple>,
      props
    );
  
    return (
      <AccordionProvider
        id={id}
        multiple={multiple}
        value={value}
        defaultValue={defaultValue}
        onChange={onChange}
        loop={loop}
        transitionDuration={transitionDuration}
        disableChevronRotation={disableChevronRotation}
        chevronPosition={chevronPosition}
        chevronSize={chevronSize}
        order={order}
        chevron={chevron}
        variant={variant}
        radius={radius}
        classNames={classNames}
        styles={styles}
        unstyled={unstyled}
      >
        <Box {...others} data-accordion>
          {children}
        </Box>
      </AccordionProvider>
    );
  }