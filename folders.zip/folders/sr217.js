import React, { Component } from 'react';

class UncontrolledCalendar extends Component {
  constructor(props) {
    super(props);
    this.calendarRef = React.createRef();
  }

  handleDateClick = (e) => {
    // Highlight the selected date.
    const cell = e.target;
    const selectedDate = cell.textContent;
    cell.style.backgroundColor = 'lightblue';
    alert(`Selected date: ${selectedDate}`);
  }

  render() {
    return (
      <div>
        <table ref={this.calendarRef}>
          <thead>
            <tr>
              <th>Sun</th>
              <th>Mon</th>
              <th>Tue</th>
              <th>Wed</th>
              <th>Thu</th>
              <th>Fri</th>
              <th>Sat</th>
            </tr>
          </thead>
          <tbody>
            {/* Calendar cells */}
          </tbody>
        </table>
      </div>
    );
  }
}
