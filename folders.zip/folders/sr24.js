
class Top extends React.Component {
    render() {
      return (
        <Middle>
          <Bottom />
        </Middle>
      );
    }
  }

  class Middle extends React.Component {
    componentDidMount() {
      this.forceUpdate();
    }

    render() {
      numMiddleRenders++;
      return React.Children.only(this.props.children);
    }
  }
