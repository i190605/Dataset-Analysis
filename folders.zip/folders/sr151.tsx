export function Popover(props: PopoverProps) {
    const arrowRef = useRef<HTMLDivElement | null>(null);
    const {
      children,
      position,
      offset,
      onPositionChange,
      positionDependencies,
      opened,
      transitionProps,
      width,
      middlewares,
      withArrow,
      arrowSize,
      arrowOffset,
      arrowRadius,
      arrowPosition,
      unstyled,
      classNames,
      styles,
      closeOnClickOutside,
      withinPortal,
      portalProps,
      closeOnEscape,
      clickOutsideEvents,
      trapFocus,
      onClose,
      onOpen,
      onChange,
      zIndex,
      radius,
      shadow,
      id,
      defaultOpened,
      __staticSelector,
      withRoles,
      disabled,
      returnFocus,
      variant,
      keepMounted,
      ...others
    } = useComponentDefaultProps('Popover', defaultProps, props);
  
    const [targetNode, setTargetNode] = useState<HTMLElement>(null);
    const [dropdownNode, setDropdownNode] = useState<HTMLElement>(null);
  
    const uid = useId(id);
    const theme = useMantineTheme();
    const popover = usePopover({
      middlewares,
      width,
      position: getFloatingPosition(theme.dir, position),
      offset: typeof offset === 'number' ? offset + (withArrow ? arrowSize / 2 : 0) : offset,
      arrowRef,
      arrowOffset,
      onPositionChange,
      positionDependencies,
      opened,
      defaultOpened,
      onChange,
      onOpen,
      onClose,
    });
  
    useClickOutside(
      () => popover.opened && closeOnClickOutside && popover.onClose(),
      clickOutsideEvents,
      [targetNode, dropdownNode]
    );
  
    const reference = useCallback(
      (node: HTMLElement) => {
        setTargetNode(node);
        popover.floating.reference(node);
      },
      [popover.floating.reference]
    );
  
    const floating = useCallback(
      (node: HTMLElement) => {
        setDropdownNode(node);
        popover.floating.floating(node);
      },
      [popover.floating.floating]
    );
  
    return (
      <PopoverContextProvider
        value={{
          returnFocus,
          disabled,
          controlled: popover.controlled,
          reference,
          floating,
          x: popover.floating.x,
          y: popover.floating.y,
          arrowX: popover.floating?.middlewareData?.arrow?.x,
          arrowY: popover.floating?.middlewareData?.arrow?.y,
          opened: popover.opened,
          arrowRef,
          transitionProps,
          width,
          withArrow,
          arrowSize,
          arrowOffset,
          arrowRadius,
          arrowPosition,
          placement: popover.floating.placement,
          trapFocus,
          withinPortal,
          portalProps,
          zIndex,
          radius,
          shadow,
          closeOnEscape,
          onClose: popover.onClose,
          onToggle: popover.onToggle,
          getTargetId: () => `${uid}-target`,
          getDropdownId: () => `${uid}-dropdown`,
          withRoles,
          targetProps: others,
          __staticSelector,
          classNames,
          styles,
          unstyled,
          variant,
          keepMounted,
        }}
      >
        {children}
      </PopoverContextProvider>
    );
  }
  