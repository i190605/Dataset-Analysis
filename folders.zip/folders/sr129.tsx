export const ActiveDescendant = () => {
    // Display each key press in the top-right corner of the page as a visual aid
    const [lastKey, setLastKey] = useState('none')
    const reportKey = useCallback((event: React.KeyboardEvent<HTMLDivElement>) => {
      setLastKey(event.key)
    }, [])
  
    const containerRef = useRef<HTMLElement>(null)
    const controllingElementRef = useRef<HTMLElement>(null)
    const {theme: themeFromContext} = useTheme()
  
    useFocusZone({
      containerRef,
      activeDescendantFocus: controllingElementRef,
      bindKeys: FocusKeys.ArrowVertical,
      onActiveDescendantChanged: (current, previous) => {
        if (current) {
          current.style.outline = `2px solid ${themeFromContext?.colors.accent.fg}`
        }
        if (previous) {
          previous.style.outline = ''
        }
      },
      focusableElementFilter: elem => elem instanceof HTMLButtonElement,
    })
  
    return (
      <>
        <Box display="flex" flexDirection="column" alignItems="flex-start" onKeyDownCapture={reportKey}>
          <Flash sx={{mb: 3}}>
            This story demonstrates using the `aria-activedescendant` pattern for managing both a focused element and an
            active element. Below, you can focus the input box then use the up/down arrow keys to change the active
            descendant (dark blue outline).
          </Flash>
          <Box position="absolute" right={5} top={2}>
            Last key pressed: {lastKey}
          </Box>
          <MarginButton>Apple</MarginButton>
          <MarginButton>Banana</MarginButton>
          <MarginButton>Cantaloupe</MarginButton>
          <Box borderColor="gray.5" m={4} p={4} borderWidth="1px" borderStyle="solid" borderRadius={2}>
            <label htmlFor="focus-input">
              <strong>Bound keys: Arrow Up and Arrow Down</strong>
            </label>
            <Box display="flex" flexDirection="column" alignItems="flex-start">
              <input
                ref={controllingElementRef as React.RefObject<HTMLInputElement>}
                type="text"
                defaultValue="Focus remains here."
                aria-controls="list"
                id="focus-input"
              />
              <Box
                display="flex"
                id="list"
                flexDirection="column"
                alignItems="flex-start"
                ref={containerRef as React.RefObject<HTMLDivElement>}
              >
                <MarginButton>Durian</MarginButton>
                <MarginButton>Elderberry</MarginButton>
                <MarginButton>Fig</MarginButton>
                <MarginButton>Grapefruit</MarginButton>
              </Box>
            </Box>
          </Box>
          <MarginButton>Honeydew</MarginButton>
          <MarginButton>Jackfruit</MarginButton>
          <MarginButton>Kiwi</MarginButton>
        </Box>
      </>
    )
  }
  