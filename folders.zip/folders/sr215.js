import React, { Component } from 'react';
import Quill from 'react-quill';

class UncontrolledRichTextEditor extends Component {
  constructor(props) {
    super(props);
    this.quillRef = React.createRef();
  }

  handleSave = () => {
    const content = this.quillRef.current.getContents();
    alert(`Saved content: ${JSON.stringify(content)}`);
  }

  render() {
    return (
      <div>
        <Quill ref={this.quillRef} />
        <button onClick={this.handleSave}>Save</button>
      </div>
    );
  }
}
