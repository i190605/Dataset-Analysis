export class EditDescriptionPopover extends Component {
    static displayName = 'EditDescriptionPopover';
    static propTypes = {
      description: PropTypes.string,
      updateDescription: PropTypes.func.isRequired,
      canCreateFilter: PropTypes.bool.isRequired,
    };
  
    constructor(props) {
      super(props);
  
      this.state = {
        isPopoverOpen: false,
        value: props.description,
      };
    }
  
    onChange = (e) => {
      this.setState({
        value: e.target.value,
      });
    };
  
    onButtonClick = () => {
      if (this.state.isPopoverOpen === false) {
        this.setState({
          isPopoverOpen: !this.state.isPopoverOpen,
          value: this.props.description,
        });
      } else {
        this.closePopover();
      }
    };
  
    closePopover = () => {
      if (this.state.isPopoverOpen === true) {
        this.setState({
          isPopoverOpen: false,
        });
        this.props.updateDescription(this.state.value);
      }
    };
  
    render() {
      const { isPopoverOpen, value } = this.state;
  
      const button = (
        <EuiButtonIcon
          size="s"
          color="primary"
          onClick={this.onButtonClick}
          iconType="pencil"
          aria-label={i18n.translate(
            'xpack.ml.settings.filterLists.editDescriptionPopover.editDescriptionAriaLabel',
            {
              defaultMessage: 'Edit description',
            }
          )}
          isDisabled={this.props.canCreateFilter === false}
          data-test-subj="mlFilterListEditDescriptionButton"
        />
      );
  
      return (
        <div>
          <EuiPopover
            id="filter_list_description_popover"
            ownFocus
            button={button}
            isOpen={isPopoverOpen}
            closePopover={this.closePopover}
            initialFocus="#filter_list_edit_description_row"
          >
            <div style={{ width: '300px' }}>
              <EuiForm>
                <EuiFormRow
                  id="filter_list_edit_description_row"
                  label={
                    <FormattedMessage
                      id="xpack.ml.settings.filterLists.editDescriptionPopover.filterListDescriptionAriaLabel"
                      defaultMessage="Filter list description"
                    />
                  }
                >
                  <EuiFieldText
                    name="filter_list_description"
                    value={value}
                    onChange={this.onChange}
                    data-test-subj={'mlFilterListDescriptionInput'}
                  />
                </EuiFormRow>
              </EuiForm>
            </div>
          </EuiPopover>
        </div>
      );
    }
  }
  