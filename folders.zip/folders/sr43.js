const StudentProfile = async () => {
    const USER=JSON.parse(localStorage.getItem('user'));
    console.log(USER._id);
    const temp = await Axios.get(`http://3.239.246.88:5000/users/get-student/${USER._id}`);
    console.log(temp.data)
    setStud(temp.data.user);
  };
  useEffect(() => {
    // userList();
    StudentProfile();
    }, []);
  useEffect(() => {
  stud ? setHobby(stud.hobby) : setHobby("");
  stud ? setAge(stud.age) : setAge();
  stud ? setgrade(stud.grade) : setgrade();
  stud ? setPicture(stud.picture) : setPicture("");
  if(stud){
    console.log(stud)
    const date = new Date(stud.dob)
    console.log(date)
    setDob(date.toISOString().slice(0,10))
  }
  }, [stud]);
return (
  <>
    <div className="content">
      <Row style={{display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',}}>
        <Col md="4">
          <Card className="card-user">
            <CardBody>
              <div className="author">
                  <img
                  style={{  width:"100%", height:"380px" }}
                    alt="..."
                    className="avatar border-gray"
                    src={picture && picture}
                  />
                  <Button style={{float:"right",margin:"5px" }}
                  size="large" color="primary" variant="outlined" aria-label="upload picture" component="label">
                    <input hidden accept="image/*" type="file" 
                    onChange={(e) => setFile(e.target.files[0])}
                    id="custom-file"
                    custom
                    label={imgLabel ? `${imgLabel}` : "Choose photo"}
                    filename="img"/>
                    <PhotoCamera />
                </Button>
                  <h5 className="title">{data && data.userName}</h5>
              </div>
              </CardBody>
              <CardBody>
              <Form>
                
                <Row>
                  <Col className="pr-1" md="6">
                  <label>Hobbies</label>
                    <FormGroup style={{display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',}}>
          {edit===false ?  <Input
                      disabled
                        placeholder="Company"
                        type="text"
                        value={hobby}
                      />:<Input
                      onChange={(e) => setHobby(e.target.value)}
                        placeholder="Company"
                        type="text"
                        value={hobby}
                      />}
                      <IconButton onClick={handleEdit}>
              <EditIcon color="primary" />
            </IconButton>
                    </FormGroup>
                    
                  </Col>
                  <Col className="pr-1" md="6">
                  <label>Age</label>
                    <FormGroup style={{display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',}}>
                      
                      {editAge===false ?   <Input
                      disabled
                        placeholder="Last Name"
                        type="text"
                        value={age ? age : ""}
                      />:<Input
                        placeholder="Last Name"
                        onChange={(e) => setAge(e.target.value)}
                        type="text"
                        value={age ? age : ""}/>}
                      <IconButton onClick={handleEditAge}>
              <EditIcon color="primary" />
            </IconButton>
                    </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col className="pr-1" md="6">
                  <label>Class</label>
                    <FormGroup style={{display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',}}>
                     {editClass===false ?
                      <Input
                        disabled
                        placeholder="Class"
                        type="text"
                        value={grade}
                      />:
                      <Input
                        placeholder="Class"
                        onChange={(e) => setgrade(e.target.value)}
                        type="text"
                        value={grade}
                      />}
                      <IconButton onClick={handleEditClass}>
              <EditIcon color="primary" />
            </IconButton>
                    </FormGroup>
                  </Col>
                  <Col className="pr-1" md="6">
                  <label>Date of Birth</label>
                    <FormGroup style={{display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',}}>
                     {editDob===false ?
                      <Input
                      disabled
                        placeholder="Date of Birth"
                        type="date"
                        value={dob ? dob : ""}
                      />:<Input
                      name="dob"
                      placeholder="Date of Birth"
                      onChange={(e) => setDob(e.target.value)}
                      type="date"
                      value={dob ? dob : ""}
                    />}
                      <IconButton onClick={handleEditDob}>
              <EditIcon color="primary" />
            </IconButton>
                    </FormGroup>
                  </Col>
                </Row>
                </Form>
                <Grid style={{display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',}}>
                <Button 
          color="primary"
          variant="contained"
          onClick={handleSubmit}
        >
          Save details
        </Button>
        </Grid>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </div>
  </>
);
