export const PullRequestPage = () => (
    <PageLayout>
      <PageLayout.Header>
        <Box sx={{display: 'flex', flexDirection: 'column', gap: 3}}>
          <Box>
            <Heading as="h1" sx={{fontWeight: 'normal'}}>
              Input validation styles <Text sx={{color: 'fg.muted', fontWeight: 'light'}}>#1831</Text>
            </Heading>
            <Box sx={{display: 'flex', gap: 2, alignItems: 'center'}}>
              <StateLabel status="pullOpened">Open</StateLabel>
              <Text sx={{fontSize: 1, color: 'fg.muted'}}>
                <Link href="#" muted sx={{fontWeight: 'bold'}}>
                  mperrotti
                </Link>{' '}
                wants to merge 3 commits into <BranchName href="#">main</BranchName> from{' '}
                <BranchName href="#">mp/validation-styles</BranchName>
              </Text>
            </Box>
          </Box>
          <TabNav>
            <TabNav.Link href="#" selected>
              Conversation
            </TabNav.Link>
            <TabNav.Link href="#">Commits</TabNav.Link>
            <TabNav.Link href="#">Checks</TabNav.Link>
            <TabNav.Link href="#">Files changed</TabNav.Link>
          </TabNav>
        </Box>
      </PageLayout.Header>
      <PageLayout.Content>
        <Box sx={{border: '1px solid', borderRadius: 2, borderColor: 'border.default', height: 200}}></Box>
        <Box
          sx={{
            maxWidth: '100%',
            overflowX: 'auto',
            border: '1px solid',
            whiteSpace: 'nowrap',
            borderColor: 'border.default',
            mt: 3,
            p: 3,
            borderRadius: 2,
          }}
          tabIndex={0}
        >
          This box has really long content. If it is too long, it will cause x overflow and should show a scrollbar. When
          this overflows, it should not break to overall page layout!
        </Box>
      </PageLayout.Content>
      <PageLayout.Pane>
        <Box sx={{display: 'flex', flexDirection: 'column', gap: 3}}>
          <Box>
            <Text sx={{fontSize: 0, fontWeight: 'bold', display: 'block', color: 'fg.muted'}}>Assignees</Text>
            <Text sx={{fontSize: 0, color: 'fg.muted', lineHeight: 'condensed'}}>
              No one –{' '}
              <Link href="#" muted>
                assign yourself
              </Link>
            </Text>
          </Box>
          <Box role="separator" sx={{width: '100%', height: 1, backgroundColor: 'border.default'}}></Box>
          <Box>
            <Text sx={{fontSize: 0, fontWeight: 'bold', display: 'block', color: 'fg.muted'}}>Labels</Text>
            <Text sx={{fontSize: 0, color: 'fg.muted', lineHeight: 'condensed'}}>None yet</Text>
          </Box>
        </Box>
      </PageLayout.Pane>
    </PageLayout>
  )