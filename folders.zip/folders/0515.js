this.state = {
    // will eventually be the collection object representing the selected collection
    // we store the whole object instead of just the ID so that we can use its
    // name in the action button, and other properties
    //
    //  undefined = no selection
    //  null = root collection
    //  number = non-root collection id
    //
    selectedCollectionId: props.initialCollectionId,
    // whether the move action has started
    // TODO: use this loading and error state in the UI
    moving: false,
    error: null,
  };