interface SearchProps {
    onSearch: (value: any) => void;
    placeholder: string;
    value: string;
    className?: string;
    autoFocus?: boolean;
  }
  
  const SearchComponentWrapper = styled.div`
    position: relative;
    width: 100%;
  `;
  
  const CrossIconWrapper = styled.div`
    width: 20px;
    height: 20px;
    position: absolute;
    cursor: pointer;
    top: 5px;
    right: 5px;
    .cross-icon {
      width: 10px;
      height: 10px;
      position: absolute;
      top: 5px;
      left: 5px;
    }
  `;
  