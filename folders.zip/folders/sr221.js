import React, { Component } from 'react';

class UncontrolledChat extends Component {
  constructor(props) {
    super(props);
    this.messages = [];
    this.messageInputRef = React.createRef();
  }

  handleSendMessage = () => {
    const message = this.messageInputRef.current.value;
    this.messages.push({ text: message, timestamp: new Date() });
    this.messageInputRef.current.value = '';
  }

  renderMessages() {
    return this.messages.map((message, index) => (
      <div key={index}>
        <span>{message.timestamp.toLocaleTimeString()}: </span>
        <span>{message.text}</span>
      </div>
    ));
  }

  render() {
    return (
      <div>
        <div>
          <div>
            <input type="text" ref={this.messageInputRef} />
            <button onClick={this.handleSendMessage}>Send</button>
          </div>
          <div>
            {this.renderMessages()}
          </div>
        </div>
      </div>
    );
  }
}
