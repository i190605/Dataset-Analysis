export function Menu(props: MenuProps) {
    const {
      children,
      onOpen,
      onClose,
      opened,
      defaultOpened,
      onChange,
      closeOnItemClick,
      loop,
      closeOnEscape,
      trigger,
      openDelay,
      closeDelay,
      classNames,
      styles,
      unstyled,
      radius,
      variant,
      ...others
    } = useComponentDefaultProps('Menu', defaultProps, props);
    const { classes, cx } = useStyles();
  
    const [hovered, { setHovered, resetHovered }] = useHovered();
    const [_opened, setOpened] = useUncontrolled({
      value: opened,
      defaultValue: defaultOpened,
      finalValue: false,
      onChange,
    });
  
    const close = () => {
      setOpened(false);
      _opened && onClose?.();
    };
  
    const open = () => {
      setOpened(true);
      !_opened && onOpen?.();
    };
  
    const toggleDropdown = () => (_opened ? close() : open());
  
    const { openDropdown, closeDropdown } = useDelayedHover({ open, close, closeDelay, openDelay });
  
    const getItemIndex = (node: HTMLButtonElement) =>
      getContextItemIndex('[data-menu-item]', '[data-menu-dropdown]', node);
  
    useDidUpdate(() => {
      resetHovered();
    }, [_opened]);
  
    return (
      <MenuContextProvider
        value={{
          opened: _opened,
          toggleDropdown,
          getItemIndex,
          hovered,
          setHovered,
          closeOnItemClick,
          closeDropdown: trigger === 'click' ? close : closeDropdown,
          openDropdown: trigger === 'click' ? open : openDropdown,
          closeDropdownImmediately: close,
          loop,
          trigger,
          radius,
          classNames,
          styles,
          unstyled,
          variant,
        }}
      >
        <Popover
          {...others}
          radius={radius}
          opened={_opened}
          onChange={toggleDropdown}
          defaultOpened={defaultOpened}
          trapFocus={trigger === 'click'}
          closeOnEscape={closeOnEscape && trigger === 'click'}
          __staticSelector="Menu"
          classNames={{ ...classNames, dropdown: cx(classes.dropdown, classNames?.dropdown) }}
          styles={styles}
          unstyled={unstyled}
          variant={variant}
        >
          {children}
        </Popover>
      </MenuContextProvider>
    );
  }