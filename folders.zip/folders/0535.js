

const handleRemoveFile = () => {
    setFileObj(null);
};



let uploadLicenseContent = (
    <>
        <div className='content-body'>
            <div className='svg-image'>
                <WomanArmOnTable
                    width={200}
                    height={200}
                />
            </div>
            <div className='title'>
                <FormattedMessage
                    id='admin.license.upload-modal.title'
                    defaultMessage='Upload a License Key'
                />
            </div>
            <div className='subtitle'>
                <FormattedMessage
                    id='admin.license.upload-modal.subtitle'
                    defaultMessage='Upload a license key for Mattermost Enterprise Edition to upgrade this server. '
                />
            </div>
            <div className='file-upload'>
                <div className='file-upload__titleSection'>
                    <FormattedMessage
                        id='admin.license.upload-modal.file'
                        defaultMessage='File'
                    />
                </div>
                <div className='file-upload__inputSection'>
                    <div className='help-text file-name-section'>
                        {fileObj?.name && fileObj?.size ? (
                            <>
                                <FileSvg
                                    width={20}
                                    height={20}
                                />
                                <span className='file-name'>
                                    {displayFileName(fileObj.name)}
                                </span>
                                <span className='file-size'>
                                    {fileSizeToString(fileObj.size)}
                                </span>
                            </>
                        ) : (
                            <FormattedMessage
                                id='admin.license.no-file-selected'
                                defaultMessage='No file selected'
                            />
                        )}
                    </div>
                    <div className='file__upload'>
                        {fileObj?.name ? (
                            <a
                                onClick={handleRemoveFile}
                            >
                                <FormattedMessage
                                    id='admin.license.remove'
                                    defaultMessage='Remove'
                                />
                            </a>
                        ) : (
                            <>
                                <input
                                    ref={fileInputRef}
                                    type='file'
                                    accept={FileTypes.LICENSE_EXTENSION}
                                    onChange={handleChange}
                                />
                                <a
                                    className='btn-select'
                                >
                                    <FormattedMessage
                                        id='admin.license.choose'
                                        defaultMessage='Choose File'
                                    />
                                </a>
                            </>
                        )}
                    </div>
                </div>
            </div>
            {serverError && <div className='serverError'>
                <i className='icon icon-alert-outline'/>
                <span
                    className='server-error-text'
                    dangerouslySetInnerHTML={{__html: marked(serverError)}}
                />
            </div>}
        </div>
        <div className='content-footer'>
            <div className='btn-upload-wrapper'>
                <button
                    className={`btn ${(fileObj?.name && fileObj?.name.length > 0) && 'btn-primary'}`}
                    disabled={!(fileObj?.name && fileObj?.name.length > 0)}
                    onClick={handleSubmit}
                    id='upload-button'
                >
                    <LoadingWrapper
                        loading={Boolean(isUploading)}
                        text={localizeMessage('admin.license.modal.uploading', 'Uploading')}
                    >
                        <FormattedMessage
                            id='admin.license.modal.upload'
                            defaultMessage='Upload'
                        />
                    </LoadingWrapper>
                </button>
            </div>
        </div>
    </>
);
