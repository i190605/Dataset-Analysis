class Counter extends React.Component {
    state = {asyncValue: '', syncValue: ''};

    handleChange = e => {
      const nextValue = e.target.value;
      React.startTransition(() => {
        this.setState({
          asyncValue: nextValue,
        });
        // It should not be flushed yet.
        expect(asyncValueRef.current.textContent).toBe('');
      });
      this.setState({
        syncValue: nextValue,
      });
    };

    render() {
      return (
        <div>
          <input
            ref={inputRef}
            onChange={this.handleChange}
            defaultValue=""
          />
          <p ref={asyncValueRef}>{this.state.asyncValue}</p>
          <p ref={syncValueRef}>{this.state.syncValue}</p>
        </div>
      );
    }
  }