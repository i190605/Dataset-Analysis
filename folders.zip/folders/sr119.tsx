export const ViewSwitch = ({selectedView, onViewSelect, onLoadPreview, disabled}: ViewSwitchProps) => {
    // don't get disabled from context - the switch is not disabled when the editor is disabled
    const {condensed} = useContext(MarkdownEditorContext)
  
    const {label, icon, ...sharedProps} =
      selectedView === 'preview'
        ? {
            variant: 'invisible' as const,
            sx: {color: 'fg.default', px: 2},
            onClick: () => onViewSelect?.('edit'),
            icon: PencilIcon,
            label: 'Edit',
          }
        : {
            variant: 'invisible' as const,
            sx: {color: 'fg.default', px: 2},
            onClick: () => {
              onLoadPreview()
              onViewSelect?.('preview')
            },
            onMouseOver: () => onLoadPreview(),
            onFocus: () => onLoadPreview(),
            icon: EyeIcon,
            label: 'Preview',
          }
  
    return (
      <Box sx={{display: 'flex', flexDirection: 'row'}}>
        {condensed ? (
          <IconButton {...sharedProps} disabled={disabled} icon={icon} aria-label={label} />
        ) : (
          <Button {...sharedProps} leadingIcon={icon} disabled={disabled}>
            {label}
          </Button>
        )}
      </Box>
    )
  }
  