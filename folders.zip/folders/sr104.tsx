const Overlay: React.FC<React.PropsWithChildren<MenuOverlayProps>> = ({
    children,
    align = 'start',
    'aria-labelledby': ariaLabelledby,
    ...overlayProps
  }) => {
    // we typecast anchorRef as required instead of optional
    // because we know that we're setting it in context in Menu
    const {anchorRef, renderAnchor, anchorId, open, onOpen, onClose} = React.useContext(MenuContext) as MandateProps<
      MenuContextProps,
      'anchorRef'
    >
  
    const containerRef = React.useRef<HTMLDivElement>(null)
    useMenuKeyboardNavigation(open, onClose, containerRef, anchorRef)
  
    return (
      <AnchoredOverlay
        anchorRef={anchorRef}
        renderAnchor={renderAnchor}
        anchorId={anchorId}
        open={open}
        onOpen={onOpen}
        onClose={onClose}
        align={align}
        overlayProps={overlayProps}
        focusZoneSettings={{focusOutBehavior: 'wrap'}}
      >
        <div ref={containerRef}>
          <ActionListContainerContext.Provider
            value={{
              container: 'ActionMenu',
              listRole: 'menu',
              listLabelledBy: ariaLabelledby || anchorId,
              selectionAttribute: 'aria-checked', // Should this be here?
              afterSelect: onClose,
            }}
          >
            {children}
          </ActionListContainerContext.Provider>
        </div>
      </AnchoredOverlay>
    )
  }
  
  Menu.displayName = 'ActionMenu'
  export const ActionMenu = Object.assign(Menu, {Button: MenuButton, Anchor, Overlay, Divider})
  