let renderCount = 0;
class Foo extends React.Component {
  constructor(props) {
    super(props);
    this.state = {bar: props.initialValue};
  }
  UNSAFE_componentWillMount() {
    this.setState({bar: 'bar'});
  }
  test(<Foo initialValue="foo" />, 'SPAN', 'bar');
    expect(renderCount).toBe(1);
  }
  