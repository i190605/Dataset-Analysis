class MockPortal extends React.Component<MockPortalProps> {
    container: boolean;
  
    static contextType = TriggerMockContext;
  
    componentDidMount() {
      this.createContainer();
    }
  
    createContainer() {
      this.container = true;
      this.forceUpdate();
    }
  
    render() {
      const { children } = this.props;
      if (this.container) {
        return children;
      }
      return null;
    }
  }