const SchedulerTable = (props) => {
    const history = useHistory();
    const [toast, setToast] = React.useState(false);
    const [selectedValue, setSelectedValue] = React.useState("");
    const [newValue, setNewValue] = React.useState("");
    const [openConfir, setOpenConfir] = React.useState(false);
    const [error, setError] = React.useState(false);
  
    const handleClickOpenConfir = (userId) => {
      setSelectedValue(userId);
      setOpenConfir(true);
    };
  
    const handleCloseConfir = () => {
      setOpenConfir(false);
    };
    const editUser = async (user) => {
      history.push({
        pathname: "/schedulerRegister",
        state: { user: user, role: "Student", edit: true },
      });
    };
    const removeUser = async (userId) => {
      console.log(selectedValue);
      console.log(newValue);
      if(selectedValue != "" && newValue != ""){
        try {
      const user = await Axios.post(
        "http://3.239.246.88:5000/users/delete-scheduler",
        {
          schedulerId: selectedValue,
          newSchedulerId: newValue,
        },
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${localStorage.getItem("auth_token")}`,
          }
        }
  
      );
      console.log(user);
        setToast(true);
        setTimeout(() => {
          window.location.reload();
        }, 1000);
        console.log(user);
      }
      catch (err) {
        setError("Something went wrong");
        console.log(err);
      }
     
      }
      else{
        setError("Please select a new scheduler");
      }
    };
  
    return (
      <>
        <Toast_Comp
          setToast={setToast}
          renderToast={toast}
          msg={`Scheduler deleted successfully`}
        />
        <Table breakPoint={700}>
          <Thead>
            <Tr>
              <Th>Serial No.</Th>
              <Th>Name</Th>
              <Th>Email</Th>
              <Th>Actions</Th>
            </Tr>
          </Thead>
          <Tbody>
            {(props.data && props.data).map((user, index) => (
              <Tr>
                <Td>{index + 1}</Td>
                <Td>{user.userName}</Td>
                <Td>{user.email}</Td>
                <Td>
                  <IconButton onClick={() => editUser(user)}>
                    <EditIcon color="primary" />
                  </IconButton>
                  <IconButton
                    type="button"
                    className="btn btn-sm"
                    data-bs-toggle="modal"
                    data-bs-target="#exampleModal"
                    onClick={() => handleClickOpenConfir(user._id)}
                  >
                    <DeleteIcon style={{ color: "red" }} />
                  </IconButton>
                  <div
                    className="modal fade"
                    id="exampleModal"
                    tabindex="-1"
                    aria-labelledby="exampleModalLabel"
                    aria-hidden="true"
                    open={openConfir}
                    onClose={handleCloseConfir}
                    aria-describedby="alert-dialog-description"
                  >
                    <div className="modal-dialog modal-dialog-centered">
                      <div className="modal-content">
                        <div className="modal-header">
                          <h5 className="modal-title" id="exampleModalLabel">
                            Confirm Delete
                          </h5>
                          <button
                            type="button"
                            className="btn-close"
                            data-bs-dismiss="modal"
                            aria-label="Close"
                          ></button>
                        </div>
                        <div className="modal-body text-left">
                          <div className="mt-3 mb-3">
                            <form>
                              <label>
                                Are you sure to delete the Scheduler please select
                                a new schedular?
                              </label>
                              <select className="form-control"
                                onChange={(e) => setNewValue(e.target.value)}
                              >
                                <option value="">Select schedular</option>
                                {props.data && 
                                  props.data.map((user, index) => (
                                    user._id!=selectedValue?
                                      <option value={user._id}>
                                      {user.userName}
                                    </option>:null
                                  ))} 
                              </select>
                              <span className="text-danger">
                                {error && error}
                              </span>
                            </form>
                          </div>
                        </div>
                        <div className="modal-footer">
                          <button
                            type="button"
                            className="btn btn-secondary"
                            onClick={handleCloseConfir}
                            data-bs-dismiss="modal"
                          >
                            Disagree
                          </button>
                          <button
                            type="button"
                            className="btn btn-primary"
                            onClick={() => {
                              removeUser(user._id);
                              handleCloseConfir();
                            }}
                            autoFocus
                          >
                            Agree
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </Td>
              </Tr>
            ))}
          </Tbody>
        </Table>
      </>
    );
  };
  