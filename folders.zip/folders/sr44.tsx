const shouldRenderTask = (uuid: string) => shouldRender(uuid) || shouldRenderPrerequisites(uuid);

  return (
    <>
      {shouldRenderTask(uuid) && (
        <li className="task">
          <AchievementCard
            uuid={uuid}
            focusState={focusState}
            isDropdownOpen={isDropdownOpen}
            shouldRender={isInFilter(uuid)}
            toggleDropdown={toggleDropdown}
          />
          <Collapse isOpen={isDropdownOpen} keepChildrenMounted={true}>
            <div className="prerequisite-container">
              {prerequisiteUuids.map(prerequisiteUuid => (
                <div className="prerequisite" key={prerequisiteUuid}>
                  <div
                    className="dropdown-lines"
                    style={{
                      borderBottom: `1px solid ${taskColor}`,
                      borderLeft: `1px solid ${taskColor}`
                    }}
                  ></div>
                  <AchievementCard
                    uuid={prerequisiteUuid}
                    focusState={focusState}
                    shouldRender={isInFilter(prerequisiteUuid)}
                  />
                </div>
              ))}
            </div>
          </Collapse>
        </li>
      )}
    </>
  );
};