export type PageLayoutProps = {
    /** The maximum width of the page container */
    containerWidth?: keyof typeof containerWidths
    /** The spacing between the outer edges of the page container and the viewport */
    padding?: keyof typeof SPACING_MAP
    rowGap?: keyof typeof SPACING_MAP
    columnGap?: keyof typeof SPACING_MAP
  
    /** Private prop to allow SplitPageLayout to customize slot components */
    _slotsConfig?: Record<'header' | 'footer', React.ElementType>
  } & SxProp
  
  const containerWidths = {
    full: '100%',
    medium: '768px',
    large: '1012px',
    xlarge: '1280px',
  }
  
  // TODO: refs
  const Root: React.FC<React.PropsWithChildren<PageLayoutProps>> = ({
    containerWidth = 'xlarge',
    padding = 'normal',
    rowGap = 'normal',
    columnGap = 'normal',
    children,
    sx = {},
    _slotsConfig: slotsConfig,
  }) => {
    const {rootRef, enableStickyPane, disableStickyPane, contentTopRef, contentBottomRef, stickyPaneHeight} =
      useStickyPaneHeight()
  
    const [slots, rest] = useSlots(children, slotsConfig ?? {header: Header, footer: Footer})
  
    return (
      <PageLayoutContext.Provider
        value={{
          padding,
          rowGap,
          columnGap,
          enableStickyPane,
          disableStickyPane,
          contentTopRef,
          contentBottomRef,
        }}
      >
        <Box
          ref={rootRef}
          style={{
            // @ts-ignore TypeScript doesn't know about CSS custom properties
            '--sticky-pane-height': stickyPaneHeight,
          }}
          sx={merge<BetterSystemStyleObject>({padding: SPACING_MAP[padding]}, sx)}
        >
          <Box
            sx={{
              maxWidth: containerWidths[containerWidth],
              marginX: 'auto',
              display: 'flex',
              flexWrap: 'wrap',
            }}
          >
            {slots.header}
            <Box sx={{display: 'flex', flex: '1 1 100%', flexWrap: 'wrap', maxWidth: '100%'}}>{rest}</Box>
            {slots.footer}
          </Box>
        </Box>
      </PageLayoutContext.Provider>
    )
  }
  