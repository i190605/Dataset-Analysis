import React, { useState, useEffect } from 'react';

// Define a custom context for managing data.
const DataContext = React.createContext();

// Custom data provider component.
function DataProvider({ children }) {
  const [data, setData] = useState([]);
  
  // Simulate initial data loading.
  useEffect(() => {
    fetch('/api/data')
      .then(response => response.json())
      .then(newData => {
        setData(newData);
      });
  }, []);

  return (
    <DataContext.Provider value={data}>
      {children}
    </DataContext.Provider>
  );
}

// Custom data consumer component.
function DataConsumer() {
  return (
    <DataContext.Consumer>
      {data => (
        <div>
          <h2>Data Consumer Component</h2>
          <ul>
            {/* Render data items */}
            {data.map((item, index) => (
              <li key={index}>{item}</li>
            ))}
          </ul>
        </div>
      )}
    </DataContext.Consumer>
  );
}

// Component that demonstrates the uncontrolled component smell.
function UncontrolledComponent() {
  const fileInputRef = React.createRef();

  function handleFileUpload() {
    const selectedFile = fileInputRef.current.files[0];
    const reader = new FileReader();

    reader.onload = (event) => {
      const fileData = event.target.result;
      const parsedData = parseData(fileData);
      // Do something with parsedData, but it's not managed by React state.
    };

    if (selectedFile) {
      reader.readAsText(selectedFile);
    }
  }

  function parseData(fileData) {
    // Complex data parsing logic, not utilizing React state.
    const parsedData = /* ... complex parsing logic ... */;
    return parsedData;
  }

  return (
    <div>
      <h2>Uncontrolled Component</h2>
      <input type="file" ref={fileInputRef} />
      <button onClick={handleFileUpload}>Upload File</button>
    </div>
  );
}

function App() {
  return (
    <div>
      <DataProvider>
        <DataConsumer />
      </DataProvider>
      <UncontrolledComponent />
    </div>
  );
}

export default App;
