const EditableGoal: React.FC<EditableGoalProps> = props => {
    const { uuid, isNewGoal, releaseUuid, removeCard, requestPublish } = props;
  
    const inferencer = useContext(AchievementContext);
    const goal = inferencer.getGoalDefinition(uuid);
    const goalClone = useMemo(() => cloneDeep(goal), [goal]);
  
    const [state, dispatch] = useReducer(reducer, goalClone, init);
    const [isNew, setIsNew] = useState<boolean>(isNewGoal);
    const { editableGoal, isDirty } = state;
    const { meta, text } = editableGoal;
  
    const saveChanges = () => {
      dispatch({ type: ActionType.SAVE_CHANGES });
      inferencer.modifyGoalDefinition(editableGoal);
      if (isNew) {
        releaseUuid();
        setIsNew(false);
      }
      requestPublish();
    };
  
    const discardChanges = () => dispatch({ type: ActionType.DISCARD_CHANGES, payload: goalClone });
  
    const deleteGoal = () => {
      dispatch({ type: ActionType.DELETE_GOAL });
      inferencer.removeGoalDefinition(uuid);
      if (isNew) {
        releaseUuid();
        setIsNew(false);
      }
      removeCard(uuid);
      requestPublish();
    };
  
    const changeMeta = (meta: GoalMeta) => dispatch({ type: ActionType.CHANGE_META, payload: meta });
  
    const changeText = (text: string) => dispatch({ type: ActionType.CHANGE_TEXT, payload: text });
  
    return (
      <li className="editable-goal" id={uuid}>
        <div className="action-button">
          {isDirty ? (
            <ItemSaver discardChanges={discardChanges} saveChanges={saveChanges} />
          ) : (
            <ItemDeleter deleteItem={deleteGoal} item={text} />
          )}
        </div>
        <h3>
          <EditableText onChange={changeText} placeholder="Enter goal text here" value={text} />
        </h3>
        <div className="meta">
          <EditableMeta changeMeta={changeMeta} meta={meta} />
        </div>
      </li>
    );
  };
  