<style jsx>
          {`
            button {
              display: inline-block;
            }

            .choose-image,
            .random-image {
              padding: 8px;
            }

            .choose-image > button {
              cursor: pointer;
              color: white;
              background: transparent;
              border: none;
              outline: none;
              padding: 0;
              margin: 0 8px 8px 0;
            }

            .choose-image > button:not(.active) {
              opacity: 0.4;
            }

            .choose-image > button:focus {
              text-decoration: underline;
            }

            form {
              display: flex;
              justify-content: space-between;
            }

            form > button {
              padding: 1px 18px 2px 7px;
            }

            span {
              display: block;
              margin-bottom: 16px;
            }

            a {
              text-decoration: underline;
            }

            hr {
              border-bottom: none;
              margin-bottom: 0;
              margin-top: 0;
            }

            .error {
              color: red;
              margin-top: 8px;
            }
          `}
        </style>
      </div>
    )

    if (this.state.dataURL) {
      content = (
        <div className="settings-container">
          <div className="image-container">
            <div className="label">
              <span>Background image</span>
              <button onClick={this.removeImage}>&times;</button>
            </div>
            <ReactCrop
              src={this.state.dataURL}
              onImageLoaded={this.onImageLoaded}
              crop={this.state.crop}
              onChange={this.onCropChange}
              onDragEnd={this.onDragEnd}
              minHeight={10}
              minWidth={10}
              keepSelection
            />
            {this.state.photographer && <PhotoCredit photographer={this.state.photographer} />}
          </div>
          <style jsx>
       