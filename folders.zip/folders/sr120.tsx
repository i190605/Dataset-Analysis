const MarkdownViewer = ({
    dangerousRenderedHTML,
    loading = false,
    markdownValue = '',
    onChange: externalOnChange,
    disabled = false,
    onLinkClick,
    openLinksInNewTab = false,
  }: MarkdownViewerProps) => {
    // We're using state to store the HTML container because we want the value
    // to re-run effects when it changes
    const [htmlContainer, setHtmlContainer] = React.useState<HTMLElement>()
    const htmlContainerRef = React.useCallback((node: HTMLElement | null) => {
      if (!node) return
      setHtmlContainer(node)
    }, [])
  
    const onChange = useCallback(
      async (value: string) => {
        try {
          await externalOnChange?.(value)
        } catch (error) {
          if (htmlContainer) {
            htmlContainer.innerHTML = dangerousRenderedHTML.__html as string
          }
        }
      },
      [externalOnChange, htmlContainer, dangerousRenderedHTML],
    )
  
    useListInteraction({
      onChange,
      disabled: disabled || !externalOnChange,
      htmlContainer,
      markdownValue,
      dependencies: [dangerousRenderedHTML],
    })
  
    useLinkInterception({
      htmlContainer,
      onLinkClick,
      openLinksInNewTab,
    })
  
    return loading ? (
      <Box sx={{display: 'flex', justifyContent: 'space-around', p: 2}}>
        <Spinner aria-label="Loading content..." />
      </Box>
    ) : (
      <Box
        ref={htmlContainerRef}
        className="markdown-body"
        sx={{fontSize: 1, maxWidth: '100%', '& > div > :last-child': {mb: 0}}}
        dangerouslySetInnerHTML={dangerousRenderedHTML}
      />
    )
  }
  