export const AnchoredOverlay: React.FC<React.PropsWithChildren<AnchoredOverlayProps>> = ({
    renderAnchor,
    anchorRef: externalAnchorRef,
    anchorId: externalAnchorId,
    children,
    open,
    onOpen,
    onClose,
    height,
    width,
    overlayProps,
    focusTrapSettings,
    focusZoneSettings,
    side = 'outside-bottom',
    align = 'start',
    alignmentOffset,
    anchorOffset,
  }) => {
    const anchorRef = useProvidedRefOrCreate(externalAnchorRef)
    const [overlayRef, updateOverlayRef] = useRenderForcingRef<HTMLDivElement>()
    const anchorId = useId(externalAnchorId)
  
    const onClickOutside = useCallback(() => onClose?.('click-outside'), [onClose])
    const onEscape = useCallback(() => onClose?.('escape'), [onClose])
  
    const onAnchorKeyDown = useCallback(
      (event: React.KeyboardEvent<HTMLElement>) => {
        if (!event.defaultPrevented) {
          if (!open && ['ArrowDown', 'ArrowUp', ' ', 'Enter'].includes(event.key)) {
            onOpen?.('anchor-key-press', event)
            event.preventDefault()
          }
        }
      },
      [open, onOpen],
    )
    const onAnchorClick = useCallback(
      (event: React.MouseEvent<HTMLElement>) => {
        if (event.defaultPrevented || event.button !== 0) {
          return
        }
        if (!open) {
          onOpen?.('anchor-click')
        } else {
          onClose?.('anchor-click')
        }
      },
      [open, onOpen, onClose],
    )
  
    const {position} = useAnchoredPosition(
      {
        anchorElementRef: anchorRef,
        floatingElementRef: overlayRef,
        side,
        align,
        alignmentOffset,
        anchorOffset,
      },
      [overlayRef.current],
    )
  
    useEffect(() => {
      // ensure overlay ref gets cleared when closed, so position can reset between closing/re-opening
      if (!open && overlayRef.current) {
        updateOverlayRef(null)
      }
    }, [open, overlayRef, updateOverlayRef])
  
    useFocusZone({
      containerRef: overlayRef,
      disabled: !open || !position,
      ...focusZoneSettings,
    })
    useFocusTrap({containerRef: overlayRef, disabled: !open || !position, ...focusTrapSettings})
  
    return (
      <>
        {renderAnchor &&
          renderAnchor({
            ref: anchorRef,
            id: anchorId,
            'aria-haspopup': 'true',
            'aria-expanded': open ? 'true' : undefined,
            tabIndex: 0,
            onClick: onAnchorClick,
            onKeyDown: onAnchorKeyDown,
          })}
        {open ? (
          <Overlay
            returnFocusRef={anchorRef}
            onClickOutside={onClickOutside}
            ignoreClickRefs={[anchorRef]}
            onEscape={onEscape}
            ref={updateOverlayRef}
            role="none"
            visibility={position ? 'visible' : 'hidden'}
            height={height}
            width={width}
            top={position?.top || 0}
            left={position?.left || 0}
            anchorSide={position?.anchorSide}
            {...overlayProps}
          >
            {children}
          </Overlay>
        ) : null}
      </>
    )
  }
  
  AnchoredOverlay.displayName = 'AnchoredOverlay'
  