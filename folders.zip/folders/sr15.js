class Parent extends React.Component {
    handleChange = val => {
      didCallOnChange = true;
    };
    render() {
      return (
        <div>
          <Child />
          <input
            ref={inputRef}
            type="checkbox"
            checked={true}
            onChange={this.handleChange}
          />
        </div>
      );
    }
  }
