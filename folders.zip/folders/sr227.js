import React, { Component } from 'react';

class UncontrolledWeatherWidget extends Component {
  constructor(props) {
    super(props);
    this.locationInputRef = React.createRef();
  }

  handleFetchWeather = () => {
    const location = this.locationInputRef.current.value;
    // Fetch weather data for the location from an external API.
    alert(`Fetching weather data for ${location}`);
  }

  render() {
    return (
      <div>
        <h2>Weather Widget</h2>
        <div>
          <label>Location:</label>
          <input type="text" ref={this.locationInputRef} />
        </div>
        <div>
          <button onClick={this.handleFetchWeather}>Fetch Weather</button>
        </div>
      </div>
    );
  }
}
