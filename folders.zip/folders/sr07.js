const Component = ({show}) => {
    const ref = React.useRef(null);

    React.useEffect(() => {
      const clear1 = setAfterBlurHandle(document, onAfterBlur);
      const clear2 = setBeforeBlurHandle(ref.current, onBeforeBlur);

      return () => {
        clear1();
        clear2();
      };
    });

    return (
      <div ref={ref}>
        {show && <input ref={innerRef} />}
        <div ref={innerRef2} />
      </div>
    );
  };
