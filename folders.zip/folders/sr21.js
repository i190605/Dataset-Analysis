function App() {
    return (
      <form action={action}>
        <input type="hidden" name="bar" defaultValue="baz" ref={hiddenRef} />
        <input type="text" name="foo" defaultValue="bar" />
      </form>
    );
  }
