static defaultProps = {
    isOpen: true,
    hasArrow: false,
    hasBackground: true,
    verticalAttachments: ["top", "bottom"],
    horizontalAttachments: ["left", "right"],
    alignVerticalEdge: false,
    alignHorizontalEdge: true,
    targetOffsetX: 0,
    targetOffsetY: 5,
    sizeToFit: false,
    autoWidth: false,
    noOnClickOutsideWrapper: false,
    containerClassName: "",
    ignoreTrigger: false,
  };

  _getPopoverElement(isOpen) {
    // 3s is an overkill for Cypress, but let's start with it and dial it down
    // if we see that the flakes don't appear anymore
    const resizeTimer = isCypressActive ? 3000 : 100;

    if (!this._popoverElement && isOpen) {
      this._popoverElement = document.createElement("span");
      this._popoverElement.className = `PopoverContainer ${this.props.containerClassName}`;
      document.body.appendChild(this._popoverElement);
      this._timer = setInterval(() => {
        const { width, height } = this._popoverElement.getBoundingClientRect();
        if (this.state.width !== width || this.state.height !== height) {
          this.setState({ width, height });
        }
      }, resizeTimer);
    }
    return this._popoverElement;
  }

  componentDidMount() {
    this.updateComponentPosition(this.props.isOpen);
  }

  updateComponentPosition(isOpen) {
    if (!isOpen) {
      return;
    }

    const tetherOptions = {
      element: this._popoverElement,
      target: this._getTargetElement(),
    };

    if (!this._best || !this.props.pinInitialAttachment) {
      let best = {
        attachmentX: "center",
        attachmentY: "top",
        targetAttachmentX: "center",
        targetAttachmentY: "bottom",
        offsetX: 0,
        offsetY: 0,
      };

      // horizontal
      best = this._getBestAttachmentOptions(
        tetherOptions,
        best,
        this.props.horizontalAttachments,
        ["left", "right"],
        (best, attachmentX) => ({
          ...best,
          attachmentX: attachmentX,
          targetAttachmentX: this.props.alignHorizontalEdge
            ? attachmentX
            : "center",
          offsetX: {
            center: 0,
            left: -this.props.targetOffsetX,
            right: this.props.targetOffsetX,
          }[attachmentX],
        }),
      );

      // vertical
      best = this._getBestAttachmentOptions(
        tetherOptions,
        best,
        this.props.verticalAttachments,
        ["top", "bottom"],
        (best, attachmentY) => ({
          ...best,
          attachmentY: attachmentY,
          targetAttachmentY: (
            this.props.alignVerticalEdge
              ? attachmentY === "bottom"
              : attachmentY === "top"
          )
            ? "bottom"
            : "top",
          offsetY: {
            top: this.props.targetOffsetY,
            bottom: -this.props.targetOffsetY,
          }[attachmentY],
        }),
      );

      this._best = best;
    }

    if (this.props.sizeToFit) {
      if (this._best.targetAttachmentY === "top") {
        this.constrainPopoverToBetweenViewportAndTarget(tetherOptions, "top");
      } else if (this._best.targetAttachmentY === "bottom") {
        this.constrainPopoverToBetweenViewportAndTarget(
          tetherOptions,
          "bottom",
        );
      }
    }

    // finally set the best options
    this._setTetherOptions(tetherOptions, this._best);
  }

  componentDidUpdate() {
    this.updateComponentPosition(this.props.isOpen);
  }

  componentWillUnmount() {
    if (this._tether) {
      this._tether.destroy();
      delete this._tether;
    }
    if (this._popoverElement) {
      ReactDOM.unmountComponentAtNode(this._popoverElement);
      if (this._popoverElement.parentNode) {
        this._popoverElement.parentNode.removeChild(this._popoverElement);
      }
      delete this._popoverElement;
      clearInterval(this._timer);
      delete this._timer;
    }
  }

  handleDismissal(...args) {
    if (this.props.onClose) {
      this.props.onClose(...args);
    }
  }

  _popoverComponent() {
    const childProps = {
      maxHeight: this._getMaxHeight(),
    };
    const content = (
      <div
        id={this.props.id}
        className={cx(
          "PopoverBody",
          {
            "PopoverBody--withBackground": this.props.hasBackground,
            "PopoverBody--withArrow":
              this.props.hasArrow && this.props.hasBackground,
            "PopoverBody--autoWidth": this.props.autoWidth,
          },
          // TODO kdoh 10/16/2017 we should eventually remove this
          this.props.className,
        )}
        role={this.props.role}
        style={this.props.style}
      >
        {typeof this.props.children === "function"
          ? this.props.children(childProps)
          : React.Children.count(this.props.children) === 1 &&
            // NOTE: workaround for https://github.com/facebook/react/issues/12136
            !Array.isArray(this.props.children)
          ? React.cloneElement(
              React.Children.only(this.props.children),
              childProps,
            )
          : this.props.children}
      </div>
    );
    if (this.props.noOnClickOutsideWrapper) {
      return content;
    } else {
      return (
        <OnClickOutsideWrapper
          handleDismissal={this.handleDismissal}
          ignoreElement={
            this.props.ignoreTrigger ? this._getTargetElement() : undefined
          }
        >
          {content}
        </OnClickOutsideWrapper>
      );
    }
  }

  _setTetherOptions(tetherOptions, o) {
    if (o) {
      tetherOptions = {
        ...tetherOptions,
        attachment: `${o.attachmentY} ${o.attachmentX}`,
        targetAttachment: `${o.targetAttachmentY} ${o.targetAttachmentX}`,
        targetOffset: `${o.offsetY}px ${o.offsetX}px`,
      };
    }
    if (this._tether) {
      this._tether.setOptions(tetherOptions);
    } else {
      this._tether = new Tether(tetherOptions);
    }
  }

  _getMaxHeight() {
    const { top, bottom } = this._getTargetElement().getBoundingClientRect();

    let attachments;
    if (this.props.pinInitialAttachment && this._best) {
      // if we have a pinned attachment only use that
      attachments = [this._best.attachmentY];
    } else {
      // otherwise use the verticalAttachments prop
      attachments = this.props.verticalAttachments;
    }

    const availableHeights = attachments.map(attachmentY =>
      attachmentY === "top"
        ? window.innerHeight - bottom - this.props.targetOffsetY - PAGE_PADDING
        : attachmentY === "bottom"
        ? top - this.props.targetOffsetY - PAGE_PADDING
        : 0,
    );

    // get the largest available height, then subtract .PopoverBody's border and padding
    return Math.max(...availableHeights) - POPOVER_BODY_PADDING;
  }
