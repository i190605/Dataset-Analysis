import React, { Component } from 'react';

class UncontrolledRadioButtons extends Component {
  handleRadioChange = () => {
    const selectedRadio = document.querySelector('input[name="radio"]:checked');
    alert(`Selected radio: ${selectedRadio.value}`);
  }

  render() {
    return (
      <div>
        <input type="radio" name="radio" value="option1" onChange={this.handleRadioChange} /> Option 1
        <input type="radio" name="radio" value="option2" onChange={this.handleRadioChange} /> Option 2
        <input type="radio" name="radio" value="option3" onChange={this.handleRadioChange} /> Option 3
      </div>
    );
  }
}
