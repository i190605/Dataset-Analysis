class Timestamp extends PureComponent<Props, State> {
    constructor(props: Props) {
        super(props);
        this.state = {
            now: new Date(),
            prevValue: props.value,
        };
    }

    static defaultProps: Partial<Props> = {

        // relative
        numeric: 'auto',
        style: 'long',
        relNearest: 1,

        // fixed
        year: 'numeric',
        month: 'long',
        day: '2-digit',
        weekday: 'long',
        hour: 'numeric',
        minute: 'numeric',
        second: 'numeric',
        hourCycle: 'h12',
        timeZoneName: 'short',
    };
    nextUpdate: ReturnType<typeof setTimeout> | null = null;
    mounted = false;

    componentDidMount() {
        this.mounted = true;
    }

    formatParts(value: Date, {relative: relFormat, date: dateFormat, time: timeFormat}: ResolvedFormats): FormattedParts {
        try {
            let relative: FormattedParts['relative'];
            let date: FormattedParts['date'];
            let time: FormattedParts['time'];

            if (isSimpleRelative(relFormat)) {
                relative = relFormat.message;
            } else if (isRelative(relFormat)) {
                relative = this.formatRelative(value, relFormat);

                if (relFormat.unit !== 'day' || !timeFormat) {
                    return {relative};
                }
            }

            if (relative == null && dateFormat) {
                date = this.formatDateTime(value, dateFormat);
            }

            if (timeFormat) {
                const {
                    hourCycle,
                    hour12 = supportsHourCycle ? undefined : is12HourTime(hourCycle),
                } = this.props;

                time = this.formatDateTime(value, {hourCycle, hour12, ...timeFormat});
            }

            return {relative, date, time};
        } catch {
            // fallback to moment for unsupported timezones
            const {timeZone, hourCycle, hour12} = this.props;

            const momentValue = moment.utc(value.getTime());

            if (timeZone) {
                momentValue.tz(timeZone);
            }

            return {
                date: dateFormat && Timestamp.momentDate(momentValue, {...dateFormat}),
                time: timeFormat && Timestamp.momentTime(momentValue, {hourCycle, hour12, ...timeFormat}),
            };
        }
    }

    formatRelative(value: Date, {unit, relNearest, truncateEndpoints, ...format}: RelativeOptions): string {
        let diff: number;

        if (relNearest === 0) {
            diff = 0;
        } else {
            diff = getDiff(value, this.state.now, this.props.timeZone, unit, truncateEndpoints);
            if (relNearest != null) {
                diff = Math.round(diff / relNearest) * relNearest;
            }
        }

        if (diff === 0) {
            diff = value <= this.state.now ? -0 : +0;
        }

        const rel = this.props.intl.formatRelativeTime(diff, unit, format);
        return format.capitalize ? caps(rel) : rel;
    }

    formatDateTime(value: Date, format: DateTimeOptions): string {
        const {timeZone, intl: {locale}} = this.props;

        return (new Intl.DateTimeFormat(locale, {timeZone, ...format} as any)).format(value); // TODO remove any when React-Intl is next updated
    }

    static momentTime(value: Moment, {hour, minute, hourCycle, hour12}: DateTimeOptions): string | undefined {
        if (hour && minute) {
            return value.format(is12HourTime(hourCycle, hour12) ? 'h:mm A' : 'HH:mm');
        }
        return undefined;
    }

    static momentDate(value: Moment, {weekday, day, month, year}: DateTimeOptions): string | undefined {
        if (weekday && day && month && year) {
            return value.format('dddd, MMMM DD, YYYY');
        } else if (day && month && year) {
            return value.format('MMMM DD, YYYY');
        } else if (day && month) {
            return value.format('MMMM DD');
        } else if (weekday) {
            return value.format('dddd');
        }
        return undefined;
    }

    autoRange(value: Date, units: Props['units'] = (this.props.units || this.props.ranges)): DisplayAs {
        return units?.map(normalizeRangeDescriptor).find(({equals, within}) => {
            if (equals != null) {
                return isEqual(value, this.state.now, this.props.timeZone, ...equals);
            }
            if (within != null) {
                return isWithin(value, this.state.now, this.props.timeZone, ...within);
            }
            return false;
        }) ?? {
            display: [this.props.unit],
            updateIntervalInSeconds: this.props.updateIntervalInSeconds,
        };
    }

    private getFormats(value: Date): ResolvedFormats {
        const {
            numeric,
            style,
            useRelative = (): ResolvedFormats['relative'] => {
                const {
                    display,
                    updateIntervalInSeconds = this.props.updateIntervalInSeconds,
                    capitalize = this.props.capitalize,
                } = this.autoRange(value);

                if (display) {
                    if (isValidElementType(display) || !Array.isArray(display)) {
                        return {
                            message: display,
                            updateIntervalInSeconds,
                        };
                    }

                    const [
                        unit,
                        relNearest = this.props.relNearest,
                        truncateEndpoints = this.props.truncateEndpoints,
                    ] = display as UnitDescriptor;

                    if (unit) {
                        return {
                            unit,
                            relNearest,
                            truncateEndpoints,
                            numeric,
                            style,
                            updateIntervalInSeconds: updateIntervalInSeconds ?? defaultRefreshIntervals.get(unit),
                            capitalize,
                        };
                    }
                }

                return false;
            },
            year,
            month,
            day,
            weekday,
            hour,
            minute,
            timeZone,
            useDate = (): ResolvedFormats['date'] => {
                if (isWithin(value, this.state.now, timeZone, 'day', -6)) {
                    return {weekday};
                }
                if (isSameYear(value)) {
                    return {day, month};
                }

                return {year, month, day};
            },
            useTime = {hour, minute},
        } = this.props;

        const relative = resolve(useRelative, {value}, this.props);
        const date = !relative && resolve(useDate, {value}, this.props);
        const time = resolve(useTime, {value}, this.props);

        return {relative, date, time};
    }

    componentWillUnmount() {
        this.mounted = false;
        if (this.nextUpdate) {
            clearTimeout(this.nextUpdate);
            this.nextUpdate = null;
        }
    }

    static getDerivedStateFromProps(props: Props, state: State) {
        if (props.value !== state.prevValue) {
            return ({now: new Date(), prevValue: props.value});
        }

        return null;
    }

    private maybeUpdate(relative: ResolvedFormats['relative']): ReturnType<typeof setTimeout> | null {
        if (!relative ||
            !relative.updateIntervalInSeconds) {
            return null;
        }
        return setTimeout(() => {
            if (this.mounted) {
                this.setState({now: new Date()});
            }
        }, relative.updateIntervalInSeconds * 1000);
    }

    static format({relative, date, time}: FormattedParts): ReactNode {
        return (relative || date) && time ? (
            <FormattedMessage
                id='timestamp.datetime'
                defaultMessage='{relativeOrDate} at {time}'
                values={{
                    relativeOrDate: relative || date,
                    time,
                }}
            />
        ) : relative || date || time;
    }

    static formatLabel(value: Date, timeZone?: string) {
        const momentValue = moment(value);

        if (timeZone) {
            momentValue.tz(timeZone);
        }

        return momentValue.toString() + (timeZone ? ` (${momentValue.tz()})` : '');
    }

    render() {
        const {
            value: unparsed = this.state.now,
            children,
            useSemanticOutput = true,
            timeZone,
            label,
            className,
        } = this.props;

        const value = unparsed instanceof Date ? unparsed : new Date(unparsed);
        const formats = this.getFormats(value);
        const parts = this.formatParts(value, formats);
        let formatted = Timestamp.format(parts);

        if (useSemanticOutput) {
            formatted = (
                <SemanticTime
                    value={value}
                    aria-label={label}
                    className={className}
                >
                    {formatted}
                </SemanticTime>
            );
        }

        this.nextUpdate = this.maybeUpdate(formats.relative);

        if (children) {
            return resolve(children, {value, timeZone, formatted, ...parts}, formats);
        }

        return formatted;
    }
}

export default injectIntl(Timestamp);
