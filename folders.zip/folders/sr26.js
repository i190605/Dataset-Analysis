class Baz extends React.Component {
    UNSAFE_componentWillMount() {
      this.forceUpdate();
      setTimeout(() => {
        this.forceUpdate();
      });
    }

    render() {
      return <div onClick={() => {}} />;
    }
  }

  ReactDOMServer.renderToString(<Baz />);
  expect(() => jest.runOnlyPendingTimers()).toErrorDev(
    'Warning: forceUpdate(...): Can only update a mounting component. ' +
      'This usually means you called forceUpdate() outside componentWillMount() on the server. ' +
      'This is a no-op.\n\nPlease check the code for the Baz component.',
    {withoutStack: true},
  );
  const markup = ReactDOMServer.renderToStaticMarkup(<Baz />);
  expect(markup).toBe('<div></div>');


it('does not get confused by throwing null', () => {
  function Bad() {
    // eslint-disable-next-line no-throw-literal
    throw null;
  }

  let didError;
  let error;
  try {
    ReactDOMServer.renderToString(<Bad />);
  } catch (err) {
    didError = true;
    error = err;
  }
  expect(didError).toBe(true);
  expect(error).toBe(null);
});

it('does not get confused by throwing undefined', () => {
  function Bad() {
    // eslint-disable-next-line no-throw-literal
    throw undefined;
  }

  let didError;
  let error;
  try {
    ReactDOMServer.renderToString(<Bad />);
  } catch (err) {
    didError = true;
    error = err;
  }
  expect(didError).toBe(true);
  expect(error).toBe(undefined);
});
