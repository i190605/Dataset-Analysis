const TimeTables = (props) => {

    const history= useHistory();
    const classes = useStyles();
    const [timeTableList, setTimeTableList] = useState([]);
    
    const editTimetable =async(user)=>{
      history.push({
        pathname: "/classRegister",
        state: { 
          user: props.data && props.data,
          timeTable: user,
          role: "Student",
          edit: true,
          register: false,
      }
      });
      
    }
    const removeTimetable = async (userId) => {
      try {
        console.log(userId)
        const user = await Axios.get(`http://3.239.246.88:5000/users/timetable/delete/${userId}`,{
          headers:{
              "Authorization":"Bearer "+localStorage.getItem("auth_token")  
          }
        })
        //setToast(true)
        if(user){
          console.log("deleted")
          window.location.reload()
        }
      }
      catch (err){
        console.log(err)
      }
      
      
    };
    return (
      <>
        <Table breakPoint={700}>
        <Thead>
            <Tr>
                <Th>Slot</Th>
                <Th>Monday</Th>
                <Th>Tuesday</Th>
                <Th>Wednesday</Th>
                <Th>Thursday</Th>
                <Th>Friday</Th>
                <Th>Saturday</Th>
                <Th>Sunday</Th>
            </Tr>
        </Thead>
        <Tbody>
              {props && props.timeTableList && props.timeTableList.map((time) => {
                return(
                    <Tr>
                    <Td >{time.TeacherStartTime} - {time.TeacherEndTime}</Td>
                    {time.Day=="Monday" ? <Td style={{backgroundColor:time.makeUp && "yellow"}}>{props && props.teachers.map((teacher) => {
                      console.log(teacher)
                      if(time.teacher == teacher._id)
                      return teacher.userName
                      else 
                      return ""
                      
                    })} <Td style={{ display: "flex",   alignItems:"center",
                    justifyContent:"center"}}><IconButton onClick={()=>editTimetable(time)} size="small">
                    <EditIcon color="primary" fontSize="inherit"/>
                  </IconButton>
                  <IconButton onClick={() => removeTimetable(time._id)} size="small">
                    <DeleteIcon style={{ color: "red" }} fontSize="inherit"/>
                  </IconButton></Td></Td> : <Td></Td>}
                    {time.Day=="Tuesday" ? <Td style={{backgroundColor:time.makeUp && "yellow"}}>{props && props.teachers.map((teacher) => {
                      console.log(teacher, time)
                      if(time.teacher == teacher._id)
                      return teacher.userName
                      else 
                      return ""
                    })}<Td style={{ display: "flex",   alignItems:"center",
                    justifyContent:"center"}}><IconButton onClick={()=>editTimetable(time)} size="small">
                    <EditIcon color="primary" fontSize="inherit"/>
                  </IconButton>
                  <IconButton onClick={() => removeTimetable(time._id)} size="small">
                    <DeleteIcon style={{ color: "red" }} fontSize="inherit"/>
                  </IconButton></Td></Td> : <Td></Td>}
                    {time.Day=="Wednesday" ? <Td style={{backgroundColor:time.makeUp && "yellow"}}>{props && props.teachers.map((teacher) => {
                      console.log(teacher)
                      if(time.teacher == teacher._id)
                      return teacher.userName
                      else 
                      return ""
                    })}<Td style={{ display: "flex",   alignItems:"center",
                    justifyContent:"center"}}><IconButton onClick={()=>editTimetable(time)} size="small">
                    <EditIcon color="primary" fontSize="inherit"/>
                  </IconButton>
                  <IconButton onClick={() => removeTimetable(time._id)} size="small">
                    <DeleteIcon style={{ color: "red" }} fontSize="inherit"/>
                  </IconButton></Td></Td> : <Td></Td>}
                    {time.Day=="Thursday" ? <Td style={{backgroundColor:time.makeUp && "yellow"}}>{props && props.teachers.map((teacher) => {
                      console.log(teacher)
                      if(time.teacher == teacher._id)
                      return teacher.userName
                      else 
                      return ""
                    })}<Td style={{ display: "flex",   alignItems:"center",
                    justifyContent:"center"}}><IconButton onClick={()=>editTimetable(time)} size="small">
                    <EditIcon color="primary" fontSize="inherit"/>
                  </IconButton>
                  <IconButton onClick={() => removeTimetable(time._id)} size="small">
                    <DeleteIcon style={{ color: "red" }} fontSize="inherit"/>
                  </IconButton></Td></Td> : <Td></Td>}
                    {time.Day=="Friday" ? <Td style={{backgroundColor:time.makeUp && "yellow"}}>{props && props.teachers.map((teacher) => {
                      console.log(teacher)
                      if(time.teacher == teacher._id)
                      return teacher.userName
                      else 
                      return ""
                    })}<Td style={{ display: "flex",   alignItems:"center",
                    justifyContent:"center"}}><IconButton onClick={()=>editTimetable(time)} size="small">
                    <EditIcon color="primary" fontSize="inherit"/>
                  </IconButton>
                  <IconButton onClick={() => removeTimetable(time._id)} size="small">
                    <DeleteIcon style={{ color: "red" }} fontSize="inherit"/>
                  </IconButton></Td></Td> : <Td></Td>}
                    {time.Day=="Saturday" ? <Td style={{backgroundColor:time.makeUp && "yellow"}}>{props && props.teachers.map((teacher) => {
                      console.log(teacher)
                      if(time.teacher == teacher._id)
                      return teacher.userName
                      else 
                      return ""
                    })}<Td style={{ display: "flex",   alignItems:"center",
                    justifyContent:"center"}}><IconButton onClick={()=>editTimetable(time)} size="small">
                    <EditIcon color="primary" fontSize="inherit"/>
                  </IconButton>
                  <IconButton onClick={() => removeTimetable(time._id)} size="small">
                    <DeleteIcon style={{ color: "red" }} fontSize="inherit"/>
                  </IconButton></Td></Td> : <Td></Td>}
                    {time.Day=="Sunday" ? <Td style={{backgroundColor:time.makeUp && "yellow"}}>{props && props.teachers.map((teacher) => {
                      console.log(teacher)
                      if(time.teacher == teacher._id)
                      return teacher.userName
                      else 
                      return ""
                    })}<Td style={{ display: "flex",   alignItems:"center",
                    justifyContent:"center"}}><IconButton onClick={()=>editTimetable(time)} size="small">
                    <EditIcon color="primary" fontSize="inherit"/>
                  </IconButton>
                  <IconButton onClick={() => removeTimetable(time._id)} size="small">
                    <DeleteIcon style={{ color: "red" }} fontSize="inherit"/>
                  </IconButton></Td></Td> : <Td></Td>}
                    </Tr>
                )
              })
              }
        </Tbody>
    </Table>
   </>
    );
    };
  