function App({isUpdate}) {
    return (
      <form action={isUpdate ? undefined : action} ref={formRef}>
        <input
          type="submit"
          formAction={isUpdate ? undefined : action}
          ref={inputRef}
        />
        <button formAction={isUpdate ? undefined : action} ref={buttonRef} />
      </form>
    );
  }
