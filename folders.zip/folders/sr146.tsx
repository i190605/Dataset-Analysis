export function ModalBase(props: ModalBaseProps) {
    const {
      opened,
      onClose,
      children,
      closeOnClickOutside,
      __staticSelector,
      transitionProps,
      withinPortal,
      portalProps,
      keepMounted,
      target,
      zIndex,
      lockScroll,
      trapFocus,
      closeOnEscape,
      returnFocus,
      padding,
      shadow,
      id,
      size,
      variant,
      classNames,
      unstyled,
      styles,
      className,
      ...others
    } = useComponentDefaultProps('ModalBase', ModalBaseDefaultProps, props);
  
    const { classes, cx } = useStyles(null, {
      name: __staticSelector,
      classNames,
      styles,
      unstyled,
      variant,
      size,
    });
  
    const _id = useId(id);
    const [titleMounted, setTitleMounted] = useState(false);
    const [bodyMounted, setBodyMounted] = useState(false);
  
    const transitionDuration =
      typeof transitionProps?.duration === 'number' ? transitionProps?.duration : 200;
  
    const shouldLockScroll = useLockScroll({ opened, transitionDuration });
  
    useWindowEvent('keydown', (event) => {
      if (!trapFocus && event.key === 'Escape' && closeOnEscape) {
        onClose();
      }
    });
  
    useFocusReturn({ opened, shouldReturnFocus: trapFocus && returnFocus });
  
    return (
      <OptionalPortal {...portalProps} withinPortal={withinPortal} target={target}>
        <ModalBaseProvider
          value={{
            __staticSelector,
            opened,
            onClose,
            closeOnClickOutside,
            transitionProps: { ...transitionProps, duration: transitionDuration, keepMounted },
            zIndex,
            padding,
            id: _id,
            getTitleId: () => `${_id}-title`,
            getBodyId: () => `${_id}-body`,
            titleMounted,
            bodyMounted,
            setTitleMounted,
            setBodyMounted,
            trapFocus,
            closeOnEscape,
            shadow,
            stylesApi: {
              name: __staticSelector,
              size,
              variant,
              classNames,
              styles,
              unstyled,
            },
          }}
        >
          <RemoveScroll enabled={shouldLockScroll && lockScroll}>
            <Box className={cx(classes.root, className)} {...others}>
              {children}
            </Box>
          </RemoveScroll>
        </ModalBaseProvider>
      </OptionalPortal>
    );
  }