import React, { Component } from 'react';

class UncontrolledPasswordInput extends Component {
  handlePasswordChange = () => {
    const passwordInput = this.passwordInputRef.current;
    alert(`Entered password: ${passwordInput.value}`);
  }

  render() {
    return (
      <div>
        <input type="password" onChange={this.handlePasswordChange} ref={this.passwordInputRef} />
      </div>
    );
  }
}
