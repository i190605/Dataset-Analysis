export class LegendItem extends PureComponent<LegendItemProps, LegendItemState> {
    static defaultProps = {
      asTable: false,
      hidden: false,
      onLabelClick: () => {},
      onColorChange: () => {},
      onToggleAxis: () => {},
    };
  
    constructor(props: LegendItemProps) {
      super(props);
      this.state = {
        yaxis: this.props.series.yaxis,
      };
    }
  
    onLabelClick = (e: any) => this.props.onLabelClick(this.props.series, e);
  
    onToggleAxis = () => {
      const yaxis = this.state.yaxis === 2 ? 1 : 2;
      const info = { alias: this.props.series.alias, yaxis: yaxis };
      this.setState({ yaxis: yaxis });
      this.props.onToggleAxis(info);
    };
  
    onColorChange = (color: string) => {
      this.props.onColorChange(this.props.series, color);
      // Because of PureComponent nature it makes only shallow props comparison and changing of series.color doesn't run
      // component re-render. In this case we can't rely on color, selected by user, because it may be overwritten
      // by series overrides. So we need to use forceUpdate() to make sure we have proper series color.
      this.forceUpdate();
    };
  
    renderLegendValues() {
      const { series, asTable } = this.props;
      const legendValueItems = [];
      for (const valueName of LEGEND_STATS) {
        // @ts-ignore
        if (this.props[valueName]) {
          const valueFormatted = series.formatValue(series.stats[valueName]);
          legendValueItems.push(
            <LegendValue
              key={valueName}
              valueName={valueName}
              value={valueFormatted}
              asTable={asTable}
              onValueClick={this.onLabelClick}
            />
          );
        }
      }
      return legendValueItems;
    }
  
    render() {
      const { series, values, asTable, hidden } = this.props;
      const seriesOptionClasses = classNames({
        'graph-legend-series-hidden': hidden,
        'graph-legend-series--right-y': series.yaxis === 2,
      });
      const valueItems = values ? this.renderLegendValues() : [];
      const seriesLabel = (
        <LegendSeriesLabel
          label={series.alias}
          color={series.color}
          yaxis={this.state.yaxis}
          onLabelClick={this.onLabelClick}
          onColorChange={this.onColorChange}
          onToggleAxis={this.onToggleAxis}
        />
      );
  
      if (asTable) {
        return (
          <tr className={`graph-legend-series ${seriesOptionClasses}`}>
            <td role="gridcell">
              <div className="graph-legend-series__table-name">{seriesLabel}</div>
            </td>
            {valueItems}
          </tr>
        );
      } else {
        return (
          <div className={`graph-legend-series ${seriesOptionClasses}`}>
            {seriesLabel}
            {valueItems}
          </div>
        );
      }
    }
  }
  