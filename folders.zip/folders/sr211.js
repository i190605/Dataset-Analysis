import React, { Component } from 'react';

class UncontrolledRangeInput extends Component {
  handleRangeChange = () => {
    const rangeInput = this.rangeInputRef.current;
    alert(`Selected value: ${rangeInput.value}`);
  }

  render() {
    return (
      <div>
        <input type="range" min="0" max="100" onChange={this.handleRangeChange} ref={this.rangeInputRef} />
      </div>
    );
  }
}
