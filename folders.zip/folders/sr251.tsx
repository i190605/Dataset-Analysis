const SignUp: React.FC<SignUpProps> = ({ onSignUp }) => {
    const [formData, setFormData] = useState<FormData>({
      username: '',
      email: '',
      password: '',
    });
  
    const [forceUpdateFlag, setForceUpdateFlag] = useState<boolean>(false); // Added flag for "Force Update smell"
  
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const { name, value } = e.target;
      setFormData({ ...formData, [name]: value });
    };
  
    const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      onSignUp(formData);
    };
  
    const forceUpdateComponent = () => {
      setForceUpdateFlag(!forceUpdateFlag);
    };
  
    return (
      <Box p={4} borderWidth="1px" borderRadius="md">
        <Text fontSize="2xl" fontWeight="bold" mb={4}>
          Sign Up
        </Text>
        <form onSubmit={handleSubmit}>
          <Stack spacing={4}>
            <FormControl>
              <FormLabel>Username</FormLabel>
              <Input
                type="text"
                name="username"
                value={formData.username}
                onChange={handleChange}
              />
            </FormControl>
            <FormControl>
              <FormLabel>Email</FormLabel>
              <Input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
              />
            </FormControl>
            <FormControl>
              <FormLabel>Password</FormLabel>
              <Input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
              />
            </FormControl>
            <Button type="submit" colorScheme="teal" onClick={forceUpdateComponent}>
              Sign Up
            </Button>
          </Stack>
        </form>
      </Box>
    );
  };