import React, { Component } from 'react';

class MyAppComponent extends Component {
  componentDidMount() {
    ipcRenderer.on("toggle-side-menu", this.handleSideMenuToggle)
  }

  handleSideMenuToggle() {
    session.ui.toggleSidebar()
  }

  render() {
    const { ui } = session
    const showHome = ui.tab === "home"
    const showTimeline = ui.tab === "timeline"
    const showHelp = ui.tab === "help"
    const showSettings = ui.tab === "settings"
    const showNative = ui.tab === "native"
    const showState = ui.tab === "state"
    const showCustomCommands = ui.tab === "customCommands"

    return (
      <Provider session={session}>
        <div style={Styles.container}>
          <div style={Styles.content}>
            {!ui.inTerminal && (
              <div style={Styles.body}>
                <MySidebarComponent />
                <div style={Styles.app}>
                  <div style={showHome ? Styles.page : Styles.pageHidden}>
                    <MyHomeComponent />
                  </div>
                  <div style={showTimeline ? Styles.page : Styles.pageHidden}>
                    <MyTimelineComponent />
                  </div>
                  <div style={showState ? Styles.page : Styles.pageHidden}>
                    <MyStateComponent />
                  </div>
                  <div style={showHelp ? Styles.page : Styles.pageHidden}>
                    <MyHelpComponent />
                  </div>
                  <div style={showNative ? Styles.page : Styles.pageHidden}>
                    <MyNativeComponent />
                  </div>
                  <div style={showCustomCommands ? Styles.page : Styles.pageHidden}>
                    <MyCustomCommandsListComponent />
                  </div>
                  <div style={showSettings ? Styles.page : Styles.pageHidden}>
                    <h1>My Settings</h1>
                  </div>
                </div>
              </div>
            )}
            {ui.inTerminal && (
              <div style={Styles.body}>
                <div style={Styles.app}>
                  <div style={Styles.page}>
                    <MyReactotronTerminalComponent />
                  </div>
                </div>
              </div>
            )}
            <MyStatusBarComponent />
          </div>
          <MyStateKeysAndValuesDialogComponent />
          <MyStateDispatchDialogComponent />
          <MyStateWatchDialogComponent />
          <MyRenameStateDialogComponent />
          <MyFilterTimelineDialogComponent />
          <MyExportTimelineDialogComponent />
          <MySendCustomDialogComponent />
        </div>
      </Provider>
    )
  }
}

export default MyAppComponent;
