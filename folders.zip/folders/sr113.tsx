function PointerBox(props: PointerBoxProps) {
    // don't destructure these, just grab them
    const themeContext = React.useContext(ThemeContext)
    const {bg, border, borderColor, theme: themeProp, sx} = props
    const {caret, children, ...boxProps} = props
    const {bg: sxBg, backgroundColor, ...sxRest} = sx || {}
    const theme = themeProp || themeContext
    const customBackground = bg || sxBg || backgroundColor
  
    const caretProps = {
      bg: bg || sx?.bg || sx?.backgroundColor,
      borderColor: borderColor || sx?.borderColor,
      borderWidth: border,
      location: caret,
      theme,
    }
  
    const defaultBoxProps = {borderWidth: '1px', borderStyle: 'solid', borderColor: 'border.default', borderRadius: 2}
  
    return (
      <Box
        {...defaultBoxProps}
        {...boxProps}
        sx={{
          ...sxRest,
          '--custom-bg': get(`colors.${customBackground}`)({theme}),
          backgroundImage: customBackground
            ? `linear-gradient(var(--custom-bg), var(--custom-bg)), linear-gradient(${theme.colors.canvas.default}, ${theme.colors.canvas.default})`
            : undefined,
          position: 'relative',
        }}
      >
        {children}
        <Caret {...caretProps} />
      </Box>
    )
  }