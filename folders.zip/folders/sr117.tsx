export const WithPageLayout = () => {
    return (
      <PageLayout>
        <PageLayout.Header>
          <PageHeader>
            <PageHeader.ContextArea>
              <PageHeader.ParentLink href="http://github.com">Pull requests</PageHeader.ParentLink>
            </PageHeader.ContextArea>
            <PageHeader.TitleArea>
              <PageHeader.Title as="h2">
                PageHeader component initial layout explorations extra long pull request title &nbsp;
                <Text sx={{color: 'fg.muted', fontWeight: 'light'}}>#1831</Text>
              </PageHeader.Title>
              <PageHeader.Actions>
                <Hidden when={['regular', 'wide']}>
                  <IconButton aria-label="More" icon={KebabHorizontalIcon} />
                  {/* Pop up actions */}
                </Hidden>
  
                <Hidden when={['narrow']}>
                  <Box sx={{display: 'flex'}}>
                    <Button>Edit</Button>
                    <Button leadingIcon={CodeIcon}>Code</Button>
                  </Box>
                </Hidden>
              </PageHeader.Actions>
            </PageHeader.TitleArea>
            <PageHeader.Description>
              <StateLabel status="pullOpened">Open</StateLabel>
              <Hidden when={['narrow']}>
                <Text sx={{fontSize: 1, color: 'fg.muted'}}>
                  <Link href="#" muted sx={{fontWeight: 'bold'}}>
                    broccolinisoup
                  </Link>{' '}
                  wants to merge 3 commits into <BranchName href="#">main</BranchName> from{' '}
                  <BranchName href="#">broccolinisoup/switch-to-new-underlineNav</BranchName>
                </Text>
              </Hidden>
              <Hidden when={['regular', 'wide']}>
                <Text sx={{fontSize: 1, color: 'fg.muted'}}>
                  <BranchName href="#">main</BranchName>
                  <ArrowRightIcon />
                  <BranchName href="#">page-header-initial</BranchName>
                </Text>
              </Hidden>
            </PageHeader.Description>
            <PageHeader.Navigation>
              <UnderlineNav aria-label="Pull Request">
                <UnderlineNav.Item icon={CommentDiscussionIcon} counter="12" aria-current="page">
                  Conversation
                </UnderlineNav.Item>
                <UnderlineNav.Item counter={3} icon={CommitIcon}>
                  Commits
                </UnderlineNav.Item>
                <UnderlineNav.Item counter={7} icon={ChecklistIcon}>
                  Checks
                </UnderlineNav.Item>
                <UnderlineNav.Item counter={4} icon={FileDiffIcon}>
                  Files Changes
                </UnderlineNav.Item>
              </UnderlineNav>
            </PageHeader.Navigation>
          </PageHeader>
        </PageLayout.Header>
        <PageLayout.Content>
          <Box sx={{border: '1px solid', borderRadius: 2, borderColor: 'border.default', height: 200}}></Box>
          <Box
            sx={{
              maxWidth: '100%',
              overflowX: 'auto',
              border: '1px solid',
              whiteSpace: 'nowrap',
              borderColor: 'border.default',
              mt: 3,
              p: 3,
              borderRadius: 2,
            }}
            tabIndex={0}
          >
            This box has really long content. If it is too long, it will cause x overflow and should show a scrollbar.
            When this overflows, it should not break to overall page layout!
          </Box>
        </PageLayout.Content>
        <PageLayout.Pane>
          <Box sx={{display: 'flex', flexDirection: 'column', gap: 3}}>
            <Box>
              <Text sx={{fontSize: 0, fontWeight: 'bold', display: 'block', color: 'fg.muted'}}>Assignees</Text>
              <Text sx={{fontSize: 0, color: 'fg.muted', lineHeight: 'condensed'}}>
                No one –{' '}
                <Link href="#" muted>
                  assign yourself
                </Link>
              </Text>
            </Box>
            <Box role="separator" sx={{width: '100%', height: 1, backgroundColor: 'border.default'}}></Box>
            <Box>
              <Text sx={{fontSize: 0, fontWeight: 'bold', display: 'block', color: 'fg.muted'}}>Labels</Text>
              <Text sx={{fontSize: 0, color: 'fg.muted', lineHeight: 'condensed'}}>None yet</Text>
            </Box>
          </Box>
        </PageLayout.Pane>
      </PageLayout>
    )
  }