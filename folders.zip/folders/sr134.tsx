export const ProfilePage = () => {
    const [selectedIndex, setSelectedIndex] = React.useState<number | null>(1)
    return (
      <Box sx={{display: 'flex', flexDirection: 'row', gap: 3, alignItems: 'flex-start'}}>
        <Box sx={{display: 'flex', flexDirection: 'column', alignItems: 'flex-start', height: '100%'}}>
          <Avatar size={256} src="https://avatars.githubusercontent.com/u/92997159?v=4" alt="mona user avatar" />
          <Box>
            {/* Initial bio info */}
            <Box sx={{paddingY: 3}}>
              <Heading as="h1" sx={{fontSize: 24}}>
                Monalisa Octocat
              </Heading>
              <Heading as="h1" sx={{fontSize: 20, fontWeight: 300}}>
                mona
              </Heading>
            </Box>
  
            {/* Edit Profile / Profile details */}
            <Box sx={{display: 'flex', flexDirection: 'column', color: 'fg.onEmphasis'}}>
              <Button block>Edit Profile</Button>
  
              <Box sx={{display: 'flex', flexDirection: 'row', alignItems: 'center', marginTop: 3}}>
                <Octicon icon={PeopleIcon} size={16} sx={{marginRight: 1}} />
                <Link href="https://github.com" muted sx={{marginRight: 2}}>
                  47 Followers
                </Link>
                <span> · </span>
                <Link href="https://github.com" muted sx={{marginLeft: 2}}>
                  54 Following
                </Link>
              </Box>
            </Box>
          </Box>
        </Box>
        <Box sx={{flexGrow: 1}}>
          <UnderlineNav aria-label="Repository">
            {profileItems.map((item, index) => (
              <UnderlineNav.Item
                key={item.navigation}
                icon={item.icon}
                aria-current={index === selectedIndex ? 'page' : undefined}
                onSelect={event => {
                  event.preventDefault()
                  setSelectedIndex(index)
                }}
                counter={item.counter}
                href={item.href}
              >
                {item.navigation}
              </UnderlineNav.Item>
            ))}
          </UnderlineNav>
          <Box
            sx={{
              border: '1px solid',
              marginTop: 2,
              borderColor: 'border.default',
              borderRadius: '12px',
              height: '300px',
              width: '80%',
              padding: 4,
            }}
          >
            <Text> mona/README.md</Text>
          </Box>
        </Box>
      </Box>
    )
  }
  