import React, { Component } from 'react';

class UncontrolledInput extends Component {
  constructor(props) {
    super(props);
    this.inputRef = React.createRef();
  }

  handleSubmit = (e) => {
    e.preventDefault();
    alert(`Submitted value: ${this.inputRef.current.value}`);
  }

  render() {
    return (
      <div>
        <form onSubmit={this.handleSubmit}>
          <label>
            Uncontrolled Input:
            <input type="text" ref={this.inputRef} />
          </label>
          <button type="submit">Submit</button>
        </form>
      </div>
    );
  }
}

export default UncontrolledInput;
