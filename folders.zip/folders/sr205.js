import React, { Component } from 'react';

class UncontrolledFileInput extends Component {
  handleFileChange = () => {
    const fileInput = this.fileInputRef.current;
    alert(`Selected file: ${fileInput.files[0].name}`);
  }

  render() {
    return (
      <div>
        <input type="file" onChange={this.handleFileChange} ref={this.fileInputRef} />
      </div>
    );
  }
}
