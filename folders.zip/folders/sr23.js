class Baz extends React.Component {
    UNSAFE_componentWillMount() {
      this.forceUpdate();
      setTimeout(() => {
        this.forceUpdate();
      });
    }

    render() {
      return <div onClick={() => {}} />;
    }
  }
