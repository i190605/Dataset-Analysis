import React, { Component } from 'react';

class UncontrolledColorInput extends Component {
  handleColorChange = () => {
    const colorInput = this.colorInputRef.current;
    alert(`Selected color: ${colorInput.value}`);
  }

  render() {
    return (
      <div>
        <input type="color" onChange={this.handleColorChange} ref={this.colorInputRef} />
      </div>
    );
  }
}
