export function DrawerRoot(props: DrawerRootProps) {
    const { classNames, variant, size, scrollAreaComponent, position, transitionProps, ...others } =
      useComponentDefaultProps('DrawerRoot', defaultProps, props);
  
    const { classes, cx, theme } = useStyles({ position }, { name: 'Drawer', variant, size });
  
    const drawerTransition = (theme.dir === 'rtl' ? rtlTransitions : transitions)[position];
  
    return (
      <DrawerProvider value={{ scrollAreaComponent }}>
        <ModalBase
          __staticSelector="Drawer"
          size={size}
          variant={variant}
          transitionProps={{ transition: drawerTransition, duration: 200, ...transitionProps }}
          classNames={{
            ...classNames,
            content: cx(classes.content, classNames?.content),
            inner: cx(classes.inner, classNames?.inner),
          }}
          {...others}
        />
      </DrawerProvider>
    );
  }
  