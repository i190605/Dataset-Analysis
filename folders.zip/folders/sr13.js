class A extends React.Component {
    render() {
      return (
        <div>
          <input id="one" ref={r => (input = input || r)} />
          {this.props.showTwo && (
            <input id="two" ref={r => (input2 = input2 || r)} />
          )}
        </div>
      );
    }

    componentDidUpdate() {
      // Focus should have been restored to the original input
      expect(document.activeElement.id).toBe('one');
      input2.focus();
      expect(document.activeElement.id).toBe('two');
      log.push('input2 focused');
    }
  }
