import React, { Component } from 'react';

class UncontrolledTree extends Component {
  constructor(props) {
    super(props);
    this.treeData = [
      {
        label: 'Node 1',
        children: [
          { label: 'Node 1.1' },
          { label: 'Node 1.2' },
        ],
      },
      {
        label: 'Node 2',
        children: [
          { label: 'Node 2.1' },
          { label: 'Node 2.2' },
        ],
      },
    ];
  }

  handleNodeClick = (node) => {
    // Handle node click logic, e.g., expand/collapse.
    alert(`Clicked node: ${node.label}`);
  }

  renderTreeNodes(nodes) {
    return nodes.map((node, index) => (
      <li key={index}>
        <span onClick={() => this.handleNodeClick(node)}>{node.label}</span>
        {node.children && node.children.length > 0 && (
          <ul>{this.renderTreeNodes(node.children)}</ul>
        )}
      </li>
    ));
  }

  render() {
    return (
      <div>
        <ul>{this.renderTreeNodes(this.treeData)}</ul>
      </div>
    );
  }
}
