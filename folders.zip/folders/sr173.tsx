export const Notifications: React.FC<NotificationsProps> & NotificationsStaticMethods = ({

    className,
    position = 'bottom-right',
    autoClose = 4000,
    transitionDuration = 250,
    containerWidth = rem(440),
    notificationMaxHeight = rem(200),
    limit = 5,
    zIndex = getDefaultZIndex('overlay'),
    style,
    children,
    target,
    ...others
  }) => {
    const forceUpdate = useForceUpdate();
    const refs = useRef<Record<string, HTMLDivElement>>({});
    const previousLength = useRef<number>(0);
    const {
      notifications,
      showNotification,
      updateNotification,
      hideNotification,
      clean,
      cleanQueue,
    } = useNotificationsState({ limit });
  
    const { classes, cx, theme } = useStyles({ zIndex });
    const shouldReduceMotion = useReducedMotion();
    const reduceMotion = theme.respectReducedMotion ? shouldReduceMotion : false;
    const duration = reduceMotion ? 1 : transitionDuration;
    const positioning = (POSITIONS.includes(position) ? position : 'bottom-right').split(
      '-'
    ) as NotificationsPositioning;
  
    useDidUpdate(() => {
      if (notifications.length > previousLength.current) {
        setTimeout(() => forceUpdate(), 0);
      }
      previousLength.current = notifications.length;
    }, [notifications]);
  
    useNotificationsEvents({
      show: showNotification,
      hide: hideNotification,
      update: updateNotification,
      clean,
      cleanQueue,
    });
  
    const items = notifications.map((notification) => (
      <Transition
        key={notification.id}
        timeout={duration}
        onEnter={() => refs.current[notification.id].offsetHeight}
        nodeRef={{ current: refs.current[notification.id] }}
      >
        {(state) => (
          <NotificationContainer
            innerRef={(node) => {
              refs.current[notification.id] = node;
            }}
            notification={notification}
            onHide={hideNotification}
            className={classes.notification}
            autoClose={autoClose}
            sx={[
              {
                ...getNotificationStateStyles({
                  state,
                  positioning,
                  transitionDuration: duration,
                  maxHeight: notificationMaxHeight,
                }),
              },
              ...(Array.isArray(notification.sx) ? notification.sx : [notification.sx]),
            ]}
          />
        )}
      </Transition>
    ));
  
    return (
      <Portal target={target}>
        <Box
          className={cx(classes.notifications, className)}
          style={style}
          sx={{
            maxWidth: containerWidth,
            ...getPositionStyles(positioning, theme.spacing.md),
          }}
          {...others}
        >
          <TransitionGroup>{items}</TransitionGroup>
        </Box>
      </Portal>
    );
  };