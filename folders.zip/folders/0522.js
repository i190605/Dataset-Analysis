this.state = {
    value: props.value,
    isFocused: false,
  };