const ArrangeMakeUpModal = (props) => {
    const [formState, dispatch] = useReducer(formReducer, {
      input: {
        Start_timeof_Teacher: {
          value: "",
          isValid: "",
        },
        End_time_of_Teacher: {
          value: "",
          isValid: "",
        },
        Start_time_of_Class: {
          value: "",
          isValid: "",
        },
        End_time_of_Class: {
          value: "",
          isValid: "",
        },
        select_day: {
          value: "",
          isValid: "",
        },
        select_student: {
          value: "",
          isValid: "",
        },
      },
      isValid: false,
    });
    const inputHandler = useCallback((id, value, isValid) => {
      dispatch({
        type: "INPUT_CHANGE",
        value: value,
        isValid: isValid,
        inputId: id,
      });
    }, []);
  
    const submitHandler = (event) => {
      event.preventDefault();
      console.log(formState.inputs);
      console.log(props.id);
      fetch("http://3.239.246.88:5000/auth/add-makeup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer " + localStorage.getItem("auth_token"),
          },
          body: JSON.stringify({
            TeacherStartTime: formState.inputs.Start_timeof_Teacher.value,
            TeacherEndTime: formState.inputs.End_time_of_Teacher.value,
            StudentStartTime: formState.inputs.Start_time_of_Class.value,
            StudentEndTime: formState.inputs.End_time_of_Class.value,
            Day: formState.inputs.selectDay.value,
            user: formState.inputs.selectStudent.value,
            teacher: props && props.id
            }),
          })
          .then((res) => {
            if (res.status !== 200 && res.status !== 201) {
              throw new Error("Failed!");
            }
            return res.json();
          })
          .then((resData) => {
            console.log(resData);
          }
          )
          .catch((err) => {
            console.log(err);
          }
          );
  
    };
    return (
      <div>
        <button
          type="button"
          className="btn btn-dark"
          data-bs-toggle="modal"
          data-bs-target="#exampleModal"
        >
          Arrange Make Up Class
        </button>
  
        <div
          className="modal fade"
          id="exampleModal"
          tabIndex="-1"
          aria-labelledby="exampleModalLabel"
          aria-hidden="true"
        >
          <div className="modal-dialog">
            <div className="modal-content text-start">
              <div className="modal-header">
                <h1 className="modal-title fs-5" id="exampleModalLabel">
                  Arrange Make Up Class
                </h1>
                <button
                  type="button"
                  className="btn-close"
                  data-bs-dismiss="modal"
                  aria-label="Close"
                ></button>
              </div>
              <form onSubmit={submitHandler}>
                <div className="modal-body">
                  <div className="mb-3">
                    <Input
                      id="Start_timeof_Teacher"
                      type="time"
                      placeholder="Teacher start time"
                      className="form-control"
                      label="Start time of Teacher"
                      error="Please enter a valid start teacher time"
                      validators={[VALIDATOR_REQUIRE()]}
                      onInput={inputHandler}
                    />
                  </div>
  
                  <div className="mb-3">
                    <Input
                      id="End_time_of_Teacher"
                      type="time"
                      placeholder="Teacher End time"
                      className="form-control"
                      label="End time of Teacher"
                      error="Please enter a valid end teacher time"
                      validators={[VALIDATOR_REQUIRE()]}
                      onInput={inputHandler}
                    />
                  </div>
                  <div className="mb-3">
                    <Input
                      id="Start_time_of_Class"
                      type="time"
                      placeholder="Class class time"
                      className="form-control"
                      label="Start time of Class"
                      error="Please enter a valid start Class time"
                      validators={[VALIDATOR_REQUIRE()]}
                      onInput={inputHandler}
                    />
                  </div>
                  <div className="mb-3">
                    <Input
                      id="End_time_of_Class"
                      type="time"
                      placeholder="Class End time"
                      className="form-control"
                      label="End time of Class"
                      error="Please enter a valid end Class time"
                      validators={[VALIDATOR_REQUIRE()]}
                      onInput={inputHandler}
                    />
                  </div>
                  <div className="mb-3">
                    <Input
                      id="selectDay"
                      type="selectDay"
                      placeholder="selectDay"
                      className="form-control"
                      label="Select Day"
                      error="Please enter a valid day"
                      validators={[VALIDATOR_REQUIRE()]}
                      onInput={inputHandler}
                    />
                  </div>
  
                  <div className="mb-3">
                    <Input
                      id="selectStudent"
                      type="selectStudent"
                      placeholder="selectStudent"
                      className="form-control"
                      label="Select Student"
                      error="Please enter a valid student"
                      validators={[VALIDATOR_REQUIRE()]}
                      onInput={inputHandler}
                    />
                  </div>
                </div>
                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    data-bs-dismiss="modal"
                  >
                    Close
                  </button>
                  <button
                    type="submit"
                    className="btn btn-primary"
                    disabled={!formState.isValid}
                  >
                    Save changes
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    );
  };
  