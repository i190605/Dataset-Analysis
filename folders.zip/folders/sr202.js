import React, { Component } from 'react';

class UncontrolledTextarea extends Component {
  handleSubmit = (e) => {
    e.preventDefault();
    const textarea = this.textareaRef.current;
    alert(`Submitted value: ${textarea.value}`);
  }

  render() {
    return (
      <div>
        <form onSubmit={this.handleSubmit}>
          <textarea ref={this.textareaRef} />
          <button type="submit">Submit</button>
        </form>
      </div>
    );
  }
}
