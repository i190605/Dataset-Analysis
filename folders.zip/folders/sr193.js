class ForceUpdatesOnChange extends React.Component {
    componentDidMount() {
      this.onChange = () => this.forceUpdate();
      this.onChange();
      callbacks.push(this.onChange);
    }
    componentWillUnmount() {
      callbacks = callbacks.filter(c => c !== this.onChange);
    }
    render() {
      return <div key={Math.random()} onClick={function () {}} />;
    }
  }
