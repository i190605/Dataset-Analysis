import ast
import json


def find_component(node):
    if isinstance(node, ast.ClassDef):
        if 'Component' in [base.id for base in node.bases]:
            return node
    for child_node in ast.iter_child_nodes(node):
        result = find_component(child_node)
        if result:
            return result
    return None

def copy_component_file(path):
    try:
        with open(path, 'r') as file:
            lines = file.readlines()
            content = ''.join(lines)
            tree = ast.parse(content)

            component_node = find_component(tree)
            if component_node:
                start_line = component_node.lineno
                end_line = component_node.end_lineno
                component_content = ''.join(lines[start_line-1:end_line])
                return component_content, start_line, end_line
            else:
                return "No React component found in the file.", None, None

    except FileNotFoundError:
        return "File not found.", None, None

# Example usage
path = 'D:\\fyp\\DatasetGeneration\\carbon\\components\\BackgroundSelect.js'

component_content, start_line, end_line = copy_component_file(path)
if component_content:
    print("Component content:")
    print(component_content)
    print("Start line:", start_line)
    print("End line:", end_line)
else:
    print("Error occurred while copying the component file.")
