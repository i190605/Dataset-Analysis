
const removePrereq = (removeUuid?: string) => {
    if (removeUuid === undefined) return;

    selectedPrereqs.delete(removeUuid);
    availablePrereqs.add(removeUuid);
    changePrerequisiteUuids([...selectedPrereqs]);
  };

  return (
    <PrerequisiteSelect
      itemRenderer={prerequisiteRenderer}
      items={[...availablePrereqs].map(uuid => inferencer.getAchievement(uuid))}
      noResults={<MenuItem disabled={true} text="No available achievement" />}
      onItemSelect={achievement => selectPrereq(achievement.uuid)}
      selectedItems={[...selectedPrereqs].map(uuid => inferencer.getAchievement(uuid))}
      tagInputProps={{ onRemove: title => removePrereq(getUuid(title!.toString())) }}
      tagRenderer={achievement => achievement.title}
      itemPredicate={prerequisitePredicate}
      resetOnSelect={true}
    />
  );
};
