export function DefaultValue({
    label,
    classNames,
    styles,
    className,
    onRemove,
    disabled,
    readOnly,
    size,
    radius = 'sm',
    variant,
    unstyled,
    ...others
  }: MultiSelectValueProps) {
    const { classes, cx } = useStyles(
      { disabled, readOnly, radius },
      { name: 'MultiSelect', classNames, styles, unstyled, size, variant }
    );
  
    return (
      <div className={cx(classes.defaultValue, className)} {...others}>
        <span className={classes.defaultValueLabel}>{label}</span>
  
        {!disabled && !readOnly && (
          <CloseButton
            aria-hidden
            onMouseDown={onRemove}
            size={buttonSizes[size]}
            radius={2}
            color="blue"
            variant="transparent"
            iconSize="70%"
            className={classes.defaultValueRemove}
            tabIndex={-1}
            unstyled={unstyled}
          />
        )}
      </div>
    );
  }