import React, { Component } from 'react';

class UncontrolledDateInput extends Component {
  handleDateChange = () => {
    const dateInput = this.dateInputRef.current;
    alert(`Selected date: ${dateInput.value}`);
  }

  render() {
    return (
      <div>
        <input type="date" onChange={this.handleDateChange} ref={this.dateInputRef} />
      </div>
    );
  }
}
