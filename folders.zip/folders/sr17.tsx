interface UncontrolledComponentProps {
    onUpload: (data: string[]) => void;
  }
  
  const UncontrolledComponent: React.FC<UncontrolledComponentProps> = ({ onUpload }) => {
    const fileInputRef = useRef<HTMLInputElement | null>(null);
  
    useEffect(() => {
      // Simulate initial data loading.
      fetch('/api/data')
        .then((response) => response.json())
        .then((newData: string[]) => {
          // Data loaded from an external source is not controlled by React state.
          // This demonstrates the uncontrolled component smell.
          onUpload(newData);
        });
    }, [onUpload]);
  
    const handleFileUpload = () => {
      if (fileInputRef.current?.files) {
        const selectedFile = fileInputRef.current.files[0];
        const reader = new FileReader();
  
        reader.onload = (event) => {
          const fileData = event.target?.result as string;
          const parsedData = parseData(fileData);
          // Update data outside of React state.
          onUpload(parsedData);
        };
  
        if (selectedFile) {
          reader.readAsText(selectedFile);
        }
      }
    };
  
    const parseData = (fileData: string): string[] => {
      // Complex data parsing logic, not utilizing React state.
      const parsedData = /* ... complex parsing logic ... */;
      return parsedData;
    };
  
    return (
      <div>
        <h2>Uncontrolled Component with Smell</h2>
        <input type="file" ref={fileInputRef} />
        <button onClick={handleFileUpload}>Upload File</button>
      </div>
    );
  };
  