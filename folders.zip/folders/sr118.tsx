const UncontrolledEditor = forwardRef<MarkdownEditorHandle, UncontrolledEditorProps>((props, forwardedRef) => {
    const [value, setValue] = useState('')
  
    const handleChange = (v: string) => {
      props.onChange?.(v)
      setValue(v)
    }
  
    const onRenderPreview = async () => 'Preview'
  
    return (
      <ThemeProvider>
        <MarkdownEditor
          ref={forwardedRef}
          onRenderPreview={onRenderPreview}
          {...props}
          value={value}
          onChange={handleChange}
        >
          <MarkdownEditor.Label visuallyHidden={props.hideLabel}>Test Editor</MarkdownEditor.Label>
  
          {props.children}
        </MarkdownEditor>
      </ThemeProvider>
    )
  })