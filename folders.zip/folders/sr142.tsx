export function DialogBody(props: DialogProps) {
    const {
      withCloseButton,
      onClose,
      position,
      shadow,
      children,
      className,
      style,
      classNames,
      styles,
      opened,
      withBorder,
      size,
      transition,
      transitionDuration,
      transitionTimingFunction,
      unstyled,
      variant,
      keepMounted,
      ...others
    } = useComponentDefaultProps('Dialog', defaultProps, props);
  
    const { classes, cx } = useStyles(null, {
      classNames,
      styles,
      unstyled,
      name: 'Dialog',
      variant,
      size,
    });
  
    return (
      <Transition
        keepMounted={keepMounted}
        mounted={opened}
        transition={transition}
        duration={transitionDuration}
        timingFunction={transitionTimingFunction}
      >
        {(transitionStyles) => (
          <Paper
            className={cx(classes.root, className)}
            style={{ ...style, ...transitionStyles }}
            shadow={shadow}
            withBorder={withBorder}
            unstyled={unstyled}
            {...others}
          >
            {withCloseButton && <CloseButton onClick={onClose} className={classes.closeButton} />}
            {children}
          </Paper>
        )}
      </Transition>
    );
  }
  
  export const Dialog = forwardRef<HTMLDivElement, DialogProps>(
    ({ zIndex = getDefaultZIndex('modal'), ...props }: DialogProps, ref) => {
      const theme = useMantineTheme();
  
      return (
        <Affix
          zIndex={zIndex}
          position={props.position || { bottom: theme.spacing.xl, right: theme.spacing.xl }}
          ref={ref}
        >
          <DialogBody {...props} />
        </Affix>
      );
    }
  );
  